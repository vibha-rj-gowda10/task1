import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json({ limit: '25mb' }));

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', hasGeminiKey: Boolean(process.env.GEMINI_API_KEY) });
});

// Logo analysis endpoint using Gemini 2.5/3.8 Flash
app.post('/api/analyze-logo', async (req, res) => {
  try {
    const { imageBase64, mimeType = 'image/png', brandName = '', industry = '' } = req.body;

    if (!imageBase64) {
      return res.status(400).json({ error: 'Missing imageBase64 data' });
    }

    if (!process.env.GEMINI_API_KEY) {
      return res.status(200).json({
        fallback: true,
        message: 'No GEMINI_API_KEY detected in environment. Using expert senior designer heuristic engine.',
      });
    }

    const ai = new GoogleGenAI();
    // Strip header prefix if present (e.g. data:image/png;base64,)
    const cleanBase64 = imageBase64.replace(/^data:[a-zA-Z0-9/+-]+;base64,/, '');

    const prompt = `You are a world-class Senior Brand Identity Specialist and Creative Director reviewing an internship project submission for "TASK 1: LOGO REDESIGN".
The user has provided their original logo image. Brand context: Name="${brandName || 'Not specified'}", Industry="${industry || 'General commercial'}".

Carefully examine this logo image and provide a comprehensive senior designer critique.
Return ONLY valid JSON with this exact structure (no markdown fences, just pure JSON):
{
  "brandName": "Estimated or provided brand name",
  "industry": "Identified industry",
  "overallImpression": "Concise executive critique in 2-3 sentences",
  "analysis": {
    "symbol": "Detailed analysis of symbol/icon, visual motifs, metaphorical clarity, and mechanical flaws",
    "typography": "Analysis of type choice, kerning, weight balance, legibility, and era characteristics",
    "colors": [
      {"name": "Color name", "hex": "#HEX", "usage": "e.g. Primary icon / Typography / Accent", "evaluation": "Why this color works or fails"}
    ],
    "shapeComposition": "Geometry, balance, visual weight distribution, optical alignment, and spatial tension",
    "brandPersonality": {
      "traits": ["Trait 1", "Trait 2", "Trait 3"],
      "tone": "e.g., Utilitarian, corporate, energetic, dated 2000s tech",
      "perceptionScore": 65
    },
    "strengths": [
      "Key strength 1",
      "Key strength 2",
      "Key strength 3"
    ],
    "weaknesses": [
      "Weakness 1 (e.g. poor small-screen legibility)",
      "Weakness 2 (e.g. dated bevel/gradient)",
      "Weakness 3 (e.g. complex clipping paths or clashing fonts)"
    ],
    "whatToPreserve": [
      "Exact visual asset / core silhouette to protect brand equity",
      "Core metaphorical concept",
      "Primary brand color recognition"
    ],
    "whatToImprove": [
      "Geometric simplification needed",
      "Type hierarchy and optical kerning overhaul",
      "Elimination of skeuomorphic artifacts or excessive details"
    ]
  },
  "directions": {
    "versionA": {
      "title": "Minimal & Modern",
      "concept": "Clean reductive geometry with high negative space",
      "symbolMeaning": "Symbolic distillation focusing on pure form",
      "typography": "Clean Neo-Grotesque sans-serif with generous tracking",
      "colors": [
        {"name": "Primary", "hex": "#1E293B"},
        {"name": "Accent", "hex": "#2563EB"},
        {"name": "Neutral", "hex": "#F8FAFC"}
      ],
      "colorRationale": "Restrained dual-tone palette prioritizing legibility and digital rendering",
      "improvements": "Removes clutter, scales seamlessly to 16px favicon, crisp contemporary feel"
    },
    "versionB": {
      "title": "Professional & Corporate",
      "concept": "Structured authority with robust architectural balance",
      "symbolMeaning": "Solid geometric lockup evoking trust, stability, and scale",
      "typography": "Authoritative geometric grotesque with crisp letterforms",
      "colors": [
        {"name": "Deep Brand Navy", "hex": "#0F172A"},
        {"name": "Precision Cyan", "hex": "#0EA5E9"},
        {"name": "Steel Gray", "hex": "#64748B"}
      ],
      "colorRationale": "High-contrast corporate hierarchy conveying institutional trust and modern enterprise",
      "improvements": "Standardized optical alignment, enterprise-grade typography lockup, pristine grid execution"
    },
    "versionC": {
      "title": "Creative & Contemporary",
      "concept": "Dynamic forward-leaning form with unexpected optical rhythm",
      "symbolMeaning": "Evolutionary kinetic symbol suggesting innovation and agility",
      "typography": "High-contrast humanist/geometric hybrid with distinctive bespoke details",
      "colors": [
        {"name": "Electric Indigo", "hex": "#4F46E5"},
        {"name": "Vibrant Coral", "hex": "#F43F5E"},
        {"name": "Soft Chalk", "hex": "#F1F5F9"}
      ],
      "colorRationale": "Energetic, dynamic pairing that differentiates the brand in competitive creative markets",
      "improvements": "Breaks out of dated static conventions while preserving the unmistakable soul of the original icon"
    }
  }
}`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: [
        {
          role: 'user',
          parts: [
            {
              inlineData: {
                mimeType,
                data: cleanBase64,
              },
            },
            { text: prompt },
          ],
        },
      ],
      config: {
        responseMimeType: 'application/json',
      },
    });

    const responseText = response.text || '{}';
    let parsed;
    try {
      parsed = JSON.parse(responseText);
    } catch {
      // Clean possible wrapper if any
      const cleaned = responseText.replace(/```json/g, '').replace(/```/g, '').trim();
      parsed = JSON.parse(cleaned);
    }

    res.json(parsed);
  } catch (error: any) {
    console.error('Error analyzing logo:', error);
    res.status(500).json({ error: error.message || 'Internal server error analyzing logo' });
  }
});

// Vite or static serving
async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    const { createServer } = await import('vite');
    const vite = await createServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(Number(PORT), '0.0.0.0', () => {
    console.log(`Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
