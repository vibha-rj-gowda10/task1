import React, { useState } from 'react';
import { CASE_STUDIES } from './data/caseStudies';
import { CaseStudy } from './types/brand';
import { Header } from './components/Header';
import { OriginalAnalysis } from './components/OriginalAnalysis';
import { RedesignVersions } from './components/RedesignVersions';
import { LogoVariations } from './components/LogoVariations';
import { BrandGuidelines } from './components/BrandGuidelines';
import { PresentationDeck } from './components/PresentationDeck';
import { LogoUploader } from './components/LogoUploader';
import { ExportModal } from './components/ExportModal';
import { 
  Compass, 
  Layers, 
  Grid, 
  BookOpen, 
  Presentation, 
  Upload, 
  Sparkles, 
  ArrowRight,
  ShieldCheck,
  CheckCircle2
} from 'lucide-react';

export default function App() {
  const [caseStudies, setCaseStudies] = useState<CaseStudy[]>(CASE_STUDIES);
  const [selectedCaseId, setSelectedCaseId] = useState<string>(CASE_STUDIES[0].id);
  const [selectedVersionId, setSelectedVersionId] = useState<'versionA' | 'versionB' | 'versionC'>('versionA');
  const [currentTab, setCurrentTab] = useState<'audit' | 'redesigns' | 'variations' | 'guidelines' | 'deck'>('audit');
  
  const [isUploaderOpen, setIsUploaderOpen] = useState<boolean>(false);
  const [isExportOpen, setIsExportOpen] = useState<boolean>(false);
  const [isFullscreenDeck, setIsFullscreenDeck] = useState<boolean>(false);

  const currentCase = caseStudies.find(c => c.id === selectedCaseId) || caseStudies[0];
  const currentVersion = currentCase.versions[selectedVersionId];

  const handleCustomLogoCreated = (newCaseStudy: CaseStudy) => {
    setCaseStudies(prev => [newCaseStudy, ...prev]);
    setSelectedCaseId(newCaseStudy.id);
    setSelectedVersionId('versionA');
    setCurrentTab('audit');
  };

  const handleStartPresentation = () => {
    setCurrentTab('deck');
    setIsFullscreenDeck(true);
  };

  return (
    <div className="min-h-screen bg-[#090a0f] text-neutral-100 flex flex-col font-sans selection:bg-indigo-500 selection:text-white">
      
      {/* Top Main Navigation Header */}
      <Header
        currentTab={currentTab}
        setCurrentTab={setCurrentTab}
        caseStudies={caseStudies}
        selectedCaseId={selectedCaseId}
        onSelectCase={(id) => {
          setSelectedCaseId(id);
          setSelectedVersionId('versionA');
        }}
        onOpenUpload={() => setIsUploaderOpen(true)}
        onOpenExport={() => setIsExportOpen(true)}
        onStartPresentation={handleStartPresentation}
      />

      {/* Main Workflow Stage */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        {/* Step Progress Tracker Ribbon (visible across all tabs except fullscreen deck) */}
        {!isFullscreenDeck && (
          <div className="mb-8 no-print">
            <div className="bg-neutral-900/90 border border-neutral-800 rounded-2xl p-4 flex flex-wrap items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse"></span>
                <div>
                  <div className="text-xs font-mono text-neutral-400">
                    Active Brand Rebrand Project:
                  </div>
                  <div className="text-sm font-bold text-white font-display">
                    {currentCase.name} <span className="text-neutral-500 font-normal">({currentCase.badge})</span>
                  </div>
                </div>
              </div>

              {/* Progress Steps */}
              <div className="flex items-center gap-2 overflow-x-auto text-xs font-mono">
                <button
                  onClick={() => setCurrentTab('audit')}
                  className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-colors ${
                    currentTab === 'audit' ? 'bg-indigo-600 text-white font-bold' : 'text-neutral-400 hover:text-white'
                  }`}
                >
                  <span>1. Audit</span>
                </button>
                <span className="text-neutral-600">→</span>
                <button
                  onClick={() => setCurrentTab('redesigns')}
                  className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-colors ${
                    currentTab === 'redesigns' ? 'bg-indigo-600 text-white font-bold' : 'text-neutral-400 hover:text-white'
                  }`}
                >
                  <span>2. Redesigns (A/B/C)</span>
                </button>
                <span className="text-neutral-600">→</span>
                <button
                  onClick={() => setCurrentTab('variations')}
                  className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-colors ${
                    currentTab === 'variations' ? 'bg-indigo-600 text-white font-bold' : 'text-neutral-400 hover:text-white'
                  }`}
                >
                  <span>3. Variations</span>
                </button>
                <span className="text-neutral-600">→</span>
                <button
                  onClick={() => setCurrentTab('guidelines')}
                  className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-colors ${
                    currentTab === 'guidelines' ? 'bg-indigo-600 text-white font-bold' : 'text-neutral-400 hover:text-white'
                  }`}
                >
                  <span>4. Guidelines</span>
                </button>
                <span className="text-neutral-600">→</span>
                <button
                  onClick={() => setCurrentTab('deck')}
                  className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-colors ${
                    currentTab === 'deck' ? 'bg-indigo-600 text-white font-bold' : 'text-neutral-400 hover:text-white'
                  }`}
                >
                  <span>5. 14-Slide Deck</span>
                </button>
              </div>

              {/* Quick switch to upload */}
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setIsUploaderOpen(true)}
                  className="px-3 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-750 text-neutral-300 hover:text-white text-xs font-medium flex items-center gap-1.5 transition-colors border border-neutral-700"
                >
                  <Upload className="w-3 h-3 text-indigo-400" />
                  <span>Upload Another Logo</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Tab 1: Original Logo Deep Audit */}
        {currentTab === 'audit' && (
          <OriginalAnalysis
            caseStudy={currentCase}
            onProceedToRedesigns={() => setCurrentTab('redesigns')}
          />
        )}

        {/* Tab 2: 3 Redesign Concepts (A/B/C) */}
        {currentTab === 'redesigns' && (
          <RedesignVersions
            caseStudy={currentCase}
            selectedVersionId={selectedVersionId}
            onSelectVersion={setSelectedVersionId}
            onProceedToVariations={() => setCurrentTab('variations')}
          />
        )}

        {/* Tab 3: Logo Variations Suite */}
        {currentTab === 'variations' && (
          <LogoVariations
            caseStudy={currentCase}
            selectedVersion={currentVersion}
            onProceedToGuidelines={() => setCurrentTab('guidelines')}
          />
        )}

        {/* Tab 4: Mini Brand Guidelines */}
        {currentTab === 'guidelines' && (
          <BrandGuidelines
            caseStudy={currentCase}
            selectedVersion={currentVersion}
            onProceedToDeck={() => setCurrentTab('deck')}
          />
        )}

        {/* Tab 5: 14-Slide Presentation Deck */}
        {currentTab === 'deck' && (
          <PresentationDeck
            caseStudy={currentCase}
            selectedVersion={currentVersion}
            isFullscreen={isFullscreenDeck}
            onToggleFullscreen={() => setIsFullscreenDeck(!isFullscreenDeck)}
            onOpenExport={() => setIsExportOpen(true)}
          />
        )}

      </main>

      {/* Footer */}
      {!isFullscreenDeck && (
        <footer className="border-t border-neutral-900 bg-neutral-950 py-8 text-neutral-500 text-xs no-print">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <span className="font-mono font-bold text-neutral-300">TASK 1: LOGO REDESIGN</span>
              <span>·</span>
              <span>Senior Graphic Design &amp; Brand Identity Internship Project</span>
            </div>
            <div className="flex items-center gap-4 font-mono text-[11px]">
              <button 
                onClick={() => setIsExportOpen(true)}
                className="text-indigo-400 hover:text-indigo-300 underline"
              >
                Export Submission Report (Markdown)
              </button>
              <span>·</span>
              <button 
                onClick={handleStartPresentation}
                className="text-neutral-400 hover:text-neutral-200"
              >
                Present 14 Slides
              </button>
            </div>
          </div>
        </footer>
      )}

      {/* Upload Logo Modal */}
      <LogoUploader
        isOpen={isUploaderOpen}
        onClose={() => setIsUploaderOpen(false)}
        onCustomLogoCreated={handleCustomLogoCreated}
        caseStudies={caseStudies}
        onSelectExistingCase={(id) => {
          setSelectedCaseId(id);
          setSelectedVersionId('versionA');
          setCurrentTab('audit');
        }}
      />

      {/* Export Deliverables Modal */}
      <ExportModal
        isOpen={isExportOpen}
        onClose={() => setIsExportOpen(false)}
        caseStudy={currentCase}
        selectedVersion={currentVersion}
      />

    </div>
  );
}
