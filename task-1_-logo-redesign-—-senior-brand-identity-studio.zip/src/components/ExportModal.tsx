import React, { useState } from 'react';
import { 
  X, 
  Copy, 
  Check, 
  Printer, 
  FileText, 
  Download, 
  Sparkles, 
  BookOpen, 
  Layers 
} from 'lucide-react';
import { CaseStudy, RedesignVersion } from '../types/brand';

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  caseStudy: CaseStudy;
  selectedVersion: RedesignVersion;
}

export const ExportModal: React.FC<ExportModalProps> = ({
  isOpen,
  onClose,
  caseStudy,
  selectedVersion,
}) => {
  const [copiedReport, setCopiedReport] = useState<boolean>(false);
  const [activeFormat, setActiveFormat] = useState<'markdown' | 'presentation'>('markdown');

  if (!isOpen) return null;

  const { analysis, versions, guidelines } = caseStudy;

  // Generate complete internship report text in clean markdown
  const reportMarkdown = `# INTERNSHIP SUBMISSION REPORT
## TASK 1: LOGO REDESIGN
**Brand Case Study:** ${caseStudy.name}  
**Industry:** ${caseStudy.industry}  
**Role:** Senior Graphic Designer & Brand Identity Specialist  
**Deliverable Status:** Complete  

---

### 1. ANALYSIS OF THE ORIGINAL LOGO
- **Brand Context:** ${analysis.brandName} (${analysis.established})
- **Executive Summary:** ${analysis.executiveSummary}

#### Detailed Diagnostic Audit:
1. **Symbol / Icon:**
   - Analysis: ${analysis.symbolAnalysis.description}
   - Metaphor: ${analysis.symbolAnalysis.metaphor}
   - Critical Flaws:
     ${analysis.symbolAnalysis.flaws.map(f => `- ${f}`).join('\n     ')}

2. **Typography:**
   - Font Classification: ${analysis.typographyAnalysis.fontType}
   - Critique: ${analysis.typographyAnalysis.critique}
   - Legibility Breakdown: ${analysis.typographyAnalysis.legibilityIssue}

3. **Colors & Chromatic Ratio:**
   - Palette Evaluation: ${analysis.colorsAnalysis.harmonyCritique}
   - Accessibility & Contrast: ${analysis.colorsAnalysis.contrastIssue}
   - Original Hues:
     ${analysis.colorsAnalysis.originalColors.map(c => `- ${c.name} (${c.hex}): ${c.note}`).join('\n     ')}

4. **Shape & Composition:**
   - Balance: ${analysis.shapeComposition.balance}
   - Composition Type: ${analysis.shapeComposition.compositionType}
   - Scalability Rating: ${analysis.shapeComposition.scalabilityScore}/100

5. **Brand Personality Assessment:**
   - Perceived Persona: ${analysis.brandPersonality.perceivedTraits.join(', ')}
   - Target Persona: ${analysis.brandPersonality.intendedTraits.join(', ')}
   - Perception Gap: ${analysis.brandPersonality.personalityGap}

6. **Strengths & Weaknesses:**
   - Verified Strengths:
     ${analysis.strengths.map(s => `- ${s}`).join('\n     ')}
   - Structural Weaknesses:
     ${analysis.weaknesses.map(w => `- ${w}`).join('\n     ')}

7. **What Must Be Preserved (Core Equity):**
   ${analysis.whatToPreserve.map(p => `- ${p}`).join('\n   ')}

8. **What Must Be Improved (Action Items):**
   ${analysis.whatToImprove.map(i => `- ${i}`).join('\n   ')}

---

### 2. THREE DIVERGENT REDESIGN DIRECTIONS

#### VERSION A — Minimal & Modern
- **Concept:** ${versions.versionA.concept}
- **Symbol Meaning:** ${versions.versionA.symbolMeaning}
- **Typography:** ${versions.versionA.typography.primaryFont} (${versions.versionA.typography.style})
- **Palette:**
  ${versions.versionA.colors.map(c => `- ${c.name} (${c.hex} | RGB: ${c.rgb} | CMYK: ${c.cmyk}): ${c.rationale}`).join('\n  ')}
- **Why It Improves Original:**
  ${versions.versionA.improvements.map(imp => `- ${imp}`).join('\n  ')}

#### VERSION B — Professional & Corporate
- **Concept:** ${versions.versionB.concept}
- **Symbol Meaning:** ${versions.versionB.symbolMeaning}
- **Typography:** ${versions.versionB.typography.primaryFont} (${versions.versionB.typography.style})
- **Palette:**
  ${versions.versionB.colors.map(c => `- ${c.name} (${c.hex} | RGB: ${c.rgb} | CMYK: ${c.cmyk}): ${c.rationale}`).join('\n  ')}
- **Why It Improves Original:**
  ${versions.versionB.improvements.map(imp => `- ${imp}`).join('\n  ')}

#### VERSION C — Creative & Contemporary
- **Concept:** ${versions.versionC.concept}
- **Symbol Meaning:** ${versions.versionC.symbolMeaning}
- **Typography:** ${versions.versionC.typography.primaryFont} (${versions.versionC.typography.style})
- **Palette:**
  ${versions.versionC.colors.map(c => `- ${c.name} (${c.hex} | RGB: ${c.rgb} | CMYK: ${c.cmyk}): ${c.rationale}`).join('\n  ')}
- **Why It Improves Original:**
  ${versions.versionC.improvements.map(imp => `- ${imp}`).join('\n  ')}

---

### 3. RECOMMENDED IDENTITY & VARIATION SUITE
**Selected Master Direction:** ${selectedVersion.label} (${selectedVersion.styleTitle})
- **Primary Logo:** Master horizontal lockup for website headers and letterheads.
- **Secondary Logo:** Stacked center-aligned lockup for packaging and signage.
- **Icon-Only Version:** 1:1 square vector for favicons, app icons, and social media avatars.
- **Monochrome Version:** 100% Black (positive) and 100% White (knockout negative) for single-ink reproduction.
- **Light & Dark Background Versions:** Calibrated for high-contrast viewing in day and night modes.

---

### 4. MINI BRAND GUIDELINES
- **Clear Space Perimeter:** ${guidelines.clearSpaceRatio} (${guidelines.clearSpaceExplanation})
- **Minimum Digital Size:** ${guidelines.minSizeDigital}
- **Minimum Print Size:** ${guidelines.minSizePrint}
- **Prohibited Misuse (Don'ts):**
  ${guidelines.dosAndDonts.filter(d => d.type === 'dont').map(d => `- ${d.title}: ${d.description}`).join('\n  ')}
- **Approved Practices (Do's):**
  ${guidelines.dosAndDonts.filter(d => d.type === 'do').map(d => `- ${d.title}: ${d.description}`).join('\n  ')}
- **Recommended Touchpoint Applications:**
  ${guidelines.applications.map(a => `- ${a.title} (${a.category}): ${a.description}`).join('\n  ')}

---

### 5. DESIGN RATIONALE & CONCLUSION
${caseStudy.rationaleSummary}

**Conclusion:** ${caseStudy.conclusionTakeaway}
`;

  const handleCopy = () => {
    navigator.clipboard.writeText(reportMarkdown);
    setCopiedReport(true);
    setTimeout(() => setCopiedReport(false), 2000);
  };

  const handlePrint = () => {
    onClose();
    setTimeout(() => {
      window.print();
    }, 200);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 sm:p-6 overflow-y-auto no-print">
      <div className="bg-neutral-900 border border-neutral-800 rounded-3xl max-w-3xl w-full p-6 sm:p-8 space-y-6 shadow-2xl relative my-auto">
        
        {/* Header */}
        <div className="flex items-start justify-between">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono font-bold text-indigo-400 uppercase">
                EXPORT &amp; SUBMISSION CENTER
              </span>
              <span className="text-xs font-mono text-neutral-500">TASK 1</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-bold text-white font-display mt-0.5">
              Export Internship Deliverables
            </h2>
            <p className="text-xs text-neutral-400 mt-1">
              Export your complete project as a formatted academic Markdown report, or print the entire 14-slide presentation deck to PDF.
            </p>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-400 hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab selection */}
        <div className="flex items-center gap-2 border-b border-neutral-800 pb-2">
          <button
            onClick={() => setActiveFormat('markdown')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors ${
              activeFormat === 'markdown' ? 'bg-indigo-600 text-white' : 'text-neutral-400 hover:text-white'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Complete Written Report (Markdown)</span>
          </button>
          <button
            onClick={() => setActiveFormat('presentation')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors ${
              activeFormat === 'presentation' ? 'bg-indigo-600 text-white' : 'text-neutral-400 hover:text-white'
            }`}
          >
            <Printer className="w-3.5 h-3.5" />
            <span>14-Slide PDF Deck</span>
          </button>
        </div>

        {/* Content Box */}
        {activeFormat === 'markdown' ? (
          <div className="space-y-3">
            <div className="flex items-center justify-between text-xs">
              <span className="text-neutral-400">Ready for submission to internship portal or supervisor</span>
              <button
                onClick={handleCopy}
                className="px-3 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-white font-mono flex items-center gap-1.5 transition-colors"
              >
                {copiedReport ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedReport ? 'Copied to Clipboard!' : 'Copy Full Report'}</span>
              </button>
            </div>

            <div className="h-80 overflow-y-auto bg-neutral-950 p-4 rounded-2xl border border-neutral-800 font-mono text-[11px] text-neutral-300 leading-relaxed whitespace-pre-wrap select-all">
              {reportMarkdown}
            </div>
          </div>
        ) : (
          <div className="space-y-4 py-4 text-center">
            <div className="w-16 h-16 rounded-2xl bg-indigo-500/10 text-indigo-400 flex items-center justify-center mx-auto">
              <Printer className="w-8 h-8" />
            </div>
            <div className="space-y-1">
              <h3 className="text-base font-bold text-white font-display">
                Print or Save All 14 Slides as PDF
              </h3>
              <p className="text-xs text-neutral-400 max-w-md mx-auto">
                Formatted with clean CSS print rules, standard page breaks per slide, speaker notes, and high-contrast vector graphics.
              </p>
            </div>

            <div className="pt-2">
              <button
                onClick={handlePrint}
                className="px-6 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs inline-flex items-center gap-2 shadow-lg shadow-indigo-600/30"
              >
                <Printer className="w-4 h-4" />
                <span>Launch Print Dialog (Save as PDF)</span>
              </button>
            </div>
          </div>
        )}

        {/* Footer */}
        <div className="flex items-center justify-between pt-3 border-t border-neutral-800 text-xs text-neutral-500">
          <span>TASK 1: LOGO REDESIGN — Senior Brand Identity Specialist</span>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-xs font-medium"
          >
            Close
          </button>
        </div>

      </div>
    </div>
  );
};
