import React, { useState } from 'react';
import { 
  ZoomIn, 
  Grid3X3, 
  AlertTriangle, 
  ShieldCheck, 
  Sparkles, 
  ArrowRight, 
  Palette, 
  Type, 
  Layers, 
  Scale, 
  Eye, 
  CheckCircle2, 
  XCircle, 
  Maximize2 
} from 'lucide-react';
import { CaseStudy } from '../types/brand';

interface OriginalAnalysisProps {
  caseStudy: CaseStudy;
  onProceedToRedesigns: () => void;
}

export const OriginalAnalysis: React.FC<OriginalAnalysisProps> = ({
  caseStudy,
  onProceedToRedesigns,
}) => {
  const { analysis } = caseStudy;
  const [zoomLevel, setZoomLevel] = useState<number>(1);
  const [showGrid, setShowGrid] = useState<boolean>(true);
  const [bgMode, setBgMode] = useState<'white' | 'checker' | 'dark'>('white');
  const [activeTab, setActiveTab] = useState<'overview' | 'breakdown' | 'scalability'>('overview');

  const bgClasses = {
    white: 'bg-white',
    checker: 'bg-[radial-gradient(#e5e7eb_1px,transparent_1px)] [background-size:12px_12px] bg-slate-50',
    dark: 'bg-neutral-900'
  };

  return (
    <div className="space-y-8 animate-fade-in">
      
      {/* Top Banner & Context */}
      <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-6 sm:p-8">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono font-medium px-2 py-0.5 rounded bg-amber-500/10 text-amber-400 border border-amber-500/20">
                PHASE 1: DIAGNOSTIC AUDIT
              </span>
              <span className="text-xs text-neutral-400 font-mono">
                {analysis.established} · {analysis.industry}
              </span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight font-display">
              Original Logo Analysis: {analysis.brandName}
            </h2>
            <p className="text-neutral-400 text-sm max-w-3xl leading-relaxed">
              {analysis.executiveSummary}
            </p>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={onProceedToRedesigns}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-medium text-sm transition-all shadow-lg shadow-indigo-600/20 hover:scale-[1.02]"
            >
              <span>Explore 3 Redesign Concepts</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Main Visual Workbench & Scalability Stress Test */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Column: Visual Inspector (7 cols) */}
        <div className="lg:col-span-7 space-y-4">
          <div className="bg-neutral-900 border border-neutral-800 rounded-2xl overflow-hidden shadow-xl">
            
            {/* Viewport Top Bar Controls */}
            <div className="px-4 py-3 bg-neutral-850 border-b border-neutral-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-rose-500/80"></span>
                <span className="w-2.5 h-2.5 rounded-full bg-amber-500/80"></span>
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500/80"></span>
                <span className="ml-2 text-xs font-mono text-neutral-400 font-medium">Original Asset Inspector</span>
              </div>

              {/* Viewport Toolbar */}
              <div className="flex items-center gap-2">
                {/* Background Switcher */}
                <div className="flex items-center bg-neutral-900 rounded-lg p-0.5 border border-neutral-800 text-xs">
                  <button
                    onClick={() => setBgMode('white')}
                    className={`px-2 py-1 rounded ${bgMode === 'white' ? 'bg-neutral-800 text-white font-medium' : 'text-neutral-400'}`}
                  >
                    White
                  </button>
                  <button
                    onClick={() => setBgMode('checker')}
                    className={`px-2 py-1 rounded ${bgMode === 'checker' ? 'bg-neutral-800 text-white font-medium' : 'text-neutral-400'}`}
                  >
                    Grid
                  </button>
                  <button
                    onClick={() => setBgMode('dark')}
                    className={`px-2 py-1 rounded ${bgMode === 'dark' ? 'bg-neutral-800 text-white font-medium' : 'text-neutral-400'}`}
                  >
                    Dark
                  </button>
                </div>

                {/* Grid Overlay Toggle */}
                <button
                  onClick={() => setShowGrid(!showGrid)}
                  className={`p-1.5 rounded-lg border text-xs flex items-center gap-1 transition-colors ${
                    showGrid 
                      ? 'bg-indigo-600/20 text-indigo-300 border-indigo-500/40' 
                      : 'bg-neutral-900 text-neutral-400 border-neutral-800 hover:text-white'
                  }`}
                  title="Toggle Diagnostic Grid Guides"
                >
                  <Grid3X3 className="w-3.5 h-3.5" />
                  <span className="text-[11px] hidden sm:inline">Guides</span>
                </button>

                {/* Zoom Controls */}
                <div className="flex items-center bg-neutral-900 rounded-lg p-0.5 border border-neutral-800 text-xs">
                  <button
                    onClick={() => setZoomLevel(1)}
                    className={`px-2 py-1 rounded ${zoomLevel === 1 ? 'bg-neutral-800 text-white' : 'text-neutral-400'}`}
                  >
                    1×
                  </button>
                  <button
                    onClick={() => setZoomLevel(1.5)}
                    className={`px-2 py-1 rounded ${zoomLevel === 1.5 ? 'bg-neutral-800 text-white' : 'text-neutral-400'}`}
                  >
                    1.5×
                  </button>
                  <button
                    onClick={() => setZoomLevel(2)}
                    className={`px-2 py-1 rounded ${zoomLevel === 2 ? 'bg-neutral-800 text-white' : 'text-neutral-400'}`}
                  >
                    2×
                  </button>
                </div>
              </div>
            </div>

            {/* Visual Canvas Area */}
            <div className={`relative min-h-[340px] flex items-center justify-center p-8 overflow-hidden transition-colors ${bgClasses[bgMode]}`}>
              
              {/* Diagnostic Grid Guides (Golden Ratio / Alignment) */}
              {showGrid && (
                <div className="absolute inset-0 pointer-events-none opacity-30">
                  <div className="w-full h-full border border-indigo-400/30 grid grid-cols-3 grid-rows-3">
                    <div className="border-r border-b border-indigo-400/20"></div>
                    <div className="border-r border-b border-indigo-400/20"></div>
                    <div className="border-b border-indigo-400/20"></div>
                    <div className="border-r border-b border-indigo-400/20"></div>
                    <div className="border-r border-b border-indigo-400/20"></div>
                    <div className="border-b border-indigo-400/20"></div>
                    <div className="border-r border-indigo-400/20"></div>
                    <div className="border-r border-indigo-400/20"></div>
                    <div></div>
                  </div>
                  {/* Center Crosshair */}
                  <div className="absolute left-1/2 top-0 bottom-0 w-px bg-rose-400/40 -translate-x-1/2"></div>
                  <div className="absolute top-1/2 left-0 right-0 h-px bg-rose-400/40 -translate-y-1/2"></div>
                </div>
              )}

              {/* Render Original Logo Asset */}
              <div 
                className="transition-transform duration-200 max-w-full max-h-[260px] flex items-center justify-center"
                style={{ transform: `scale(${zoomLevel})` }}
              >
                {analysis.isSvg ? (
                  <div 
                    className="w-full max-w-md h-auto drop-shadow-sm select-none"
                    dangerouslySetInnerHTML={{ __html: analysis.originalSvgOrImg }} 
                  />
                ) : (
                  <img
                    src={analysis.originalSvgOrImg}
                    alt={analysis.brandName}
                    className="max-h-[220px] max-w-full object-contain drop-shadow-sm"
                  />
                )}
              </div>

              {/* Status Ribbon */}
              <div className="absolute bottom-3 left-3 bg-neutral-950/80 backdrop-blur-md px-2.5 py-1 rounded-md border border-neutral-800 text-[11px] font-mono text-neutral-300 flex items-center gap-1.5 shadow">
                <span className="w-2 h-2 rounded-full bg-amber-400"></span>
                <span>Pre-Redesign Original Asset</span>
              </div>
            </div>

            {/* Bottom Insight Bar */}
            <div className="p-4 bg-neutral-900 border-t border-neutral-800 text-xs text-neutral-400 flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-4">
                <span>Composition: <strong className="text-neutral-200">{analysis.shapeComposition.compositionType}</strong></span>
                <span>Type Style: <strong className="text-neutral-200">{analysis.typographyAnalysis.fontType}</strong></span>
              </div>
              <div className="flex items-center gap-1.5 text-rose-400 font-mono text-[11px]">
                <AlertTriangle className="w-3.5 h-3.5" />
                <span>Scalability Score: {analysis.shapeComposition.scalabilityScore}/100</span>
              </div>
            </div>
          </div>

          {/* Scalability Stress Test Strip (16px to 256px) */}
          <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-sm font-bold text-white uppercase tracking-wider font-display flex items-center gap-2">
                  <Scale className="w-4 h-4 text-indigo-400" />
                  Scalability Stress Test (Why it fails at small sizes)
                </h3>
                <p className="text-xs text-neutral-400 mt-0.5">
                  Simulating multi-screen rendering from 16px favicon to desktop headers.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
              
              {/* 16px Favicon */}
              <div className="bg-neutral-950 border border-neutral-800 rounded-xl p-3 flex flex-col items-center justify-between gap-3 text-center">
                <span className="text-[10px] font-mono text-neutral-500">16×16px (Favicon)</span>
                <div className="w-10 h-10 bg-white rounded-lg flex items-center justify-center p-0.5 overflow-hidden border border-neutral-300">
                  <div 
                    className="w-4 h-4 overflow-hidden pointer-events-none flex items-center justify-center"
                    dangerouslySetInnerHTML={{ __html: analysis.originalSvgOrImg }} 
                  />
                </div>
                <span className="text-[10px] text-rose-400 font-medium leading-tight">
                  Illegible blur; details collapse
                </span>
              </div>

              {/* 24px Mobile App Icon */}
              <div className="bg-neutral-950 border border-neutral-800 rounded-xl p-3 flex flex-col items-center justify-between gap-3 text-center">
                <span className="text-[10px] font-mono text-neutral-500">24×24px (Mobile Bar)</span>
                <div className="w-10 h-10 bg-white rounded-lg flex items-center justify-center p-0.5 overflow-hidden border border-neutral-300">
                  <div 
                    className="w-6 h-6 overflow-hidden pointer-events-none flex items-center justify-center"
                    dangerouslySetInnerHTML={{ __html: analysis.originalSvgOrImg }} 
                  />
                </div>
                <span className="text-[10px] text-rose-400 font-medium leading-tight">
                  Text hairlines disappear
                </span>
              </div>

              {/* 32px App Header */}
              <div className="bg-neutral-950 border border-neutral-800 rounded-xl p-3 flex flex-col items-center justify-between gap-3 text-center">
                <span className="text-[10px] font-mono text-neutral-500">32×32px (App Header)</span>
                <div className="w-12 h-10 bg-white rounded-lg flex items-center justify-center p-1 overflow-hidden border border-neutral-300">
                  <div 
                    className="w-8 h-8 overflow-hidden pointer-events-none flex items-center justify-center"
                    dangerouslySetInnerHTML={{ __html: analysis.originalSvgOrImg }} 
                  />
                </div>
                <span className="text-[10px] text-amber-400 font-medium leading-tight">
                  Subtext unreadable
                </span>
              </div>

              {/* 64px Web Header */}
              <div className="bg-neutral-950 border border-neutral-800 rounded-xl p-3 flex flex-col items-center justify-between gap-3 text-center">
                <span className="text-[10px] font-mono text-neutral-500">64px (Nav Header)</span>
                <div className="w-16 h-10 bg-white rounded-lg flex items-center justify-center p-1 overflow-hidden border border-neutral-300">
                  <div 
                    className="w-14 h-8 overflow-hidden pointer-events-none flex items-center justify-center"
                    dangerouslySetInnerHTML={{ __html: analysis.originalSvgOrImg }} 
                  />
                </div>
                <span className="text-[10px] text-amber-300 font-medium leading-tight">
                  Heavy visual crowding
                </span>
              </div>

              {/* 128px Print / Display */}
              <div className="bg-neutral-950 border border-neutral-800 rounded-xl p-3 flex flex-col items-center justify-between gap-3 text-center col-span-2 sm:col-span-1">
                <span className="text-[10px] font-mono text-neutral-500">128px (Hero/Print)</span>
                <div className="w-full h-10 bg-white rounded-lg flex items-center justify-center p-1 overflow-hidden border border-neutral-300">
                  <div 
                    className="w-20 h-8 overflow-hidden pointer-events-none flex items-center justify-center"
                    dangerouslySetInnerHTML={{ __html: analysis.originalSvgOrImg }} 
                  />
                </div>
                <span className="text-[10px] text-neutral-400 font-medium leading-tight">
                  Dated gradient visible
                </span>
              </div>

            </div>
          </div>
        </div>

        {/* Right Column: Strategic Audit Breakdown Cards (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          
          {/* Card 1: What Should Be Preserved vs What Should Be Improved */}
          <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-6 space-y-4">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider font-display flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              Core Brand Equity: Preserve vs. Improve
            </h3>

            {/* Preserve */}
            <div className="bg-emerald-950/20 border border-emerald-500/20 rounded-xl p-4 space-y-2">
              <div className="flex items-center gap-2 text-emerald-400 font-semibold text-xs uppercase tracking-wider">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>What Must Be Preserved (Core Equity)</span>
              </div>
              <ul className="space-y-1.5 text-xs text-neutral-300">
                {analysis.whatToPreserve.map((item, idx) => (
                  <li key={idx} className="flex items-start gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 mt-1.5 shrink-0" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Improve */}
            <div className="bg-rose-950/20 border border-rose-500/20 rounded-xl p-4 space-y-2">
              <div className="flex items-center gap-2 text-rose-400 font-semibold text-xs uppercase tracking-wider">
                <XCircle className="w-4 h-4 shrink-0" />
                <span>What Must Be Improved (Pain Points)</span>
              </div>
              <ul className="space-y-1.5 text-xs text-neutral-300">
                {analysis.whatToImprove.map((item, idx) => (
                  <li key={idx} className="flex items-start gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-rose-400 mt-1.5 shrink-0" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Card 2: Original Colors Breakdown */}
          <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-6 space-y-3">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider font-display flex items-center gap-2">
              <Palette className="w-4 h-4 text-indigo-400" />
              Original Color Palette Evaluation
            </h3>
            <p className="text-xs text-neutral-400">
              {analysis.colorsAnalysis.harmonyCritique}
            </p>
            <div className="grid grid-cols-2 gap-2 pt-1">
              {analysis.colorsAnalysis.originalColors.map((color, idx) => (
                <div key={idx} className="bg-neutral-950 border border-neutral-800 rounded-lg p-2.5 flex items-center gap-3">
                  <div 
                    className="w-7 h-7 rounded-md border border-white/20 shrink-0 shadow-inner"
                    style={{ backgroundColor: color.hex }}
                  />
                  <div className="min-w-0">
                    <div className="text-xs font-semibold text-white truncate">{color.name}</div>
                    <div className="text-[11px] font-mono text-neutral-400">{color.hex}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Card 3: Brand Personality Radar */}
          <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-6 space-y-3">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider font-display flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-400" />
              Brand Personality &amp; Perception Gap
            </h3>
            
            <div className="grid grid-cols-2 gap-3 pt-1">
              <div className="bg-neutral-950 p-3 rounded-xl border border-neutral-800">
                <span className="text-[10px] font-mono text-neutral-500 uppercase block mb-1">Current Perception</span>
                <div className="flex flex-wrap gap-1">
                  {analysis.brandPersonality.perceivedTraits.map((trait, i) => (
                    <span key={i} className="text-[11px] px-2 py-0.5 rounded bg-neutral-800 text-neutral-300 font-medium">
                      {trait}
                    </span>
                  ))}
                </div>
              </div>

              <div className="bg-neutral-950 p-3 rounded-xl border border-neutral-800">
                <span className="text-[10px] font-mono text-indigo-400 uppercase block mb-1">Target Identity</span>
                <div className="flex flex-wrap gap-1">
                  {analysis.brandPersonality.intendedTraits.map((trait, i) => (
                    <span key={i} className="text-[11px] px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300 font-medium">
                      {trait}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            <p className="text-xs text-neutral-400 pt-1 leading-relaxed">
              <strong className="text-neutral-200">Strategic Gap: </strong>
              {analysis.brandPersonality.personalityGap}
            </p>
          </div>

        </div>

      </div>

      {/* Comprehensive 8-Point Analysis Grid */}
      <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-6 sm:p-8 space-y-6">
        <div>
          <span className="text-xs font-mono text-indigo-400 uppercase tracking-wider font-semibold">
            PROFESSIONAL SPECIFICATION
          </span>
          <h3 className="text-xl font-bold text-white tracking-tight font-display mt-0.5">
            Full 8-Point Senior Designer Audit Breakdown
          </h3>
          <p className="text-xs text-neutral-400 mt-1">
            Exhaustive structural review covering iconography, typography, geometry, contrast, and industrial reproduction.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          
          {/* 1. Symbol/Icon */}
          <div className="bg-neutral-950 border border-neutral-800/80 rounded-xl p-4 space-y-2">
            <div className="flex items-center gap-2 text-indigo-400 font-bold text-xs uppercase tracking-wider">
              <Layers className="w-4 h-4" />
              <span>1. Symbol &amp; Iconography</span>
            </div>
            <p className="text-xs text-neutral-300 leading-relaxed">
              {analysis.symbolAnalysis.description}
            </p>
            <div className="text-[11px] text-neutral-400 pt-1 border-t border-neutral-850">
              <span className="font-semibold text-neutral-200">Metaphor: </span>
              {analysis.symbolAnalysis.metaphor}
            </div>
          </div>

          {/* 2. Typography */}
          <div className="bg-neutral-950 border border-neutral-800/80 rounded-xl p-4 space-y-2">
            <div className="flex items-center gap-2 text-sky-400 font-bold text-xs uppercase tracking-wider">
              <Type className="w-4 h-4" />
              <span>2. Typography &amp; Lettering</span>
            </div>
            <div className="text-xs font-mono text-neutral-400">{analysis.typographyAnalysis.fontType}</div>
            <p className="text-xs text-neutral-300 leading-relaxed">
              {analysis.typographyAnalysis.critique}
            </p>
            <div className="text-[11px] text-rose-400 pt-1 border-t border-neutral-850">
              <span className="font-semibold">Issue: </span>
              {analysis.typographyAnalysis.legibilityIssue}
            </div>
          </div>

          {/* 3. Colors */}
          <div className="bg-neutral-950 border border-neutral-800/80 rounded-xl p-4 space-y-2">
            <div className="flex items-center gap-2 text-amber-400 font-bold text-xs uppercase tracking-wider">
              <Palette className="w-4 h-4" />
              <span>3. Color Harmony &amp; Ratio</span>
            </div>
            <p className="text-xs text-neutral-300 leading-relaxed">
              {analysis.colorsAnalysis.harmonyCritique}
            </p>
            <div className="text-[11px] text-amber-300 pt-1 border-t border-neutral-850">
              <span className="font-semibold">Contrast: </span>
              {analysis.colorsAnalysis.contrastIssue}
            </div>
          </div>

          {/* 4. Shape & Composition */}
          <div className="bg-neutral-950 border border-neutral-800/80 rounded-xl p-4 space-y-2">
            <div className="flex items-center gap-2 text-emerald-400 font-bold text-xs uppercase tracking-wider">
              <Scale className="w-4 h-4" />
              <span>4. Shape &amp; Composition</span>
            </div>
            <p className="text-xs text-neutral-300 leading-relaxed">
              {analysis.shapeComposition.balance}
            </p>
            <div className="text-[11px] text-neutral-400 pt-1 border-t border-neutral-850">
              <span className="font-semibold text-neutral-200">Scalability: </span>
              {analysis.shapeComposition.scalabilityScore}/100 rating
            </div>
          </div>

        </div>

        {/* Strengths & Weaknesses 2-Column */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
          
          <div className="bg-neutral-950 border border-neutral-800 rounded-xl p-5 space-y-3">
            <div className="flex items-center gap-2 text-emerald-400 font-semibold text-xs uppercase tracking-wider">
              <CheckCircle2 className="w-4 h-4" />
              <span>5. Verified Strengths to Retain</span>
            </div>
            <ul className="space-y-2 text-xs text-neutral-300">
              {analysis.strengths.map((str, idx) => (
                <li key={idx} className="flex items-start gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 mt-1.5 shrink-0" />
                  <span>{str}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="bg-neutral-950 border border-neutral-800 rounded-xl p-5 space-y-3">
            <div className="flex items-center gap-2 text-rose-400 font-semibold text-xs uppercase tracking-wider">
              <AlertTriangle className="w-4 h-4" />
              <span>6. Fatal Structural Weaknesses</span>
            </div>
            <ul className="space-y-2 text-xs text-neutral-300">
              {analysis.weaknesses.map((weak, idx) => (
                <li key={idx} className="flex items-start gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-rose-400 mt-1.5 shrink-0" />
                  <span>{weak}</span>
                </li>
              ))}
            </ul>
          </div>

        </div>

        {/* Bottom CTA to Redesigns */}
        <div className="pt-4 flex flex-col sm:flex-row items-center justify-between gap-4 border-t border-neutral-800">
          <div className="text-xs text-neutral-400">
            Audit complete. Senior designer directive: Proceed to 3 distinct redesign directions.
          </div>
          <button
            onClick={onProceedToRedesigns}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-sm transition-all shadow-lg shadow-indigo-600/20"
          >
            <span>Proceed to Step 2: Compare 3 Redesign Versions</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

      </div>

    </div>
  );
};
