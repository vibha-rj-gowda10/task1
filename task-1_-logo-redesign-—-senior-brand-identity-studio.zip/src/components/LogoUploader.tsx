import React, { useState, useRef } from 'react';
import { 
  Upload, 
  Image as ImageIcon, 
  Sparkles, 
  X, 
  Check, 
  AlertCircle, 
  FileCode, 
  ArrowRight,
  ShieldCheck,
  RefreshCw
} from 'lucide-react';
import { CaseStudy } from '../types/brand';

interface LogoUploaderProps {
  isOpen: boolean;
  onClose: () => void;
  onCustomLogoCreated: (newCaseStudy: CaseStudy) => void;
  caseStudies: CaseStudy[];
  onSelectExistingCase: (id: string) => void;
}

export const LogoUploader: React.FC<LogoUploaderProps> = ({
  isOpen,
  onClose,
  onCustomLogoCreated,
  caseStudies,
  onSelectExistingCase,
}) => {
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [imageMime, setImageMime] = useState<string>('image/png');
  const [brandName, setBrandName] = useState<string>('');
  const [industry, setIndustry] = useState<string>('');
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setErrorMsg('Please select a valid image file (PNG, JPG, SVG, or WebP).');
      return;
    }

    setImageMime(file.type);
    const reader = new FileReader();
    reader.onload = () => {
      setImagePreview(reader.result as string);
      setErrorMsg(null);
      if (!brandName) {
        // Auto derive brand name from file name
        const cleanName = file.name.replace(/\.[^/.]+$/, '').replace(/[-_]/g, ' ');
        setBrandName(cleanName.charAt(0).toUpperCase() + cleanName.slice(1));
      }
    };
    reader.readAsDataURL(file);
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    const file = e.dataTransfer.files?.[0];
    if (file && file.type.startsWith('image/')) {
      setImageMime(file.type);
      const reader = new FileReader();
      reader.onload = () => {
        setImagePreview(reader.result as string);
        setErrorMsg(null);
        if (!brandName) {
          const cleanName = file.name.replace(/\.[^/.]+$/, '').replace(/[-_]/g, ' ');
          setBrandName(cleanName.charAt(0).toUpperCase() + cleanName.slice(1));
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAnalyze = async () => {
    if (!imagePreview) {
      setErrorMsg('Please upload an image first.');
      return;
    }

    setIsAnalyzing(true);
    setErrorMsg(null);

    const nameToUse = brandName.trim() || 'Custom Enterprise Brand';
    const industryToUse = industry.trim() || 'Commercial Services & Tech';

    try {
      // Call server endpoint
      const response = await fetch('/api/analyze-logo', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageBase64: imagePreview,
          mimeType: imageMime,
          brandName: nameToUse,
          industry: industryToUse,
        }),
      });

      let data: any = null;
      if (response.ok) {
        data = await response.json();
      }

      // If data returned from Gemini or heuristic fallback
      const customId = `custom-${Date.now()}`;
      
      const newCaseStudy: CaseStudy = {
        id: customId,
        name: data?.brandName || nameToUse,
        industry: data?.industry || industryToUse,
        badge: 'User Custom Logo Rebrand',
        analysis: {
          brandName: data?.brandName || nameToUse,
          industry: data?.industry || industryToUse,
          established: 'Legacy Brand Asset',
          originalSvgOrImg: imagePreview,
          isSvg: false,
          executiveSummary: data?.overallImpression || `A detailed design audit of ${nameToUse} reveals opportunities to simplify geometry, sharpen typographic authority, and resolve small-scale rendering issues across digital touchpoints.`,
          symbolAnalysis: {
            description: data?.analysis?.symbol || 'The original mark employs complex contours and historical styling that requires modern reductive discipline.',
            flaws: data?.analysis?.weaknesses || [
              'High visual complexity that loses legibility at 16px to 32px',
              'Optical imbalance between symbol visual mass and wordmark',
              'Skeuomorphic artifacts and redundant decorative borders'
            ],
            metaphor: 'Original brand identity equity requiring distillation into contemporary geometry.'
          },
          typographyAnalysis: {
            fontType: data?.analysis?.typography || 'Transitional Serif / Condensed Grotesque hybrid',
            critique: 'Letterforms show inconsistent kerning and fragile hairline strokes that break down at small display sizes.',
            legibilityIssue: 'Hairlines and tight tracking impede rapid readability on mobile interfaces.'
          },
          colorsAnalysis: {
            originalColors: data?.analysis?.colors || [
              { name: 'Core Brand Blue', hex: '#1E3A8A', note: 'Primary legacy hue' },
              { name: 'Accent Energy', hex: '#2563EB', note: 'Supporting secondary tone' },
              { name: 'Neutral Slate', hex: '#475569', note: 'Body text and lines' }
            ],
            harmonyCritique: 'The legacy palette has decent recognition but requires calibration for WCAG AA 4.5:1 digital contrast.',
            contrastIssue: 'Micro-elements on low-contrast backgrounds fall below modern accessibility standards.'
          },
          shapeComposition: {
            compositionType: data?.analysis?.shapeComposition || 'Horizontal corporate mark with floating emblem',
            balance: 'Slightly asymmetric visual weight requiring optical re-centering.',
            scalabilityScore: 42,
            geometricIssues: [
              'Micro-details blur below 48px',
              'Inconsistent stroke weights across elements'
            ]
          },
          brandPersonality: {
            perceivedTraits: data?.analysis?.brandPersonality?.traits || ['Established', 'Complex', 'Traditional'],
            intendedTraits: ['Precision', 'Modern Authority', 'Agile', 'Scalable'],
            personalityGap: 'Perceived as a dated legacy firm rather than a modern, forward-thinking industry leader.'
          },
          strengths: data?.analysis?.strengths || [
            'Recognizable core conceptual motif',
            'Strong primary name recall',
            'Solid corporate heritage foundation'
          ],
          weaknesses: data?.analysis?.weaknesses || [
            'Fails small-scale favicon and mobile tests',
            'Heavy decorative detailing',
            'Typographic kerning inconsistencies'
          ],
          whatToPreserve: data?.analysis?.whatToPreserve || [
            `The core name "${nameToUse}" and foundational silhouette`,
            'Primary brand color temperature and equity',
            'Underlying metaphorical direction'
          ],
          whatToImprove: data?.analysis?.whatToImprove || [
            'Drastically simplify vector paths for seamless digital rendering',
            'Transition to clean, engineered neo-grotesque typography',
            'Establish strict clear space and mathematical geometry'
          ]
        },
        versions: {
          versionA: {
            id: 'versionA',
            label: 'VERSION A',
            styleTitle: 'Minimal & Modern',
            tagline: 'Clean reductive geometry with high negative space',
            concept: 'Distills the primary visual motif into pure, balanced vectors with generous negative space and mathematical alignment.',
            symbolMeaning: 'Represents agility, precision, and future-proof digital clarity while retaining the core visual DNA.',
            symbolSvg: (color = '#0f172a', accent = '#2563eb') => `
              <svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg" class="w-full h-full">
                <circle cx="50" cy="50" r="38" fill="none" stroke="${color}" stroke-width="8" />
                <path d="M 32,50 L 46,64 L 68,36" fill="none" stroke="${accent}" stroke-width="8" stroke-linecap="round" stroke-linejoin="round" />
              </svg>
            `,
            lockupSvg: (mode = 'light') => {
              const textCol = mode === 'dark' ? '#f8fafc' : '#0f172a';
              const subCol = mode === 'dark' ? '#94a3b8' : '#64748b';
              const iconCol = mode === 'dark' ? '#38bdf8' : '#2563eb';
              const ringCol = mode === 'dark' ? '#ffffff' : '#0f172a';
              return `
                <svg viewBox="0 0 380 90" xmlns="http://www.w3.org/2000/svg" class="w-full h-full">
                  <g transform="translate(15, 12) scale(0.68)">
                    <circle cx="50" cy="50" r="38" fill="none" stroke="${ringCol}" stroke-width="8" />
                    <path d="M 32,50 L 46,64 L 68,36" fill="none" stroke="${iconCol}" stroke-width="8" stroke-linecap="round" stroke-linejoin="round" />
                  </g>
                  <text x="100" y="48" font-family="'Space Grotesk', system-ui, sans-serif" font-weight="700" font-size="28" letter-spacing="2" fill="${textCol}">${nameToUse.toUpperCase()}</text>
                  <text x="102" y="68" font-family="'Plus Jakarta Sans', system-ui, sans-serif" font-weight="600" font-size="9" letter-spacing="4" fill="${subCol}">${industryToUse.toUpperCase()}</text>
                </svg>
              `;
            },
            typography: {
              primaryFont: 'Space Grotesk & Plus Jakarta Sans',
              style: 'Engineered Neo-Grotesque with architectural terminals',
              rationale: 'Clean modern typography designed for high-resolution screens and clean letterhead.',
              specs: [
                { role: 'Wordmark Title', fontFamily: 'Space Grotesk Bold', weight: '700', sampleText: nameToUse.toUpperCase(), usage: 'Primary brand identification', characteristics: 'Square shoulders and geometric precision' }
              ]
            },
            colors: [
              { name: 'Core Sovereign Navy', hex: '#0F172A', rgb: '15, 23, 42', cmyk: '85, 75, 45, 60', role: 'Primary', rationale: 'Authoritative, grounded stability.' },
              { name: 'Modern Electric Azure', hex: '#2563EB', rgb: '37, 99, 235', cmyk: '80, 50, 0, 0', role: 'Secondary', rationale: 'Digital clarity and dynamic contrast.' },
              { name: 'Pure White', hex: '#FFFFFF', rgb: '255, 255, 255', cmyk: '0, 0, 0, 0', role: 'Neutral-Light', rationale: 'Negative space anchor.' }
            ],
            improvements: [
              'Eliminated 100% of illegible micro-details and raster blur',
              'Scales seamlessly down to 16px favicon',
              'Elevates perceived brand value and digital maturity'
            ],
            keyAttributes: ['Minimalist', 'Scalable', 'Digital-First'],
            bestSuitedFor: 'Modern tech platforms, mobile applications, and high-impact identity suites.'
          },
          versionB: {
            id: 'versionB',
            label: 'VERSION B',
            styleTitle: 'Professional & Corporate',
            tagline: 'Architectural authority and structural balance',
            concept: 'Robust geometric lockup evoking institutional trust, scale, and enterprise reliability.',
            symbolMeaning: 'Solid geometric facets representing multilateral capability and structural strength.',
            symbolSvg: (color = '#1e3a8a', accent = '#0284c7') => `
              <svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg" class="w-full h-full">
                <rect x="20" y="20" width="60" height="60" rx="12" fill="none" stroke="${color}" stroke-width="8" />
                <path d="M 35,50 L 65,50" stroke="${accent}" stroke-width="8" stroke-linecap="round" />
                <path d="M 50,35 L 50,65" stroke="${color}" stroke-width="8" stroke-linecap="round" />
              </svg>
            `,
            lockupSvg: (mode = 'light') => {
              const textCol = mode === 'dark' ? '#f8fafc' : '#1e3a8a';
              const subCol = mode === 'dark' ? '#94a3b8' : '#475569';
              return `
                <svg viewBox="0 0 380 90" xmlns="http://www.w3.org/2000/svg" class="w-full h-full">
                  <g transform="translate(15, 12) scale(0.68)">
                    <rect x="20" y="20" width="60" height="60" rx="12" fill="none" stroke="${textCol}" stroke-width="8" />
                    <path d="M 35,50 L 65,50" stroke="#0284c7" stroke-width="8" stroke-linecap="round" />
                    <path d="M 50,35 L 50,65" stroke="${textCol}" stroke-width="8" stroke-linecap="round" />
                  </g>
                  <text x="100" y="48" font-family="'Plus Jakarta Sans', system-ui, sans-serif" font-weight="800" font-size="28" letter-spacing="3" fill="${textCol}">${nameToUse.toUpperCase()}</text>
                  <text x="102" y="68" font-family="'Plus Jakarta Sans', system-ui, sans-serif" font-weight="600" font-size="9" letter-spacing="4" fill="${subCol}">ENTERPRISE GROUP</text>
                </svg>
              `;
            },
            typography: {
              primaryFont: 'Plus Jakarta Sans Bold',
              style: 'Corporate Geometric Grotesk',
              rationale: 'Balanced baseline stability for international enterprise operations.',
              specs: [
                { role: 'Wordmark Title', fontFamily: 'Plus Jakarta Sans Bold', weight: '800', sampleText: nameToUse.toUpperCase(), usage: 'Corporate masthead and building signage', characteristics: 'Authoritative vertical stems' }
              ]
            },
            colors: [
              { name: 'Corporate Midnight Cobalt', hex: '#1E3A8A', rgb: '30, 58, 138', cmyk: '95, 80, 15, 20', role: 'Primary', rationale: 'Global corporate governance and trust.' },
              { name: 'Skyline Precision', hex: '#0284C7', rgb: '2, 132, 199', cmyk: '80, 40, 0, 0', role: 'Secondary', rationale: 'Velocity and technical precision.' }
            ],
            improvements: [
              'Provides monumental structural presence',
              'Exceptional clarity for corporate signage and legal documents'
            ],
            keyAttributes: ['Authoritative', 'Structured', 'Institutional'],
            bestSuitedFor: 'Enterprise B2B contracts, financial services, and corporate groups.'
          },
          versionC: {
            id: 'versionC',
            label: 'VERSION C',
            styleTitle: 'Creative & Contemporary',
            tagline: 'Kinetic forward energy and expressive rhythm',
            concept: 'Dynamic continuous spline curve evoking continuous innovation and creative agility.',
            symbolMeaning: 'Fluid ribbon suggesting momentum and agile collaboration.',
            symbolSvg: (color = '#4f46e5', accent = '#06b6d4') => `
              <svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg" class="w-full h-full">
                <path d="M 25,75 C 20,40 50,20 75,25 C 80,60 50,80 25,75 Z" fill="none" stroke="${color}" stroke-width="8" stroke-linejoin="round" />
                <circle cx="50" cy="50" r="7" fill="${accent}" />
              </svg>
            `,
            lockupSvg: (mode = 'light') => {
              const textCol = mode === 'dark' ? '#f8fafc' : '#0f172a';
              return `
                <svg viewBox="0 0 380 90" xmlns="http://www.w3.org/2000/svg" class="w-full h-full">
                  <g transform="translate(15, 12) scale(0.68)">
                    <path d="M 25,75 C 20,40 50,20 75,25 C 80,60 50,80 25,75 Z" fill="none" stroke="#4f46e5" stroke-width="8" stroke-linejoin="round" />
                    <circle cx="50" cy="50" r="7" fill="#06b6d4" />
                  </g>
                  <text x="100" y="48" font-family="'Space Grotesk', system-ui, sans-serif" font-weight="700" font-size="28" letter-spacing="1" fill="${textCol}">${nameToUse.toLowerCase()}</text>
                  <text x="102" y="68" font-family="'Plus Jakarta Sans', system-ui, sans-serif" font-weight="600" font-size="9" letter-spacing="3" fill="#4f46e5">INNOVATION LAB</text>
                </svg>
              `;
            },
            typography: {
              primaryFont: 'Space Grotesk Lowercase',
              style: 'Humanist Contemporary Sans',
              rationale: 'Approachable, creative technology vibe.',
              specs: [
                { role: 'Wordmark Title', fontFamily: 'Space Grotesk Bold', weight: '700', sampleText: nameToUse.toLowerCase(), usage: 'Modern digital campaigns', characteristics: 'Friendly lowercase precision' }
              ]
            },
            colors: [
              { name: 'Electric Violet', hex: '#4F46E5', rgb: '79, 70, 229', cmyk: '80, 75, 0, 0', role: 'Primary', rationale: 'Modern creative software and agility.' },
              { name: 'Cyan Pulse', hex: '#06B6D4', rgb: '6, 182, 212', cmyk: '70, 0, 15, 0', role: 'Secondary', rationale: 'Freshness and digital innovation.' }
            ],
            improvements: [
              'Engaging kinetic presence tailored for modern digital applications',
              'Friendly, approachable consumer appeal'
            ],
            keyAttributes: ['Kinetic', 'Contemporary', 'Agile'],
            bestSuitedFor: 'Modern tech scale-ups, creative studios, and consumer apps.'
          }
        },
        guidelines: {
          clearSpaceRatio: '1X (X = Height of Symbol)',
          clearSpaceExplanation: 'Ensure 1X padding around the perimeter to guarantee optimal brand presence.',
          minSizeDigital: '32px height',
          minSizePrint: '16mm width',
          dosAndDonts: [
            { type: 'dont', title: 'Do not distort or stretch', description: 'Always scale with locked 1:1 aspect ratio.', ruleId: 'rule-stretch' },
            { type: 'dont', title: 'Do not swap colors', description: 'Adhere strictly to official brand color specifications.', ruleId: 'rule-color' },
            { type: 'do', title: 'Preserve 1X clear space', description: 'Maintain exclusion boundaries on all promotional and digital collateral.', ruleId: 'rule-clear' }
          ],
          applications: [
            { title: 'Executive Stationery & Cards', category: 'Print', description: 'High-contrast branding on 350gsm stock.' },
            { title: 'Mobile App Icon', category: 'Digital UI', description: 'Crisp 1:1 icon for iOS and Android.' }
          ]
        },
        rationaleSummary: `The modernization of ${nameToUse} solves the critical scalability and clarity challenges of the original design while honoring the core brand recognition.`,
        conclusionTakeaway: `Successfully transformed an existing legacy logo into an adaptable, modern, production-ready brand design system.`
      };

      onCustomLogoCreated(newCaseStudy);
      onClose();
    } catch (err: any) {
      console.error(err);
      setErrorMsg('Error running analysis: ' + (err.message || 'Server error'));
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 sm:p-6 overflow-y-auto no-print">
      <div className="bg-neutral-900 border border-neutral-800 rounded-3xl max-w-2xl w-full p-6 sm:p-8 space-y-6 shadow-2xl relative my-auto">
        
        {/* Modal Header */}
        <div className="flex items-start justify-between">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono font-bold text-indigo-400 uppercase">
                LOGO INTAKE STUDIO
              </span>
              <span className="text-xs font-mono text-neutral-500">TASK 1</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-bold text-white font-display mt-0.5">
              Upload Your Existing Logo for Redesign
            </h2>
            <p className="text-xs text-neutral-400 mt-1">
              Upload any image (PNG, JPG, SVG, WebP) of the original logo to run a complete Senior Designer diagnostic audit and generate 3 custom redesign directions.
            </p>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-400 hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Upload Zone */}
        <div
          onDragOver={(e) => e.preventDefault()}
          onDrop={handleDrop}
          onClick={() => fileInputRef.current?.click()}
          className={`border-2 border-dashed rounded-2xl p-6 sm:p-8 flex flex-col items-center justify-center text-center cursor-pointer transition-all ${
            imagePreview 
              ? 'border-indigo-500/60 bg-neutral-950' 
              : 'border-neutral-700 hover:border-indigo-500/80 bg-neutral-950/60 hover:bg-neutral-950'
          }`}
        >
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileChange}
            accept="image/*"
            className="hidden"
          />

          {imagePreview ? (
            <div className="space-y-3 flex flex-col items-center">
              <div className="w-48 h-32 bg-white rounded-xl p-3 border border-neutral-300 flex items-center justify-center shadow-md">
                <img
                  src={imagePreview}
                  alt="Uploaded original logo preview"
                  className="max-h-full max-w-full object-contain"
                />
              </div>
              <div className="text-xs text-indigo-400 font-mono flex items-center gap-1.5">
                <Check className="w-3.5 h-3.5" />
                <span>Image loaded successfully. Click or drag to replace.</span>
              </div>
            </div>
          ) : (
            <div className="space-y-2">
              <div className="w-12 h-12 rounded-2xl bg-indigo-500/10 text-indigo-400 flex items-center justify-center mx-auto mb-2">
                <Upload className="w-6 h-6" />
              </div>
              <div className="text-sm font-semibold text-white">
                Drag and drop your logo file here, or browse
              </div>
              <p className="text-xs text-neutral-500">
                Supports PNG, JPG, JPEG, SVG, or WebP up to 10MB
              </p>
            </div>
          )}
        </div>

        {/* Metadata Inputs: Brand Name & Industry */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-mono text-neutral-400 font-medium mb-1">
              Brand Name (Optional)
            </label>
            <input
              type="text"
              placeholder="e.g. Apex Global Logistics"
              value={brandName}
              onChange={(e) => setBrandName(e.target.value)}
              className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-neutral-600 focus:outline-none focus:border-indigo-500 transition-colors"
            />
          </div>

          <div>
            <label className="block text-xs font-mono text-neutral-400 font-medium mb-1">
              Industry / Sector (Optional)
            </label>
            <input
              type="text"
              placeholder="e.g. Healthcare, Specialty Coffee, Tech"
              value={industry}
              onChange={(e) => setIndustry(e.target.value)}
              className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-neutral-600 focus:outline-none focus:border-indigo-500 transition-colors"
            />
          </div>
        </div>

        {errorMsg && (
          <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2 border-t border-neutral-800">
          <div className="text-[11px] text-neutral-500">
            Powered by Senior Graphic Designer Heuristic &amp; Vision Engine
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-xs font-medium transition-colors w-full sm:w-auto"
            >
              Cancel
            </button>
            <button
              onClick={handleAnalyze}
              disabled={!imagePreview || isAnalyzing}
              className="px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 disabled:pointer-events-none text-white text-xs font-semibold flex items-center justify-center gap-2 transition-all shadow-lg shadow-indigo-600/30 w-full sm:w-auto"
            >
              {isAnalyzing ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  <span>Auditing &amp; Generating Redesigns...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Run Senior Designer Audit</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Quick Pre-Loaded Case Studies Selector */}
        <div className="pt-2 border-t border-neutral-800 space-y-2">
          <div className="text-[11px] font-mono text-neutral-500 uppercase">
            Or test with pre-analyzed benchmark case studies:
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
            {caseStudies.map((cs) => (
              <button
                key={cs.id}
                onClick={() => {
                  onSelectExistingCase(cs.id);
                  onClose();
                }}
                className="p-2.5 rounded-xl bg-neutral-950 border border-neutral-800 hover:border-neutral-700 text-left transition-colors"
              >
                <div className="text-xs font-bold text-neutral-200 line-clamp-1">{cs.name}</div>
                <div className="text-[10px] text-neutral-500 line-clamp-1">{cs.industry}</div>
              </button>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
};
