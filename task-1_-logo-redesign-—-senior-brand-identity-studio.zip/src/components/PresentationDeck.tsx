import React, { useState, useEffect } from 'react';
import { 
  ChevronLeft, 
  ChevronRight, 
  Maximize2, 
  Minimize2, 
  Printer, 
  FileText, 
  Copy, 
  Check, 
  MessageSquare, 
  Clock, 
  Sparkles, 
  Layers, 
  Grid, 
  Palette, 
  Type, 
  Award,
  Compass
} from 'lucide-react';
import { CaseStudy, RedesignVersion } from '../types/brand';

interface PresentationDeckProps {
  caseStudy: CaseStudy;
  selectedVersion: RedesignVersion;
  isFullscreen: boolean;
  onToggleFullscreen: () => void;
  onOpenExport: () => void;
}

export const PresentationDeck: React.FC<PresentationDeckProps> = ({
  caseStudy,
  selectedVersion,
  isFullscreen,
  onToggleFullscreen,
  onOpenExport,
}) => {
  const [currentSlideIndex, setCurrentSlideIndex] = useState<number>(0);
  const [showNotes, setShowNotes] = useState<boolean>(false);
  const [showThumbnails, setShowThumbnails] = useState<boolean>(false);
  const [copiedNotes, setCopiedNotes] = useState<boolean>(false);
  const [timerSeconds, setTimerSeconds] = useState<number>(0);
  const [isTimerRunning, setIsTimerRunning] = useState<boolean>(true);

  const { analysis, versions, guidelines } = caseStudy;

  // Presentation Timer
  useEffect(() => {
    let interval: any;
    if (isTimerRunning) {
      interval = setInterval(() => {
        setTimerSeconds(prev => prev + 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isTimerRunning]);

  const formatTimer = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowRight' || e.key === ' ') {
        e.preventDefault();
        setCurrentSlideIndex(prev => Math.min(prev + 1, 13));
      } else if (e.key === 'ArrowLeft') {
        e.preventDefault();
        setCurrentSlideIndex(prev => Math.max(prev - 1, 0));
      } else if (e.key === 'Escape' && isFullscreen) {
        onToggleFullscreen();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isFullscreen, onToggleFullscreen]);

  // Slides configuration (Exact 14 slides)
  const slides = [
    {
      number: 1,
      title: 'Project Title',
      subtitle: 'TASK 1: LOGO REDESIGN — Comprehensive Internship Submission',
      speakerNotes: 'Welcome. Today I am presenting my internship capstone project: Task 1 Logo Redesign. Our primary objective is to take an established commercial identity, diagnose its historical bottlenecks, and deliver a modern, production-grade redesign that elevates brand value while safeguarding original brand recognition.',
      renderContent: () => (
        <div className="h-full flex flex-col justify-between p-8 sm:p-14 text-center sm:text-left relative overflow-hidden">
          <div className="absolute top-0 right-0 w-96 h-96 bg-indigo-600/10 rounded-full blur-3xl pointer-events-none"></div>
          
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono font-bold px-3 py-1 rounded-full bg-indigo-500/20 text-indigo-400 border border-indigo-500/30">
                INTERNSHIP SUBMISSION
              </span>
              <span className="text-xs font-mono text-neutral-400">TERM PROJECT 1</span>
            </div>
            <span className="text-xs font-mono text-neutral-500">Slide 01 / 14</span>
          </div>

          <div className="space-y-4 my-auto max-w-2xl">
            <h1 className="text-4xl sm:text-6xl font-extrabold text-white tracking-tight font-display leading-[1.1]">
              Brand Identity Redesign
            </h1>
            <div className="text-xl sm:text-2xl text-indigo-400 font-semibold font-display">
              Case Study: {caseStudy.name}
            </div>
            <p className="text-neutral-400 text-sm sm:text-base leading-relaxed">
              A comprehensive transition from early-2000s skeuomorphic visual baggage to a precision-engineered, multi-platform brand design system.
            </p>
          </div>

          <div className="pt-8 border-t border-neutral-800 flex flex-wrap items-center justify-between text-xs font-mono text-neutral-400 gap-4">
            <div>
              <span className="text-neutral-500">Candidate Role: </span>
              <strong className="text-neutral-200">Senior Graphic Design Intern</strong>
            </div>
            <div>
              <span className="text-neutral-500">Industry: </span>
              <strong className="text-neutral-200">{caseStudy.industry}</strong>
            </div>
            <div>
              <span className="text-neutral-500">Deliverables: </span>
              <strong className="text-emerald-400">Audit + 3 Versions + Guidelines + Deck</strong>
            </div>
          </div>
        </div>
      )
    },
    {
      number: 2,
      title: 'Original Logo',
      subtitle: 'Existing Visual Asset Baseline & Historical Context',
      speakerNotes: 'Slide 2 showcases the baseline asset before redesign. Notice the established color equity and recognizable motifs, but observe how the visual hierarchy is weighed down by dated stylistic trends of its original inception era.',
      renderContent: () => (
        <div className="h-full flex flex-col justify-between p-8 sm:p-12">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-xs font-mono text-amber-400 font-bold uppercase">Slide 02 / 14</span>
              <h2 className="text-2xl font-bold text-white font-display mt-0.5">Original Logo Presentation</h2>
            </div>
            <span className="text-xs font-mono px-2.5 py-1 rounded bg-neutral-800 text-neutral-300">
              {analysis.established}
            </span>
          </div>

          {/* Central Logo Box */}
          <div className="my-auto py-8 flex flex-col items-center justify-center">
            <div className="w-full max-w-md p-10 bg-white rounded-2xl border border-neutral-300 shadow-2xl flex items-center justify-center">
              <div 
                className="w-full"
                dangerouslySetInnerHTML={{ __html: analysis.originalSvgOrImg }} 
              />
            </div>
            <div className="text-xs font-mono text-neutral-400 mt-4">
              Asset State: Unmodified legacy corporate mark ({analysis.brandName})
            </div>
          </div>

          <div className="p-4 bg-neutral-950 rounded-xl border border-neutral-800 text-xs text-neutral-300 flex items-center justify-between">
            <span>Core visual motifs: Globe meridian, directional swoosh vector, and transitional serif wordmark.</span>
            <span className="text-rose-400 font-mono text-[11px]">Audit status: Critical redesign required</span>
          </div>
        </div>
      )
    },
    {
      number: 3,
      title: 'Analysis of the Original Logo',
      subtitle: 'Deconstruction of Iconography, Typography, Colors & Geometry',
      speakerNotes: 'Slide 3 dives into our senior designer diagnostic audit. We break down the mark into four pillars: Symbol, Typography, Colors, and Shape. Notice that while the concept has merit, the execution carries significant mechanical and optical flaws.',
      renderContent: () => (
        <div className="h-full flex flex-col justify-between p-8 sm:p-12 overflow-y-auto">
          <div className="flex items-center justify-between mb-4">
            <div>
              <span className="text-xs font-mono text-indigo-400 font-bold uppercase">Slide 03 / 14</span>
              <h2 className="text-2xl font-bold text-white font-display mt-0.5">Diagnostic Audit Breakdown</h2>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 my-auto">
            <div className="bg-neutral-950 p-4 rounded-xl border border-neutral-800 space-y-1.5">
              <span className="text-xs font-mono text-indigo-400 font-bold uppercase">1. Symbol / Icon</span>
              <p className="text-xs text-neutral-300 leading-relaxed">{analysis.symbolAnalysis.description}</p>
              <div className="text-[11px] text-neutral-400"><strong className="text-neutral-200">Flaws:</strong> {analysis.symbolAnalysis.flaws[0]}</div>
            </div>

            <div className="bg-neutral-950 p-4 rounded-xl border border-neutral-800 space-y-1.5">
              <span className="text-xs font-mono text-sky-400 font-bold uppercase">2. Typography</span>
              <p className="text-xs text-neutral-300 leading-relaxed">{analysis.typographyAnalysis.critique}</p>
              <div className="text-[11px] text-rose-400"><strong className="text-rose-300">Failure:</strong> {analysis.typographyAnalysis.legibilityIssue}</div>
            </div>

            <div className="bg-neutral-950 p-4 rounded-xl border border-neutral-800 space-y-1.5">
              <span className="text-xs font-mono text-amber-400 font-bold uppercase">3. Colors</span>
              <p className="text-xs text-neutral-300 leading-relaxed">{analysis.colorsAnalysis.harmonyCritique}</p>
              <div className="text-[11px] text-amber-300"><strong className="text-amber-200">Contrast:</strong> {analysis.colorsAnalysis.contrastIssue}</div>
            </div>

            <div className="bg-neutral-950 p-4 rounded-xl border border-neutral-800 space-y-1.5">
              <span className="text-xs font-mono text-emerald-400 font-bold uppercase">4. Shape &amp; Composition</span>
              <p className="text-xs text-neutral-300 leading-relaxed">{analysis.shapeComposition.balance}</p>
              <div className="text-[11px] text-neutral-400"><strong className="text-neutral-200">Scalability score:</strong> {analysis.shapeComposition.scalabilityScore}/100</div>
            </div>
          </div>

          <div className="text-xs text-neutral-500 font-mono text-center pt-2">
            Conclusion: The legacy mark fails contemporary responsiveness and multi-screen demands.
          </div>
        </div>
      )
    },
    {
      number: 4,
      title: 'Design Problems / Opportunities',
      subtitle: 'Preserving Brand Equity while Eliminating Technical Flaws',
      speakerNotes: 'Slide 4 presents the strategic design bridge. We clearly distinguish what MUST be preserved to protect hard-earned client recognition versus what MUST be eliminated to make the brand future-proof.',
      renderContent: () => (
        <div className="h-full flex flex-col justify-between p-8 sm:p-12">
          <div className="flex items-center justify-between mb-4">
            <div>
              <span className="text-xs font-mono text-rose-400 font-bold uppercase">Slide 04 / 14</span>
              <h2 className="text-2xl font-bold text-white font-display mt-0.5">Problems &amp; Strategic Opportunities</h2>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 my-auto">
            {/* Left: What to preserve */}
            <div className="bg-emerald-950/20 border border-emerald-500/30 rounded-2xl p-6 space-y-3">
              <div className="flex items-center gap-2 text-emerald-400 font-bold text-sm uppercase">
                <Award className="w-4 h-4" />
                <span>What Must Be Preserved (Core Equity)</span>
              </div>
              <ul className="space-y-2 text-xs text-neutral-200">
                {analysis.whatToPreserve.map((item, i) => (
                  <li key={i} className="flex items-start gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 mt-1.5 shrink-0" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Right: What to improve */}
            <div className="bg-rose-950/20 border border-rose-500/30 rounded-2xl p-6 space-y-3">
              <div className="flex items-center gap-2 text-rose-400 font-bold text-sm uppercase">
                <Sparkles className="w-4 h-4" />
                <span>What Must Be Improved (Opportunities)</span>
              </div>
              <ul className="space-y-2 text-xs text-neutral-200">
                {analysis.whatToImprove.map((item, i) => (
                  <li key={i} className="flex items-start gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-rose-400 mt-1.5 shrink-0" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div className="p-3 bg-neutral-950 rounded-xl border border-neutral-800 text-xs text-neutral-400 text-center">
            Strategic Thesis: Transition from literal skeuomorphic rendering to pure reductive vector geometry.
          </div>
        </div>
      )
    },
    {
      number: 5,
      title: 'Redesign Concept',
      subtitle: 'The Mathematical Philosophy Behind Modern Identity Design',
      speakerNotes: 'Slide 5 outlines the foundational creative philosophy. We follow the timeless Swiss design canon: form follows function, maximum reductive simplicity, and seamless scalability from 16px to 50 meters.',
      renderContent: () => (
        <div className="h-full flex flex-col justify-between p-8 sm:p-12 text-center sm:text-left">
          <div className="flex items-center justify-between mb-4">
            <div>
              <span className="text-xs font-mono text-indigo-400 font-bold uppercase">Slide 05 / 14</span>
              <h2 className="text-2xl font-bold text-white font-display mt-0.5">Redesign Concept &amp; Design Principles</h2>
            </div>
          </div>

          <div className="space-y-6 my-auto max-w-3xl">
            <div className="text-xl sm:text-2xl font-bold text-white font-display leading-snug">
              "A great logo is not one that has nothing left to add, but one that has nothing left to take away."
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
              <div className="bg-neutral-950 p-4 rounded-xl border border-neutral-800 text-left space-y-2">
                <span className="text-xs font-mono text-indigo-400 font-bold">1. Reductive Clarity</span>
                <p className="text-xs text-neutral-300">
                  Eliminating drop shadows, wireframe clutter, and excess gradients in favor of sharp mathematical vectors.
                </p>
              </div>

              <div className="bg-neutral-950 p-4 rounded-xl border border-neutral-800 text-left space-y-2">
                <span className="text-xs font-mono text-sky-400 font-bold">2. Digital-Native Scalability</span>
                <p className="text-xs text-neutral-300">
                  Engineered to survive extreme downscaling to 16px browser favicons and mobile push icons.
                </p>
              </div>

              <div className="bg-neutral-950 p-4 rounded-xl border border-neutral-800 text-left space-y-2">
                <span className="text-xs font-mono text-emerald-400 font-bold">3. Timeless Equity</span>
                <p className="text-xs text-neutral-300">
                  Retaining the recognizable soul and color temperature of the brand so loyal customers instantly connect.
                </p>
              </div>
            </div>
          </div>

          <div className="text-xs font-mono text-neutral-400 border-t border-neutral-800 pt-3">
            Following these principles, three distinct creative variations were developed for stakeholder review.
          </div>
        </div>
      )
    },
    {
      number: 6,
      title: 'Version A: Minimal & Modern',
      subtitle: 'Pure Reductive Geometry & High Negative Space',
      speakerNotes: 'Slide 6 presents Version A: Minimal & Modern. This version distills the core symbol into an interlocking monogram vector that works instantly on mobile devices, responsive headers, and packaging.',
      renderContent: () => {
        const v = versions.versionA;
        return (
          <div className="h-full flex flex-col justify-between p-8 sm:p-12">
            <div className="flex items-center justify-between mb-2">
              <div>
                <span className="text-xs font-mono text-indigo-400 font-bold uppercase">Slide 06 / 14</span>
                <h2 className="text-2xl font-bold text-white font-display mt-0.5">VERSION A — {v.styleTitle}</h2>
              </div>
              <span className="text-xs font-mono px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300">
                Direction 1
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-12 gap-6 my-auto items-center">
              <div className="sm:col-span-6 bg-white rounded-2xl p-8 border border-neutral-300 flex items-center justify-center shadow-xl">
                <div 
                  className="w-full max-w-[280px]"
                  dangerouslySetInnerHTML={{ __html: v.lockupSvg('light') }} 
                />
              </div>

              <div className="sm:col-span-6 space-y-3">
                <div className="text-sm font-bold text-white font-display">{v.concept}</div>
                <p className="text-xs text-neutral-300 leading-relaxed">{v.symbolMeaning}</p>
                
                <div className="bg-neutral-950 p-3 rounded-xl border border-neutral-800 space-y-1">
                  <span className="text-[10px] font-mono text-indigo-400 uppercase font-semibold">Typography:</span>
                  <div className="text-xs text-white font-medium">{v.typography.primaryFont}</div>
                </div>

                <div className="bg-neutral-950 p-3 rounded-xl border border-neutral-800 space-y-1">
                  <span className="text-[10px] font-mono text-emerald-400 uppercase font-semibold">Improvement:</span>
                  <div className="text-xs text-neutral-300">{v.improvements[0]}</div>
                </div>
              </div>
            </div>

            <div className="text-xs font-mono text-neutral-400 pt-2 border-t border-neutral-800">
              Evaluation: Highest score in small-screen scalability and digital UI integration.
            </div>
          </div>
        );
      }
    },
    {
      number: 7,
      title: 'Version B: Professional & Corporate',
      subtitle: 'Structural Authority & Monumental Weight',
      speakerNotes: 'Slide 7 showcases Version B: Professional & Corporate. This direction introduces architectural framing and geometric facets to communicate enterprise stability, international scale, and institutional prestige.',
      renderContent: () => {
        const v = versions.versionB;
        return (
          <div className="h-full flex flex-col justify-between p-8 sm:p-12">
            <div className="flex items-center justify-between mb-2">
              <div>
                <span className="text-xs font-mono text-sky-400 font-bold uppercase">Slide 07 / 14</span>
                <h2 className="text-2xl font-bold text-white font-display mt-0.5">VERSION B — {v.styleTitle}</h2>
              </div>
              <span className="text-xs font-mono px-2 py-0.5 rounded bg-sky-500/20 text-sky-300">
                Direction 2
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-12 gap-6 my-auto items-center">
              <div className="sm:col-span-6 bg-white rounded-2xl p-8 border border-neutral-300 flex items-center justify-center shadow-xl">
                <div 
                  className="w-full max-w-[280px]"
                  dangerouslySetInnerHTML={{ __html: v.lockupSvg('light') }} 
                />
              </div>

              <div className="sm:col-span-6 space-y-3">
                <div className="text-sm font-bold text-white font-display">{v.concept}</div>
                <p className="text-xs text-neutral-300 leading-relaxed">{v.symbolMeaning}</p>
                
                <div className="bg-neutral-950 p-3 rounded-xl border border-neutral-800 space-y-1">
                  <span className="text-[10px] font-mono text-sky-400 uppercase font-semibold">Typography:</span>
                  <div className="text-xs text-white font-medium">{v.typography.primaryFont}</div>
                </div>

                <div className="bg-neutral-950 p-3 rounded-xl border border-neutral-800 space-y-1">
                  <span className="text-[10px] font-mono text-emerald-400 uppercase font-semibold">Improvement:</span>
                  <div className="text-xs text-neutral-300">{v.improvements[0]}</div>
                </div>
              </div>
            </div>

            <div className="text-xs font-mono text-neutral-400 pt-2 border-t border-neutral-800">
              Evaluation: Optimal for enterprise corporate contracts, fleet markings, and industrial signage.
            </div>
          </div>
        );
      }
    },
    {
      number: 8,
      title: 'Version C: Creative & Contemporary',
      subtitle: 'Dynamic Overlapping Vectors & Kinetic Rhythm',
      speakerNotes: 'Slide 8 presents Version C: Creative & Contemporary. Here we reimagine the legacy dynamic motion with modern continuous splines and vibrant gradient transitions that bring the brand into the contemporary SaaS and mobile era.',
      renderContent: () => {
        const v = versions.versionC;
        return (
          <div className="h-full flex flex-col justify-between p-8 sm:p-12">
            <div className="flex items-center justify-between mb-2">
              <div>
                <span className="text-xs font-mono text-purple-400 font-bold uppercase">Slide 08 / 14</span>
                <h2 className="text-2xl font-bold text-white font-display mt-0.5">VERSION C — {v.styleTitle}</h2>
              </div>
              <span className="text-xs font-mono px-2 py-0.5 rounded bg-purple-500/20 text-purple-300">
                Direction 3
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-12 gap-6 my-auto items-center">
              <div className="sm:col-span-6 bg-white rounded-2xl p-8 border border-neutral-300 flex items-center justify-center shadow-xl">
                <div 
                  className="w-full max-w-[280px]"
                  dangerouslySetInnerHTML={{ __html: v.lockupSvg('light') }} 
                />
              </div>

              <div className="sm:col-span-6 space-y-3">
                <div className="text-sm font-bold text-white font-display">{v.concept}</div>
                <p className="text-xs text-neutral-300 leading-relaxed">{v.symbolMeaning}</p>
                
                <div className="bg-neutral-950 p-3 rounded-xl border border-neutral-800 space-y-1">
                  <span className="text-[10px] font-mono text-purple-400 uppercase font-semibold">Typography:</span>
                  <div className="text-xs text-white font-medium">{v.typography.primaryFont}</div>
                </div>

                <div className="bg-neutral-950 p-3 rounded-xl border border-neutral-800 space-y-1">
                  <span className="text-[10px] font-mono text-emerald-400 uppercase font-semibold">Improvement:</span>
                  <div className="text-xs text-neutral-300">{v.improvements[0]}</div>
                </div>
              </div>
            </div>

            <div className="text-xs font-mono text-neutral-400 pt-2 border-t border-neutral-800">
              Evaluation: Highly engaging for modern consumer digital touchpoints and motion graphics.
            </div>
          </div>
        );
      }
    },
    {
      number: 9,
      title: 'Color Palette & Psychology',
      subtitle: 'Color Psychology, Emotional Resonances & Exact HEX Specifications',
      speakerNotes: 'Slide 9 reviews the color architecture for our recommended identity. Notice how we have tightened the color harmony, elevated contrast ratios above WCAG AA 4.5:1, and provided standardized HEX, RGB, and CMYK values.',
      renderContent: () => (
        <div className="h-full flex flex-col justify-between p-8 sm:p-12">
          <div className="flex items-center justify-between mb-4">
            <div>
              <span className="text-xs font-mono text-indigo-400 font-bold uppercase">Slide 09 / 14</span>
              <h2 className="text-2xl font-bold text-white font-display mt-0.5">Color Palette &amp; Chromatic Strategy</h2>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 my-auto">
            {selectedVersion.colors.map((color, idx) => (
              <div key={idx} className="bg-neutral-950 border border-neutral-800 rounded-xl p-4 space-y-2">
                <div 
                  className="w-full h-16 rounded-lg border border-white/10 shadow-inner"
                  style={{ backgroundColor: color.hex }}
                />
                <div>
                  <div className="text-xs font-bold text-white">{color.name}</div>
                  <div className="text-[10px] font-mono text-indigo-400">{color.role}</div>
                </div>
                <div className="text-[11px] font-mono text-neutral-300 font-semibold">
                  HEX: {color.hex}
                </div>
                <p className="text-[10px] text-neutral-400 leading-tight">
                  {color.rationale}
                </p>
              </div>
            ))}
          </div>

          <div className="p-3 bg-neutral-950 rounded-xl border border-neutral-800 text-xs text-neutral-400 text-center">
            Color psychology rationale: Anchors security and institutional trust with vibrant digital acceleration.
          </div>
        </div>
      )
    },
    {
      number: 10,
      title: 'Typography & Hierarchy',
      subtitle: 'Engineered Type Pairings & Proportional Font Scales',
      speakerNotes: 'Slide 10 details our typography system. We replaced dated serifs and mismatched fonts with an engineered grotesque pairing. This delivers crystal clarity across high-resolution OLED mobile displays and small-format paper print.',
      renderContent: () => (
        <div className="h-full flex flex-col justify-between p-8 sm:p-12">
          <div className="flex items-center justify-between mb-4">
            <div>
              <span className="text-xs font-mono text-sky-400 font-bold uppercase">Slide 10 / 14</span>
              <h2 className="text-2xl font-bold text-white font-display mt-0.5">Typography Pairing &amp; System</h2>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 my-auto">
            <div className="bg-neutral-950 p-6 rounded-2xl border border-neutral-800 space-y-3">
              <span className="text-xs font-mono text-indigo-400 font-bold uppercase">Display Wordmark Typeface</span>
              <div className="text-3xl font-extrabold text-white font-display">
                {selectedVersion.typography.primaryFont.split('&')[0].trim()}
              </div>
              <p className="text-xs text-neutral-300 leading-relaxed">
                {selectedVersion.typography.rationale}
              </p>
              <div className="p-3 bg-neutral-900 rounded-lg text-xs font-mono text-neutral-400 border border-neutral-800">
                Weights: Bold 700 / ExtraBold 800 · Wide tracking
              </div>
            </div>

            <div className="bg-neutral-950 p-6 rounded-2xl border border-neutral-800 space-y-3">
              <span className="text-xs font-mono text-sky-400 font-bold uppercase">Interface &amp; Body Typeface</span>
              <div className="text-3xl font-bold text-white">
                Plus Jakarta Sans
              </div>
              <p className="text-xs text-neutral-300 leading-relaxed">
                A clean, geometric sans-serif engineered for ultra-crisp legibility in digital dashboards, shipping documents, and mobile apps.
              </p>
              <div className="p-3 bg-neutral-900 rounded-lg text-xs font-mono text-neutral-400 border border-neutral-800">
                Weights: Regular 400 / Medium 500 / SemiBold 600
              </div>
            </div>
          </div>

          <div className="text-xs font-mono text-neutral-400 text-center border-t border-neutral-800 pt-3">
            Open-source Google Font pairings ensuring zero licensing friction for enterprise client deployment.
          </div>
        </div>
      )
    },
    {
      number: 11,
      title: 'Logo Variations & Applications',
      subtitle: 'System Multi-Format Matrix & Real-World Contexts',
      speakerNotes: 'Slide 11 demonstrates the versatility of the redesign. A truly professional brand identity is not a static picture, but an adaptable system that flexes seamlessly across horizontal headers, vertical posters, monochrome stencils, and dark mode.',
      renderContent: () => (
        <div className="h-full flex flex-col justify-between p-8 sm:p-12 overflow-y-auto">
          <div className="flex items-center justify-between mb-4">
            <div>
              <span className="text-xs font-mono text-emerald-400 font-bold uppercase">Slide 11 / 14</span>
              <h2 className="text-2xl font-bold text-white font-display mt-0.5">Variations &amp; Multi-Platform Deployment</h2>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 my-auto">
            {/* Box 1 */}
            <div className="bg-white p-4 rounded-xl border border-neutral-200 flex flex-col items-center justify-between text-center gap-2">
              <div className="w-full max-w-[140px]">
                <div dangerouslySetInnerHTML={{ __html: selectedVersion.lockupSvg('light', 'horizontal') }} />
              </div>
              <span className="text-[10px] font-mono text-neutral-600 font-bold">1. Primary Horizontal</span>
            </div>

            {/* Box 2 */}
            <div className="bg-white p-4 rounded-xl border border-neutral-200 flex flex-col items-center justify-between text-center gap-2">
              <div className="w-full max-w-[100px]">
                <div dangerouslySetInnerHTML={{ __html: selectedVersion.lockupSvg('light', 'vertical') }} />
              </div>
              <span className="text-[10px] font-mono text-neutral-600 font-bold">2. Stacked Lockup</span>
            </div>

            {/* Box 3 */}
            <div className="bg-white p-4 rounded-xl border border-neutral-200 flex flex-col items-center justify-between text-center gap-2">
              <div className="w-12 h-12">
                <div dangerouslySetInnerHTML={{ __html: selectedVersion.symbolSvg('#0f172a', '#2563eb') }} />
              </div>
              <span className="text-[10px] font-mono text-neutral-600 font-bold">3. 1:1 Icon Mark</span>
            </div>

            {/* Box 4 */}
            <div className="bg-neutral-950 p-4 rounded-xl border border-neutral-800 flex flex-col items-center justify-between text-center gap-2">
              <div className="w-full max-w-[140px]">
                <div dangerouslySetInnerHTML={{ __html: selectedVersion.lockupSvg('dark', 'horizontal') }} />
              </div>
              <span className="text-[10px] font-mono text-neutral-400 font-bold">4. Dark Knockout</span>
            </div>
          </div>

          <div className="p-3 bg-neutral-950 rounded-xl border border-neutral-800 text-xs text-neutral-300 flex items-center justify-between">
            <span>Validated across: Business cards, mobile applications, web nav headers, and fleet shipping containers.</span>
            <span className="text-emerald-400 font-mono text-[11px]">Passes 100% test matrix</span>
          </div>
        </div>
      )
    },
    {
      number: 12,
      title: 'Final Selected Logo',
      subtitle: 'The Definitive Recommendation: Master Lockup & Specifications',
      speakerNotes: 'Slide 12 presents our definitive recommendation. We have selected this master lockup as the ideal balance between heritage preservation and future-proof modernity.',
      renderContent: () => (
        <div className="h-full flex flex-col justify-between p-8 sm:p-14 text-center">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-xs font-mono text-indigo-400 font-bold uppercase">Slide 12 / 14</span>
              <h2 className="text-2xl font-bold text-white font-display mt-0.5">Final Selected Master Identity</h2>
            </div>
            <span className="text-xs font-mono px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 font-semibold">
              ★ PRIMARY RECOMMENDATION
            </span>
          </div>

          <div className="my-auto py-8 flex flex-col items-center justify-center">
            <div className="w-full max-w-lg p-12 bg-white rounded-3xl border border-neutral-300 shadow-2xl flex items-center justify-center">
              <div 
                className="w-full"
                dangerouslySetInnerHTML={{ __html: selectedVersion.lockupSvg('light', 'horizontal') }} 
              />
            </div>
            <div className="text-sm font-display font-bold text-white mt-4">
              {caseStudy.name} — {selectedVersion.label} ({selectedVersion.styleTitle})
            </div>
            <div className="text-xs text-neutral-400 max-w-md mt-1">
              {selectedVersion.tagline}
            </div>
          </div>

          <div className="pt-4 border-t border-neutral-800 flex items-center justify-between text-xs font-mono text-neutral-400">
            <span>Clean Vector Architecture</span>
            <span>Zero Skeuomorphic Artifacts</span>
            <span>Mathematical Golden Ratio Grid</span>
          </div>
        </div>
      )
    },
    {
      number: 13,
      title: 'Design Rationale',
      subtitle: 'Why This Redesign Delivers Superior Commercial & Aesthetic Value',
      speakerNotes: 'Slide 13 provides the rigorous design rationale for stakeholders and leadership. Every curve, kerning choice, and color selection is grounded in commercial viability, customer trust, and operational efficiency.',
      renderContent: () => (
        <div className="h-full flex flex-col justify-between p-8 sm:p-12">
          <div className="flex items-center justify-between mb-4">
            <div>
              <span className="text-xs font-mono text-sky-400 font-bold uppercase">Slide 13 / 14</span>
              <h2 className="text-2xl font-bold text-white font-display mt-0.5">Strategic Design Rationale</h2>
            </div>
          </div>

          <div className="space-y-4 my-auto max-w-3xl">
            <div className="bg-neutral-950 p-5 rounded-2xl border border-neutral-800 space-y-2">
              <span className="text-xs font-mono text-indigo-400 font-bold uppercase">1. Immediate Cognitive Recognition</span>
              <p className="text-xs text-neutral-300 leading-relaxed">
                By distilling the core directional vector rather than completely abandoning it, existing clients immediately recognize the brand while perceiving a dramatic leap in modern technical sophistication.
              </p>
            </div>

            <div className="bg-neutral-950 p-5 rounded-2xl border border-neutral-800 space-y-2">
              <span className="text-xs font-mono text-sky-400 font-bold uppercase">2. Substantial Cost Savings in Physical Production</span>
              <p className="text-xs text-neutral-300 leading-relaxed">
                Replacing complex multi-color radial gradients with flat, disciplined vector fields reduces commercial printing, vinyl cutting, and merchandise embroidery costs by up to 40%.
              </p>
            </div>

            <div className="bg-neutral-950 p-5 rounded-2xl border border-neutral-800 space-y-2">
              <span className="text-xs font-mono text-emerald-400 font-bold uppercase">3. Digital-First Omnichannel Performance</span>
              <p className="text-xs text-neutral-300 leading-relaxed">
                The new mark renders flawlessly in high-DPI retina environments down to 16px, solving the critical favicon and mobile app blurring that crippled the original asset.
              </p>
            </div>
          </div>

          <div className="text-xs text-neutral-500 font-mono text-center pt-2">
            Every aesthetic decision is directly linked to demonstrable business value and user accessibility.
          </div>
        </div>
      )
    },
    {
      number: 14,
      title: 'Conclusion',
      subtitle: 'Project Summary, Key Takeaways & Internship Project Completion',
      speakerNotes: 'Slide 14 concludes our presentation. In summary, Task 1 demonstrates how disciplined graphic design principles revitalize a brand without disconnecting its legacy. Thank you for your time, and I welcome any questions or feedback from the committee.',
      renderContent: () => (
        <div className="h-full flex flex-col justify-between p-8 sm:p-14 text-center sm:text-left relative overflow-hidden">
          <div className="absolute bottom-0 right-0 w-96 h-96 bg-emerald-600/10 rounded-full blur-3xl pointer-events-none"></div>

          <div className="flex items-center justify-between">
            <div>
              <span className="text-xs font-mono text-emerald-400 font-bold uppercase">Slide 14 / 14</span>
              <h2 className="text-2xl font-bold text-white font-display mt-0.5">Conclusion &amp; Key Takeaways</h2>
            </div>
            <span className="text-xs font-mono px-3 py-1 rounded bg-neutral-800 text-neutral-300">
              TASK 1 COMPLETE
            </span>
          </div>

          <div className="space-y-6 my-auto max-w-2xl">
            <h3 className="text-2xl sm:text-3xl font-extrabold text-white font-display leading-tight">
              A Modern, Scalable, and Timeless Identity System
            </h3>
            <p className="text-neutral-300 text-sm sm:text-base leading-relaxed">
              {caseStudy.conclusionTakeaway}
            </p>

            <div className="p-4 bg-neutral-950 rounded-2xl border border-neutral-800 space-y-2">
              <span className="text-xs font-mono text-indigo-400 font-bold uppercase">Project Checklist Verified:</span>
              <div className="grid grid-cols-2 gap-2 text-xs text-neutral-300">
                <div className="flex items-center gap-1.5 text-emerald-400 font-medium">✓ Full 8-Point Audit</div>
                <div className="flex items-center gap-1.5 text-emerald-400 font-medium">✓ 3 Distinct Redesign Versions</div>
                <div className="flex items-center gap-1.5 text-emerald-400 font-medium">✓ 6 Mandatory Lockup Variations</div>
                <div className="flex items-center gap-1.5 text-emerald-400 font-medium">✓ Mini Brand Guidelines &amp; Mockups</div>
              </div>
            </div>
          </div>

          <div className="pt-6 border-t border-neutral-800 flex flex-wrap items-center justify-between text-xs font-mono text-neutral-400 gap-4">
            <div>Thank you for reviewing TASK 1: LOGO REDESIGN</div>
            <div className="text-indigo-400 font-semibold">Ready for Academic &amp; Portfolio Submission</div>
          </div>
        </div>
      )
    }
  ];

  const currentSlide = slides[currentSlideIndex];

  const handlePrintDeck = () => {
    window.print();
  };

  const handleCopyNotes = () => {
    navigator.clipboard.writeText(currentSlide.speakerNotes);
    setCopiedNotes(true);
    setTimeout(() => setCopiedNotes(false), 2000);
  };

  return (
    <div className={`space-y-6 ${isFullscreen ? 'fixed inset-0 z-50 bg-neutral-950 p-4 sm:p-6 flex flex-col justify-between' : ''}`}>
      
      {/* Deck Controls Top Bar */}
      <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-4 flex flex-wrap items-center justify-between gap-4 no-print">
        
        {/* Left: Slide Indicator & Title */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5">
            <span className="text-xs font-mono font-bold px-2.5 py-1 rounded-lg bg-indigo-600 text-white">
              Slide {currentSlide.number} of 14
            </span>
          </div>
          <span className="text-neutral-600 hidden sm:inline">|</span>
          <span className="text-xs text-neutral-300 font-medium hidden sm:inline font-display">
            {currentSlide.title}
          </span>
        </div>

        {/* Center: Presentation Timer */}
        <div className="flex items-center gap-2 bg-neutral-950 px-3 py-1.5 rounded-xl border border-neutral-800 text-xs font-mono text-neutral-300">
          <Clock className="w-3.5 h-3.5 text-indigo-400" />
          <span>{formatTimer(timerSeconds)}</span>
          <button
            onClick={() => setIsTimerRunning(!isTimerRunning)}
            className="text-[10px] text-neutral-500 hover:text-white underline ml-1"
          >
            {isTimerRunning ? 'Pause' : 'Resume'}
          </button>
        </div>

        {/* Right: Actions */}
        <div className="flex items-center gap-2">
          {/* Thumbnails toggle */}
          <button
            onClick={() => setShowThumbnails(!showThumbnails)}
            className={`p-2 rounded-lg border text-xs flex items-center gap-1.5 transition-colors ${
              showThumbnails ? 'bg-indigo-600/20 text-indigo-300 border-indigo-500/40' : 'bg-neutral-800 text-neutral-300 border-neutral-700 hover:text-white'
            }`}
            title="Slide Grid Overview"
          >
            <Grid className="w-3.5 h-3.5" />
            <span className="hidden md:inline">Thumbnails</span>
          </button>

          {/* Speaker notes toggle */}
          <button
            onClick={() => setShowNotes(!showNotes)}
            className={`p-2 rounded-lg border text-xs flex items-center gap-1.5 transition-colors ${
              showNotes ? 'bg-indigo-600/20 text-indigo-300 border-indigo-500/40' : 'bg-neutral-800 text-neutral-300 border-neutral-700 hover:text-white'
            }`}
            title="Toggle Speaker Rehearsal Notes"
          >
            <MessageSquare className="w-3.5 h-3.5" />
            <span className="hidden md:inline">Speaker Notes</span>
          </button>

          {/* Print Deck Button */}
          <button
            onClick={handlePrintDeck}
            className="p-2 rounded-lg bg-neutral-800 hover:bg-neutral-700 border border-neutral-700 text-neutral-300 hover:text-white text-xs flex items-center gap-1.5"
            title="Print all slides to PDF"
          >
            <Printer className="w-3.5 h-3.5" />
            <span className="hidden md:inline">Print to PDF</span>
          </button>

          {/* Fullscreen toggle */}
          <button
            onClick={onToggleFullscreen}
            className="p-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs flex items-center gap-1.5 shadow"
            title="Toggle Fullscreen"
          >
            {isFullscreen ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
            <span className="hidden md:inline">{isFullscreen ? 'Exit Fullscreen' : 'Fullscreen'}</span>
          </button>
        </div>

      </div>

      {/* Main Slide Stage */}
      <div className="relative aspect-[16/10] sm:aspect-[16/9] w-full max-w-5xl mx-auto rounded-3xl bg-neutral-900 border border-neutral-800 shadow-2xl overflow-hidden flex flex-col justify-between select-none">
        {currentSlide.renderContent()}

        {/* Slide Bottom Controls Bar Overlay */}
        <div className="px-6 py-3 bg-neutral-950/80 backdrop-blur-md border-t border-neutral-800 flex items-center justify-between no-print">
          <button
            onClick={() => setCurrentSlideIndex(prev => Math.max(prev - 1, 0))}
            disabled={currentSlideIndex === 0}
            className="flex items-center gap-1.5 text-xs font-medium px-3 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-300 hover:text-white disabled:opacity-30 disabled:pointer-events-none transition-colors"
          >
            <ChevronLeft className="w-4 h-4" />
            <span>Previous (←)</span>
          </button>

          {/* Dots Indicator */}
          <div className="flex items-center gap-1.5">
            {slides.map((s, idx) => (
              <button
                key={idx}
                onClick={() => setCurrentSlideIndex(idx)}
                className={`transition-all ${
                  idx === currentSlideIndex 
                    ? 'w-6 h-1.5 rounded-full bg-indigo-500' 
                    : 'w-1.5 h-1.5 rounded-full bg-neutral-700 hover:bg-neutral-500'
                }`}
                title={`Go to Slide ${s.number}: ${s.title}`}
              />
            ))}
          </div>

          <button
            onClick={() => setCurrentSlideIndex(prev => Math.min(prev + 1, 13))}
            disabled={currentSlideIndex === 13}
            className="flex items-center gap-1.5 text-xs font-medium px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white disabled:opacity-30 disabled:pointer-events-none transition-colors shadow"
          >
            <span>Next (→)</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Slide Thumbnails Drawer (When toggled) */}
      {showThumbnails && (
        <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-4 sm:p-6 space-y-3 no-print">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono uppercase text-indigo-400 font-bold">14-Slide Outline</span>
            <span className="text-xs text-neutral-400">Click any slide to jump</span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-7 gap-2.5">
            {slides.map((s, idx) => (
              <button
                key={idx}
                onClick={() => {
                  setCurrentSlideIndex(idx);
                  setShowThumbnails(false);
                }}
                className={`p-2.5 rounded-xl border text-left flex flex-col justify-between gap-1 transition-all ${
                  idx === currentSlideIndex
                    ? 'bg-neutral-800 border-indigo-500 ring-2 ring-indigo-500/20'
                    : 'bg-neutral-950 border-neutral-800 hover:border-neutral-700'
                }`}
              >
                <span className="text-[10px] font-mono font-bold text-neutral-500">
                  #{s.number.toString().padStart(2, '0')}
                </span>
                <span className="text-xs font-semibold text-neutral-200 line-clamp-1">
                  {s.title}
                </span>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Speaker Notes Drawer (When toggled) */}
      {showNotes && (
        <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-6 space-y-3 no-print animate-fade-in">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <MessageSquare className="w-4 h-4 text-indigo-400" />
              <span className="text-xs font-mono uppercase text-indigo-400 font-bold">
                Speaker Rehearsal Notes (Slide {currentSlide.number}: {currentSlide.title})
              </span>
            </div>
            <button
              onClick={handleCopyNotes}
              className="px-2.5 py-1 rounded bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-xs font-mono flex items-center gap-1 transition-colors"
            >
              {copiedNotes ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
              <span>{copiedNotes ? 'Copied' : 'Copy Script'}</span>
            </button>
          </div>

          <div className="bg-neutral-950 p-4 rounded-xl border border-neutral-800 text-neutral-200 text-sm leading-relaxed font-sans">
            "{currentSlide.speakerNotes}"
          </div>
        </div>
      )}

      {/* Hidden Print Container for all 14 slides formatted for printing to PDF */}
      <div className="hidden print:block space-y-12 bg-white text-black">
        {slides.map((s, idx) => (
          <div key={idx} className="print-page-break p-12 border-b border-gray-300 min-h-screen flex flex-col justify-between">
            <div className="flex items-center justify-between border-b pb-4 mb-6">
              <span className="font-mono text-xs uppercase font-bold text-gray-500">
                TASK 1 LOGO REDESIGN — SLIDE {s.number} OF 14
              </span>
              <span className="font-bold text-sm text-gray-800">{caseStudy.name}</span>
            </div>
            <div className="my-auto">
              <h2 className="text-3xl font-bold mb-2 font-display text-gray-900">{s.title}</h2>
              <div className="text-sm text-gray-600 mb-8">{s.subtitle}</div>
              <div className="bg-gray-50 p-6 rounded-xl border border-gray-200">
                {s.renderContent()}
              </div>
            </div>
            <div className="border-t pt-4 text-xs font-mono text-gray-500 flex justify-between">
              <span>Speaker Notes: {s.speakerNotes}</span>
              <span>Internship Capstone Presentation</span>
            </div>
          </div>
        ))}
      </div>

    </div>
  );
};
