import React, { useState } from 'react';
import { 
  Check, 
  Copy, 
  Sparkles, 
  Layers, 
  Type, 
  Palette, 
  ArrowRight, 
  SlidersHorizontal, 
  Grid3X3, 
  Download, 
  Star,
  CheckCircle2,
  Maximize2
} from 'lucide-react';
import { CaseStudy, RedesignVersion } from '../types/brand';

interface RedesignVersionsProps {
  caseStudy: CaseStudy;
  selectedVersionId: 'versionA' | 'versionB' | 'versionC';
  onSelectVersion: (id: 'versionA' | 'versionB' | 'versionC') => void;
  onProceedToVariations: () => void;
}

export const RedesignVersions: React.FC<RedesignVersionsProps> = ({
  caseStudy,
  selectedVersionId,
  onSelectVersion,
  onProceedToVariations,
}) => {
  const { versions, analysis } = caseStudy;
  const [activeTab, setActiveTab] = useState<'versionA' | 'versionB' | 'versionC'>(selectedVersionId);
  const [showConstructionGrid, setShowConstructionGrid] = useState<boolean>(true);
  const [previewBg, setPreviewBg] = useState<'light' | 'dark' | 'mono'>('light');
  const [copiedHex, setCopiedHex] = useState<string | null>(null);
  const [compareSplit, setCompareSplit] = useState<number>(50);
  const [showComparisonSlider, setShowComparisonSlider] = useState<boolean>(false);

  const currentVersion: RedesignVersion = versions[activeTab];

  const handleCopyColor = (hex: string) => {
    navigator.clipboard.writeText(hex);
    setCopiedHex(hex);
    setTimeout(() => setCopiedHex(null), 2000);
  };

  const handleSelectAsPrimary = (id: 'versionA' | 'versionB' | 'versionC') => {
    onSelectVersion(id);
    setActiveTab(id);
  };

  return (
    <div className="space-y-8 animate-fade-in">
      
      {/* Header Banner */}
      <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-6 sm:p-8">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono font-medium px-2 py-0.5 rounded bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
                PHASE 2: REDESIGN CONCEPT DIRECTIONS
              </span>
              <span className="text-xs text-neutral-400 font-mono">
                3 Divergent Strategic Iterations
              </span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight font-display">
              Select &amp; Evaluate Design Directions
            </h2>
            <p className="text-neutral-400 text-sm max-w-3xl leading-relaxed">
              In accordance with professional brand design methodology, three distinct aesthetic directions have been engineered from the original equity: 
              <strong className="text-neutral-200"> Version A (Minimal &amp; Modern)</strong>, 
              <strong className="text-neutral-200"> Version B (Professional &amp; Corporate)</strong>, and 
              <strong className="text-neutral-200"> Version C (Creative &amp; Contemporary)</strong>.
            </p>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={() => setShowComparisonSlider(!showComparisonSlider)}
              className={`inline-flex items-center gap-2 px-4 py-2.5 rounded-xl border text-xs font-medium transition-all ${
                showComparisonSlider 
                  ? 'bg-indigo-600/20 border-indigo-500/40 text-indigo-300' 
                  : 'bg-neutral-800 border-neutral-700 text-neutral-300 hover:text-white'
              }`}
            >
              <SlidersHorizontal className="w-3.5 h-3.5" />
              <span>{showComparisonSlider ? 'Hide Comparison' : 'Before / After Slider'}</span>
            </button>
            <button
              onClick={onProceedToVariations}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-medium text-sm transition-all shadow-lg shadow-indigo-600/20"
            >
              <span>View Full Variations Suite</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Interactive Before & After Comparison Slider (Collapsible) */}
      {showComparisonSlider && (
        <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-6 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono uppercase text-indigo-400 font-semibold">Visual Evolution</span>
              <span className="text-xs text-neutral-400">· Drag slider to compare Original vs. {currentVersion.label}</span>
            </div>
            <div className="text-xs font-mono text-neutral-400">
              {compareSplit}% Original / {100 - compareSplit}% Redesign
            </div>
          </div>

          <div className="relative h-72 sm:h-80 rounded-xl overflow-hidden bg-white select-none border border-neutral-300">
            {/* Original Left Half */}
            <div 
              className="absolute inset-0 bg-slate-50 flex items-center justify-center p-8 overflow-hidden"
              style={{ clipPath: `polygon(0 0, ${compareSplit}% 0, ${compareSplit}% 100%, 0 100%)` }}
            >
              <div className="w-full max-w-sm">
                <div dangerouslySetInnerHTML={{ __html: analysis.originalSvgOrImg }} />
              </div>
              <div className="absolute top-4 left-4 bg-neutral-950/80 backdrop-blur-md px-2.5 py-1 rounded text-xs font-mono text-amber-400 border border-neutral-800">
                ORIGINAL (DATED)
              </div>
            </div>

            {/* Redesign Right Half */}
            <div 
              className="absolute inset-0 bg-white flex items-center justify-center p-8 overflow-hidden"
              style={{ clipPath: `polygon(${compareSplit}% 0, 100% 0, 100% 100%, ${compareSplit}% 100%)` }}
            >
              <div className="w-full max-w-sm">
                <div dangerouslySetInnerHTML={{ __html: currentVersion.lockupSvg('light') }} />
              </div>
              <div className="absolute top-4 right-4 bg-indigo-600/90 backdrop-blur-md px-2.5 py-1 rounded text-xs font-mono text-white border border-indigo-500/50">
                REDESIGN ({currentVersion.label})
              </div>
            </div>

            {/* Divider Line & Thumb */}
            <div 
              className="absolute top-0 bottom-0 w-1 bg-indigo-500 shadow-2xl pointer-events-none -translate-x-1/2 z-10"
              style={{ left: `${compareSplit}%` }}
            >
              <div className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-8 h-8 rounded-full bg-indigo-600 border-2 border-white shadow-lg flex items-center justify-center text-white text-[10px] font-bold">
                ↔
              </div>
            </div>

            {/* Hidden Range Input */}
            <input
              type="range"
              min="5"
              max="95"
              value={compareSplit}
              onChange={(e) => setCompareSplit(Number(e.target.value))}
              className="absolute inset-0 w-full h-full opacity-0 cursor-ew-resize z-20"
              aria-label="Comparison slider"
            />
          </div>
        </div>
      )}

      {/* 3 Versions Navigation Tabs */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {(['versionA', 'versionB', 'versionC'] as const).map((key) => {
          const v = versions[key];
          const isSelected = activeTab === key;
          const isPrimary = selectedVersionId === key;

          return (
            <div
              key={key}
              onClick={() => setActiveTab(key)}
              className={`cursor-pointer rounded-2xl border transition-all p-5 flex flex-col justify-between gap-4 ${
                isSelected
                  ? 'bg-neutral-850 border-indigo-500/80 ring-2 ring-indigo-500/20 shadow-xl'
                  : 'bg-neutral-900 border-neutral-800 hover:border-neutral-700 hover:bg-neutral-850/50'
              }`}
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono font-bold tracking-wider text-indigo-400">
                    {v.label}
                  </span>
                  {isPrimary && (
                    <span className="inline-flex items-center gap-1 text-[10px] font-mono font-semibold px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                      <Star className="w-2.5 h-2.5 fill-current" />
                      MASTER PICK
                    </span>
                  )}
                </div>
                <h3 className="text-lg font-bold text-white tracking-tight font-display">
                  {v.styleTitle}
                </h3>
                <p className="text-xs text-neutral-400 line-clamp-2">
                  {v.tagline}
                </p>
              </div>

              {/* Mini Preview Box */}
              <div className="h-28 rounded-xl bg-white flex items-center justify-center p-3 overflow-hidden border border-neutral-200">
                <div 
                  className="w-full max-w-[200px]"
                  dangerouslySetInnerHTML={{ __html: v.lockupSvg('light') }} 
                />
              </div>

              {/* Bottom selection button */}
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  handleSelectAsPrimary(key);
                }}
                className={`w-full py-2 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors ${
                  isPrimary
                    ? 'bg-emerald-600 text-white'
                    : 'bg-neutral-800 hover:bg-neutral-750 text-neutral-300 hover:text-white'
                }`}
              >
                {isPrimary ? (
                  <>
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Selected as Master Identity</span>
                  </>
                ) : (
                  <span>Set as Recommended Identity</span>
                )}
              </button>
            </div>
          );
        })}
      </div>

      {/* Deep-Dive Inspection Panel for Active Version */}
      <div className="bg-neutral-900 border border-neutral-800 rounded-2xl overflow-hidden shadow-2xl">
        
        {/* Top Bar for Deep Dive */}
        <div className="px-6 py-4 bg-neutral-850 border-b border-neutral-800 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <span className="w-3 h-3 rounded-full bg-indigo-500"></span>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono font-bold text-indigo-400">{currentVersion.label}</span>
                <span className="text-neutral-600">/</span>
                <span className="text-sm font-bold text-white font-display">{currentVersion.styleTitle}</span>
              </div>
            </div>
          </div>

          {/* Controls: Canvas Mode & Grid */}
          <div className="flex items-center gap-3">
            {/* Background switcher */}
            <div className="flex items-center bg-neutral-900 rounded-lg p-0.5 border border-neutral-800 text-xs">
              <button
                onClick={() => setPreviewBg('light')}
                className={`px-2.5 py-1 rounded ${previewBg === 'light' ? 'bg-neutral-800 text-white font-medium' : 'text-neutral-400'}`}
              >
                Light
              </button>
              <button
                onClick={() => setPreviewBg('dark')}
                className={`px-2.5 py-1 rounded ${previewBg === 'dark' ? 'bg-neutral-800 text-white font-medium' : 'text-neutral-400'}`}
              >
                Dark
              </button>
              <button
                onClick={() => setPreviewBg('mono')}
                className={`px-2.5 py-1 rounded ${previewBg === 'mono' ? 'bg-neutral-800 text-white font-medium' : 'text-neutral-400'}`}
              >
                Monochrome
              </button>
            </div>

            {/* Construction Grid Toggle */}
            <button
              onClick={() => setShowConstructionGrid(!showConstructionGrid)}
              className={`p-1.5 rounded-lg border text-xs flex items-center gap-1.5 transition-colors ${
                showConstructionGrid 
                  ? 'bg-indigo-600/20 text-indigo-300 border-indigo-500/40' 
                  : 'bg-neutral-900 text-neutral-400 border-neutral-800 hover:text-white'
              }`}
              title="Toggle Golden Ratio & Geometric Construction Lines"
            >
              <Grid3X3 className="w-3.5 h-3.5" />
              <span className="text-xs hidden sm:inline">Construction Geometry</span>
            </button>
          </div>
        </div>

        {/* Viewport Canvas & Vector Lockup */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-0 border-b border-neutral-800">
          
          {/* Main Stage (7 cols) */}
          <div className={`lg:col-span-7 relative min-h-[380px] flex items-center justify-center p-8 transition-colors ${
            previewBg === 'light' ? 'bg-white' : previewBg === 'dark' ? 'bg-neutral-950' : 'bg-neutral-900'
          }`}>
            
            {/* Construction Lines Overlay */}
            {showConstructionGrid && (
              <div className="absolute inset-0 pointer-events-none opacity-40">
                {/* Concentric Golden Ratio Circles */}
                <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-48 h-48 rounded-full border border-sky-400/40 border-dashed"></div>
                <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-72 h-72 rounded-full border border-sky-400/20 border-dashed"></div>
                {/* 45-degree isometric diagonals */}
                <div className="absolute inset-0 bg-[linear-gradient(45deg,transparent_49.5%,rgba(56,189,248,0.15)_50%,transparent_50.5%)]"></div>
                <div className="absolute inset-0 bg-[linear-gradient(-45deg,transparent_49.5%,rgba(56,189,248,0.15)_50%,transparent_50.5%)]"></div>
                {/* Center Crosshair */}
                <div className="absolute left-1/2 top-0 bottom-0 w-px bg-indigo-500/50 -translate-x-1/2"></div>
                <div className="absolute top-1/2 left-0 right-0 h-px bg-indigo-500/50 -translate-y-1/2"></div>
              </div>
            )}

            {/* Lockup Vector */}
            <div className="w-full max-w-md select-none relative z-10 drop-shadow-sm">
              <div 
                dangerouslySetInnerHTML={{ 
                  __html: currentVersion.lockupSvg(previewBg === 'dark' ? 'dark' : 'light', 'horizontal') 
                }} 
              />
            </div>

            {/* Bottom Meta Pill */}
            <div className="absolute bottom-3 left-3 bg-neutral-900/90 backdrop-blur-md px-3 py-1 rounded-md border border-neutral-700 text-xs font-mono text-neutral-300">
              Vector Lockup: Primary Horizontal
            </div>
          </div>

          {/* Icon Symbol Close-Up & Symbol Meaning (5 cols) */}
          <div className="lg:col-span-5 bg-neutral-900 p-6 sm:p-8 flex flex-col justify-between gap-6 border-t lg:border-t-0 lg:border-l border-neutral-800">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono text-indigo-400 font-semibold uppercase">
                  Symbolic Meaning &amp; Geometry
                </span>
                <span className="text-[11px] font-mono text-neutral-500">Pure Vector Icon</span>
              </div>

              {/* Icon close-up square */}
              <div className="w-24 h-24 rounded-2xl bg-white p-3 border border-neutral-700/60 shadow-lg flex items-center justify-center">
                <div 
                  className="w-16 h-16"
                  dangerouslySetInnerHTML={{ __html: currentVersion.symbolSvg('#0f172a', '#2563eb') }} 
                />
              </div>

              <div className="space-y-2">
                <h4 className="text-base font-bold text-white font-display">
                  Concept: {currentVersion.concept}
                </h4>
                <p className="text-xs text-neutral-300 leading-relaxed">
                  {currentVersion.symbolMeaning}
                </p>
              </div>

              <div className="space-y-2 pt-2 border-t border-neutral-800">
                <span className="text-xs font-mono text-neutral-400 font-semibold uppercase">Key Strategic Attributes:</span>
                <div className="flex flex-wrap gap-1.5">
                  {currentVersion.keyAttributes.map((attr, idx) => (
                    <span key={idx} className="text-xs px-2.5 py-0.5 rounded-full bg-neutral-800 text-indigo-300 border border-neutral-700 font-medium">
                      {attr}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            <div className="pt-2">
              <div className="text-[11px] text-neutral-400">
                <strong className="text-neutral-200">Recommended for: </strong>
                {currentVersion.bestSuitedFor}
              </div>
            </div>
          </div>

        </div>

        {/* Deep Dive Specifications Grid: Colors, Typography & Improvements */}
        <div className="p-6 sm:p-8 grid grid-cols-1 md:grid-cols-3 gap-6 bg-neutral-900">
          
          {/* Col 1: Color Palette with HEX / RGB / CMYK codes */}
          <div className="space-y-4">
            <div className="flex items-center gap-2 text-indigo-400 font-bold text-xs uppercase tracking-wider">
              <Palette className="w-4 h-4" />
              <span>Color Palette &amp; Codes</span>
            </div>
            
            <div className="space-y-3">
              {currentVersion.colors.map((color, idx) => (
                <div key={idx} className="bg-neutral-950 border border-neutral-800 rounded-xl p-3 space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <div 
                        className="w-6 h-6 rounded-md border border-white/20 shadow-inner" 
                        style={{ backgroundColor: color.hex }}
                      />
                      <div>
                        <div className="text-xs font-bold text-white">{color.name}</div>
                        <div className="text-[10px] font-mono text-indigo-400">{color.role}</div>
                      </div>
                    </div>
                    
                    <button
                      onClick={() => handleCopyColor(color.hex)}
                      className="p-1 rounded hover:bg-neutral-800 text-neutral-400 hover:text-white transition-colors text-[10px] font-mono flex items-center gap-1"
                      title="Copy HEX"
                    >
                      {copiedHex === color.hex ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                      <span>{color.hex}</span>
                    </button>
                  </div>

                  <div className="grid grid-cols-2 gap-1 text-[10px] font-mono text-neutral-400 pt-1 border-t border-neutral-900">
                    <span>RGB: {color.rgb}</span>
                    <span>CMYK: {color.cmyk}</span>
                    {color.pantone && <span className="col-span-2 text-neutral-300">Pantone: {color.pantone}</span>}
                  </div>

                  <p className="text-[11px] text-neutral-400 leading-tight">
                    {color.rationale}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Col 2: Typography & Font Pairing */}
          <div className="space-y-4">
            <div className="flex items-center gap-2 text-sky-400 font-bold text-xs uppercase tracking-wider">
              <Type className="w-4 h-4" />
              <span>Typography Styling</span>
            </div>

            <div className="bg-neutral-950 border border-neutral-800 rounded-xl p-4 space-y-3">
              <div>
                <span className="text-[10px] font-mono text-neutral-500 uppercase">Primary Type Pairing</span>
                <div className="text-sm font-bold text-white font-display mt-0.5">
                  {currentVersion.typography.primaryFont}
                </div>
                <div className="text-xs text-sky-400 font-medium mt-0.5">
                  {currentVersion.typography.style}
                </div>
              </div>

              <p className="text-xs text-neutral-300 leading-relaxed">
                {currentVersion.typography.rationale}
              </p>

              <div className="space-y-2 pt-2 border-t border-neutral-900">
                {currentVersion.typography.specs.map((spec, idx) => (
                  <div key={idx} className="bg-neutral-900 p-2.5 rounded-lg border border-neutral-800">
                    <div className="flex items-center justify-between text-[11px]">
                      <span className="font-semibold text-neutral-200">{spec.role}</span>
                      <span className="font-mono text-neutral-400">{spec.fontFamily}</span>
                    </div>
                    <div className="text-xs text-neutral-300 font-medium mt-1">
                      Sample: <span className="font-bold text-white">"{spec.sampleText}"</span>
                    </div>
                    <div className="text-[10px] text-neutral-400 mt-0.5">
                      {spec.characteristics}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Col 3: Solved Problems & Value Added */}
          <div className="space-y-4">
            <div className="flex items-center gap-2 text-emerald-400 font-bold text-xs uppercase tracking-wider">
              <CheckCircle2 className="w-4 h-4" />
              <span>Why This Version Improves the Original</span>
            </div>

            <div className="bg-neutral-950 border border-neutral-800 rounded-xl p-4 space-y-3">
              <ul className="space-y-2.5 text-xs text-neutral-300">
                {currentVersion.improvements.map((imp, idx) => (
                  <li key={idx} className="flex items-start gap-2.5">
                    <div className="w-4 h-4 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0 mt-0.5 text-[10px] font-bold">
                      ✓
                    </div>
                    <span className="leading-relaxed">{imp}</span>
                  </li>
                ))}
              </ul>

              <div className="pt-3 border-t border-neutral-900">
                <button
                  type="button"
                  onClick={() => handleSelectAsPrimary(activeTab)}
                  className="w-full py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs transition-colors flex items-center justify-center gap-2 shadow"
                >
                  <Star className="w-3.5 h-3.5" />
                  <span>Choose {currentVersion.label} as Final Recommendation</span>
                </button>
              </div>
            </div>
          </div>

        </div>

      </div>

    </div>
  );
};
