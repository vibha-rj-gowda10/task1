import React from 'react';
import { 
  Compass, 
  Layers, 
  Grid, 
  BookOpen, 
  Presentation, 
  Upload, 
  Download, 
  ChevronDown,
  Sparkles,
  Maximize2
} from 'lucide-react';
import { CaseStudy } from '../types/brand';

interface HeaderProps {
  currentTab: 'audit' | 'redesigns' | 'variations' | 'guidelines' | 'deck';
  setCurrentTab: (tab: 'audit' | 'redesigns' | 'variations' | 'guidelines' | 'deck') => void;
  caseStudies: CaseStudy[];
  selectedCaseId: string;
  onSelectCase: (id: string) => void;
  onOpenUpload: () => void;
  onOpenExport: () => void;
  onStartPresentation: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  setCurrentTab,
  caseStudies,
  selectedCaseId,
  onSelectCase,
  onOpenUpload,
  onOpenExport,
  onStartPresentation
}) => {
  const currentCase = caseStudies.find(c => c.id === selectedCaseId);

  interface NavItem {
    id: 'audit' | 'redesigns' | 'variations' | 'guidelines' | 'deck';
    label: string;
    icon: React.ComponentType<{ className?: string }>;
    badge?: string;
  }

  const navItems: NavItem[] = [
    { id: 'audit', label: '1. Original Audit', icon: Compass },
    { id: 'redesigns', label: '2. Redesign Concepts (A/B/C)', icon: Layers },
    { id: 'variations', label: '3. Variations Suite', icon: Grid },
    { id: 'guidelines', label: '4. Mini Brand Guidelines', icon: BookOpen },
    { id: 'deck', label: '5. 14-Slide Submission Deck', icon: Presentation, badge: 'Final Deck' },
  ];

  return (
    <header className="sticky top-0 z-40 bg-neutral-950/90 backdrop-blur-md border-b border-neutral-800 text-neutral-100 no-print">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-4">
          
          {/* Brand Identity / Task Title */}
          <div className="flex items-center gap-3 shrink-0">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 via-sky-500 to-emerald-400 p-0.5 shadow-lg shadow-indigo-500/20">
              <div className="w-full h-full bg-neutral-950 rounded-[10px] flex items-center justify-center">
                <Compass className="w-5 h-5 text-indigo-400" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono uppercase tracking-wider text-indigo-400 font-semibold">TASK 1</span>
                <span className="text-neutral-600">/</span>
                <span className="text-xs font-mono uppercase tracking-wider text-neutral-400">Internship Project</span>
              </div>
              <h1 className="text-sm font-bold tracking-tight text-white flex items-center gap-2 font-display">
                LOGO REDESIGN STUDIO
              </h1>
            </div>
          </div>

          {/* Navigation Tabs */}
          <nav className="hidden md:flex items-center gap-1 bg-neutral-900/80 p-1 rounded-xl border border-neutral-800/80">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setCurrentTab(item.id)}
                  className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-medium transition-all duration-150 ${
                    isActive
                      ? 'bg-neutral-800 text-white shadow-sm border border-neutral-700/60 font-semibold'
                      : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-850'
                  }`}
                >
                  <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-indigo-400' : 'text-neutral-500'}`} />
                  <span>{item.label}</span>
                  {item.badge && (
                    <span className="text-[10px] px-1.5 py-0.2 bg-indigo-500/20 text-indigo-300 rounded font-mono">
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>

          {/* Right Action Controls */}
          <div className="flex items-center gap-2.5">
            {/* Case Study Selector */}
            <div className="relative">
              <select
                aria-label="Select logo case study"
                value={selectedCaseId}
                onChange={(e) => onSelectCase(e.target.value)}
                className="appearance-none bg-neutral-900 hover:bg-neutral-850 border border-neutral-800 text-neutral-300 text-xs font-medium rounded-lg pl-3 pr-8 py-2 cursor-pointer focus:outline-none focus:ring-1 focus:ring-indigo-500 transition-colors"
              >
                {caseStudies.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
              <ChevronDown className="w-3.5 h-3.5 text-neutral-400 absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            </div>

            {/* Upload Custom Logo Button */}
            <button
              onClick={onOpenUpload}
              className="flex items-center gap-1.5 px-3 py-2 bg-neutral-900 hover:bg-neutral-800 text-neutral-200 text-xs font-medium rounded-lg border border-neutral-800 transition-colors shadow-sm"
              title="Upload your own logo image"
            >
              <Upload className="w-3.5 h-3.5 text-indigo-400" />
              <span className="hidden sm:inline">Upload Logo</span>
            </button>

            {/* Quick Present / Fullscreen */}
            <button
              onClick={onStartPresentation}
              className="flex items-center gap-1.5 px-3 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-medium rounded-lg transition-colors shadow-sm shadow-indigo-600/30"
              title="Launch Fullscreen 14-Slide Presentation"
            >
              <Maximize2 className="w-3.5 h-3.5" />
              <span className="hidden lg:inline">Present Slides</span>
            </button>

            {/* Export Report / PDF */}
            <button
              onClick={onOpenExport}
              className="flex items-center gap-1.5 px-3 py-2 bg-neutral-800 hover:bg-neutral-700 text-neutral-100 text-xs font-medium rounded-lg transition-colors border border-neutral-700"
              title="Export Report & Print PDF"
            >
              <Download className="w-3.5 h-3.5 text-neutral-400" />
              <span className="hidden sm:inline">Export</span>
            </button>
          </div>
        </div>

        {/* Mobile Navigation bar */}
        <div className="md:hidden flex items-center gap-1 py-2 overflow-x-auto border-t border-neutral-900">
          {navItems.map((item) => {
            const isActive = currentTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setCurrentTab(item.id)}
                className={`whitespace-nowrap px-2.5 py-1 text-xs rounded-md transition-colors ${
                  isActive ? 'bg-indigo-600 text-white font-semibold' : 'text-neutral-400 hover:text-white'
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </div>
      </div>
    </header>
  );
};
