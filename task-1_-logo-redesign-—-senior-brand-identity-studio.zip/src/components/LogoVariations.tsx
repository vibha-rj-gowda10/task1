import React, { useState } from 'react';
import { 
  Grid, 
  Download, 
  Copy, 
  Check, 
  Sun, 
  Moon, 
  Minimize, 
  Smartphone, 
  ArrowRight,
  ShieldCheck,
  CheckCircle2
} from 'lucide-react';
import { CaseStudy, RedesignVersion } from '../types/brand';

interface LogoVariationsProps {
  caseStudy: CaseStudy;
  selectedVersion: RedesignVersion;
  onProceedToGuidelines: () => void;
}

export const LogoVariations: React.FC<LogoVariationsProps> = ({
  caseStudy,
  selectedVersion,
  onProceedToGuidelines,
}) => {
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const handleCopySvg = (svgString: string, key: string) => {
    navigator.clipboard.writeText(svgString);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const handleDownloadSvg = (svgString: string, fileName: string) => {
    const blob = new Blob([svgString], { type: 'image/svg+xml' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${fileName}.svg`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const primaryHorizontalSvg = selectedVersion.lockupSvg('light', 'horizontal');
  const secondaryStackedSvg = selectedVersion.lockupSvg('light', 'vertical');
  const iconOnlySvg = selectedVersion.symbolSvg('#0f172a', '#2563eb');
  const monochromeDarkSvg = selectedVersion.lockupSvg('light', 'horizontal'); // rendered with pure black
  const monochromeLightSvg = selectedVersion.lockupSvg('dark', 'horizontal');
  const darkBackgroundSvg = selectedVersion.lockupSvg('dark', 'horizontal');

  return (
    <div className="space-y-8 animate-fade-in">
      
      {/* Top Banner */}
      <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-6 sm:p-8">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono font-medium px-2 py-0.5 rounded bg-sky-500/10 text-sky-400 border border-sky-500/20">
                PHASE 3: COMPLETE LOGO VARIATION SUITE
              </span>
              <span className="text-xs text-neutral-400 font-mono">
                Asset Architecture for {selectedVersion.label} ({selectedVersion.styleTitle})
              </span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight font-display">
              Required Logo Variations &amp; Lockups
            </h2>
            <p className="text-neutral-400 text-sm max-w-3xl leading-relaxed">
              To ensure seamless implementation across print, web, software, and physical manufacturing, the identity is systematized into six official lockup configurations.
            </p>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={onProceedToGuidelines}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-medium text-sm transition-all shadow-lg shadow-indigo-600/20"
            >
              <span>View Brand Guidelines</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Grid of 6 Mandatory Variations */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        
        {/* Variation 1: Primary Logo (Horizontal Lockup) */}
        <div className="bg-neutral-900 border border-neutral-800 rounded-2xl overflow-hidden flex flex-col justify-between shadow-lg">
          <div className="p-4 bg-neutral-850 border-b border-neutral-800 flex items-center justify-between">
            <div>
              <span className="text-xs font-mono text-indigo-400 font-semibold block">VARIATION 1</span>
              <h3 className="text-sm font-bold text-white font-display">Primary Logo Lockup</h3>
            </div>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-neutral-800 text-neutral-300">
              Default Standard
            </span>
          </div>

          {/* Canvas Box */}
          <div className="p-8 bg-white min-h-[220px] flex items-center justify-center border-b border-neutral-200">
            <div 
              className="w-full max-w-[260px] drop-shadow-sm"
              dangerouslySetInnerHTML={{ __html: primaryHorizontalSvg }} 
            />
          </div>

          <div className="p-4 space-y-3">
            <p className="text-xs text-neutral-300">
              <strong>Primary application:</strong> Website navigation bars, corporate letterhead, email signatures, presentation titles, and legal agreements.
            </p>
            <div className="flex items-center justify-between pt-2 border-t border-neutral-800">
              <span className="text-[11px] font-mono text-neutral-500">Horizontal Aspect Ratio</span>
              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => handleCopySvg(primaryHorizontalSvg, 'v1')}
                  className="p-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-xs flex items-center gap-1"
                  title="Copy SVG"
                >
                  {copiedKey === 'v1' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
                <button
                  onClick={() => handleDownloadSvg(primaryHorizontalSvg, `${caseStudy.id}-primary-horizontal`)}
                  className="p-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-xs flex items-center gap-1"
                  title="Download SVG"
                >
                  <Download className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Variation 2: Secondary Logo (Stacked / Vertical Lockup) */}
        <div className="bg-neutral-900 border border-neutral-800 rounded-2xl overflow-hidden flex flex-col justify-between shadow-lg">
          <div className="p-4 bg-neutral-850 border-b border-neutral-800 flex items-center justify-between">
            <div>
              <span className="text-xs font-mono text-sky-400 font-semibold block">VARIATION 2</span>
              <h3 className="text-sm font-bold text-white font-display">Secondary Logo (Stacked)</h3>
            </div>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-neutral-800 text-neutral-300">
              Vertical Lockup
            </span>
          </div>

          {/* Canvas Box */}
          <div className="p-8 bg-white min-h-[220px] flex items-center justify-center border-b border-neutral-200">
            <div 
              className="w-full max-w-[180px] drop-shadow-sm"
              dangerouslySetInnerHTML={{ __html: secondaryStackedSvg }} 
            />
          </div>

          <div className="p-4 space-y-3">
            <p className="text-xs text-neutral-300">
              <strong>Primary application:</strong> Center-aligned banners, tote bags, packaging boxes, mobile splash screens, and vertical signage totems.
            </p>
            <div className="flex items-center justify-between pt-2 border-t border-neutral-800">
              <span className="text-[11px] font-mono text-neutral-500">Vertical Aspect Ratio</span>
              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => handleCopySvg(secondaryStackedSvg, 'v2')}
                  className="p-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-xs flex items-center gap-1"
                  title="Copy SVG"
                >
                  {copiedKey === 'v2' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
                <button
                  onClick={() => handleDownloadSvg(secondaryStackedSvg, `${caseStudy.id}-secondary-stacked`)}
                  className="p-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-xs flex items-center gap-1"
                  title="Download SVG"
                >
                  <Download className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Variation 3: Icon-Only / Favicon / Social Avatar */}
        <div className="bg-neutral-900 border border-neutral-800 rounded-2xl overflow-hidden flex flex-col justify-between shadow-lg">
          <div className="p-4 bg-neutral-850 border-b border-neutral-800 flex items-center justify-between">
            <div>
              <span className="text-xs font-mono text-emerald-400 font-semibold block">VARIATION 3</span>
              <h3 className="text-sm font-bold text-white font-display">Icon-Only (Symbol Mark)</h3>
            </div>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-neutral-800 text-neutral-300">
              Square / Circle 1:1
            </span>
          </div>

          {/* Canvas Box */}
          <div className="p-8 bg-slate-100 min-h-[220px] flex items-center justify-center border-b border-neutral-200">
            <div className="w-24 h-24 rounded-2xl bg-white p-3 border border-neutral-300 shadow-md flex items-center justify-center">
              <div 
                className="w-16 h-16 drop-shadow-sm"
                dangerouslySetInnerHTML={{ __html: iconOnlySvg }} 
              />
            </div>
          </div>

          <div className="p-4 space-y-3">
            <p className="text-xs text-neutral-300">
              <strong>Primary application:</strong> Browser favicons, iOS/Android home screen app icon, LinkedIn/X profile avatars, and zipper pulls.
            </p>
            <div className="flex items-center justify-between pt-2 border-t border-neutral-800">
              <span className="text-[11px] font-mono text-neutral-500">1:1 Square Silhouette</span>
              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => handleCopySvg(iconOnlySvg, 'v3')}
                  className="p-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-xs flex items-center gap-1"
                  title="Copy SVG"
                >
                  {copiedKey === 'v3' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
                <button
                  onClick={() => handleDownloadSvg(iconOnlySvg, `${caseStudy.id}-icon-mark`)}
                  className="p-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-xs flex items-center gap-1"
                  title="Download SVG"
                >
                  <Download className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Variation 4: Black & White Monochrome (100% K) */}
        <div className="bg-neutral-900 border border-neutral-800 rounded-2xl overflow-hidden flex flex-col justify-between shadow-lg">
          <div className="p-4 bg-neutral-850 border-b border-neutral-800 flex items-center justify-between">
            <div>
              <span className="text-xs font-mono text-neutral-300 font-semibold block">VARIATION 4</span>
              <h3 className="text-sm font-bold text-white font-display">Monochrome Black &amp; White</h3>
            </div>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-neutral-800 text-neutral-300">
              100% Black (K)
            </span>
          </div>

          {/* Canvas Box */}
          <div className="p-8 bg-white min-h-[220px] flex items-center justify-center border-b border-neutral-200 grayscale">
            <div 
              className="w-full max-w-[260px]"
              dangerouslySetInnerHTML={{ __html: primaryHorizontalSvg }} 
            />
          </div>

          <div className="p-4 space-y-3">
            <p className="text-xs text-neutral-300">
              <strong>Primary application:</strong> Black-and-white fax, newspaper advertisements, laser engraving, thermal receipts, and single-color foil debossing.
            </p>
            <div className="flex items-center justify-between pt-2 border-t border-neutral-800">
              <span className="text-[11px] font-mono text-neutral-500">100% Black Single-Ink</span>
              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => handleCopySvg(primaryHorizontalSvg, 'v4')}
                  className="p-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-xs flex items-center gap-1"
                  title="Copy SVG"
                >
                  {copiedKey === 'v4' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
                <button
                  onClick={() => handleDownloadSvg(primaryHorizontalSvg, `${caseStudy.id}-monochrome-black`)}
                  className="p-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-xs flex items-center gap-1"
                  title="Download SVG"
                >
                  <Download className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Variation 5: Light-Background Version */}
        <div className="bg-neutral-900 border border-neutral-800 rounded-2xl overflow-hidden flex flex-col justify-between shadow-lg">
          <div className="p-4 bg-neutral-850 border-b border-neutral-800 flex items-center justify-between">
            <div>
              <span className="text-xs font-mono text-amber-400 font-semibold block">VARIATION 5</span>
              <h3 className="text-sm font-bold text-white font-display">Light-Background Master</h3>
            </div>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-500/10 text-amber-300 border border-amber-500/20">
              <Sun className="w-3 h-3 inline mr-1" />
              Day / Paper
            </span>
          </div>

          {/* Canvas Box */}
          <div className="p-8 bg-neutral-100 min-h-[220px] flex items-center justify-center border-b border-neutral-200">
            <div 
              className="w-full max-w-[260px] drop-shadow-sm"
              dangerouslySetInnerHTML={{ __html: primaryHorizontalSvg }} 
            />
          </div>

          <div className="p-4 space-y-3">
            <p className="text-xs text-neutral-300">
              <strong>Primary application:</strong> Standard bright web viewports, white uncoated paper stock, office stationery, and invoice PDF documents.
            </p>
            <div className="flex items-center justify-between pt-2 border-t border-neutral-800">
              <span className="text-[11px] font-mono text-neutral-500">Standard Positive Contrast</span>
              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => handleCopySvg(primaryHorizontalSvg, 'v5')}
                  className="p-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-xs flex items-center gap-1"
                  title="Copy SVG"
                >
                  {copiedKey === 'v5' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
                <button
                  onClick={() => handleDownloadSvg(primaryHorizontalSvg, `${caseStudy.id}-light-bg`)}
                  className="p-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-xs flex items-center gap-1"
                  title="Download SVG"
                >
                  <Download className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Variation 6: Dark-Background Version (Knockout Reverse) */}
        <div className="bg-neutral-900 border border-neutral-800 rounded-2xl overflow-hidden flex flex-col justify-between shadow-lg">
          <div className="p-4 bg-neutral-850 border-b border-neutral-800 flex items-center justify-between">
            <div>
              <span className="text-xs font-mono text-purple-400 font-semibold block">VARIATION 6</span>
              <h3 className="text-sm font-bold text-white font-display">Dark-Background (Knockout)</h3>
            </div>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-purple-500/10 text-purple-300 border border-purple-500/20">
              <Moon className="w-3 h-3 inline mr-1" />
              Dark Mode / OLED
            </span>
          </div>

          {/* Canvas Box */}
          <div className="p-8 bg-neutral-950 min-h-[220px] flex items-center justify-center border-b border-neutral-800">
            <div 
              className="w-full max-w-[260px] drop-shadow-sm"
              dangerouslySetInnerHTML={{ __html: darkBackgroundSvg }} 
            />
          </div>

          <div className="p-4 space-y-3">
            <p className="text-xs text-neutral-300">
              <strong>Primary application:</strong> Dark mode web applications, evening event signage, carbon-fiber corporate plaques, and dark vehicle wraps.
            </p>
            <div className="flex items-center justify-between pt-2 border-t border-neutral-800">
              <span className="text-[11px] font-mono text-neutral-500">Reverse Negative Contrast</span>
              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => handleCopySvg(darkBackgroundSvg, 'v6')}
                  className="p-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-xs flex items-center gap-1"
                  title="Copy SVG"
                >
                  {copiedKey === 'v6' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
                <button
                  onClick={() => handleDownloadSvg(darkBackgroundSvg, `${caseStudy.id}-dark-bg`)}
                  className="p-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-xs flex items-center gap-1"
                  title="Download SVG"
                >
                  <Download className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        </div>

      </div>

      {/* Production Readiness Summary */}
      <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-6 sm:p-8 flex flex-col sm:flex-row items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <h4 className="text-base font-bold text-white font-display">
              All 6 Production Variations Validated &amp; Ready
            </h4>
            <p className="text-xs text-neutral-400 mt-0.5">
              Every lockup passes WCAG AA 4.5:1 legibility benchmarks and complies with universal vector standards.
            </p>
          </div>
        </div>

        <button
          onClick={onProceedToGuidelines}
          className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-sm transition-all shadow-lg shadow-indigo-600/20"
        >
          <span>Proceed to Step 4: Mini Brand Guidelines</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>

    </div>
  );
};
