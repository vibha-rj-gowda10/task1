import React, { useState } from 'react';
import { 
  BookOpen, 
  Maximize2, 
  Check, 
  X, 
  CreditCard, 
  Smartphone, 
  Globe, 
  FileText, 
  Copy, 
  ArrowRight,
  ShieldAlert,
  ShieldCheck,
  Palette,
  Type
} from 'lucide-react';
import { CaseStudy, RedesignVersion } from '../types/brand';

interface BrandGuidelinesProps {
  caseStudy: CaseStudy;
  selectedVersion: RedesignVersion;
  onProceedToDeck: () => void;
}

export const BrandGuidelines: React.FC<BrandGuidelinesProps> = ({
  caseStudy,
  selectedVersion,
  onProceedToDeck,
}) => {
  const { guidelines } = caseStudy;
  const [copiedCode, setCopiedCode] = useState<string | null>(null);
  const [activeMockup, setActiveMockup] = useState<'card' | 'mobile' | 'web' | 'doc'>('card');
  const [cardFlipped, setCardFlipped] = useState<boolean>(false);

  const handleCopyCode = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedCode(text);
    setTimeout(() => setCopiedCode(null), 2000);
  };

  const primaryLockupSvg = selectedVersion.lockupSvg('light', 'horizontal');
  const darkLockupSvg = selectedVersion.lockupSvg('dark', 'horizontal');
  const iconSvg = selectedVersion.symbolSvg('#ffffff', '#38bdf8');

  return (
    <div className="space-y-8 animate-fade-in">
      
      {/* Top Banner */}
      <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-6 sm:p-8">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono font-medium px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                PHASE 4: MINI BRAND GUIDELINES MANUAL
              </span>
              <span className="text-xs text-neutral-400 font-mono">
                Official Standards &amp; Identity System
              </span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight font-display">
              Brand Identity Guidelines: {caseStudy.name}
            </h2>
            <p className="text-neutral-400 text-sm max-w-3xl leading-relaxed">
              These guidelines define the non-negotiable rules for logo clear space, minimum sizing thresholds, typography scales, color formulas, prohibited distortions, and real-world touchpoint applications.
            </p>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={onProceedToDeck}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-medium text-sm transition-all shadow-lg shadow-indigo-600/20"
            >
              <span>View 14-Slide Submission Deck</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Section 1 & 2: Clear Space & Minimum Sizing */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Clear Space Exclusion Zone (7 cols) */}
        <div className="lg:col-span-7 bg-neutral-900 border border-neutral-800 rounded-2xl p-6 sm:p-8 space-y-6">
          <div>
            <div className="flex items-center gap-2 text-indigo-400 font-bold text-xs uppercase tracking-wider">
              <Maximize2 className="w-4 h-4" />
              <span>1. Clear Space Exclusion Zone</span>
            </div>
            <h3 className="text-lg font-bold text-white font-display mt-1">
              Minimum Exclusion Perimeter: {guidelines.clearSpaceRatio}
            </h3>
            <p className="text-xs text-neutral-400 mt-1 leading-relaxed">
              {guidelines.clearSpaceExplanation}
            </p>
          </div>

          {/* Interactive Visual Clear Space Bounding Box */}
          <div className="relative p-12 bg-white rounded-xl border border-neutral-300 flex items-center justify-center overflow-hidden shadow-inner">
            
            {/* Outer Exclusion Bounding Box */}
            <div className="relative border-2 border-dashed border-indigo-400/80 p-8 rounded-lg bg-indigo-50/20">
              
              {/* Corner "X" dimension markers */}
              <div className="absolute -top-3 left-3 bg-indigo-600 text-white text-[10px] font-mono px-1.5 py-0.2 rounded font-bold">
                X
              </div>
              <div className="absolute -bottom-3 right-3 bg-indigo-600 text-white text-[10px] font-mono px-1.5 py-0.2 rounded font-bold">
                X
              </div>
              <div className="absolute top-3 -left-3 bg-indigo-600 text-white text-[10px] font-mono px-1.5 py-0.2 rounded font-bold">
                X
              </div>
              <div className="absolute top-3 -right-3 bg-indigo-600 text-white text-[10px] font-mono px-1.5 py-0.2 rounded font-bold">
                X
              </div>

              {/* Logo inside */}
              <div className="w-full max-w-[280px]">
                <div dangerouslySetInnerHTML={{ __html: primaryLockupSvg }} />
              </div>

              {/* Exclusion boundary line labels */}
              <div className="absolute inset-0 pointer-events-none border border-indigo-500/20"></div>
            </div>

            <div className="absolute bottom-2 right-3 text-[10px] font-mono text-neutral-500">
              Rule: Keep all typography, page margins, and imagery outside dashed perimeter
            </div>
          </div>
        </div>

        {/* Minimum Size Rules (5 cols) */}
        <div className="lg:col-span-5 bg-neutral-900 border border-neutral-800 rounded-2xl p-6 sm:p-8 space-y-6 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 text-sky-400 font-bold text-xs uppercase tracking-wider">
              <BookOpen className="w-4 h-4" />
              <span>2. Minimum Reproduction Sizes</span>
            </div>
            <h3 className="text-lg font-bold text-white font-display mt-1">
              Legibility Thresholds
            </h3>
            <p className="text-xs text-neutral-400 mt-1 leading-relaxed">
              To prevent optical collapse of hairline stems and micro-typography, never reproduce the logo below these minimum dimensions.
            </p>
          </div>

          <div className="space-y-4">
            
            {/* Digital Min Size */}
            <div className="bg-neutral-950 border border-neutral-800 rounded-xl p-4 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-white">Digital Screens (Web / UI)</span>
                <span className="text-xs font-mono font-semibold px-2 py-0.5 rounded bg-sky-500/10 text-sky-400 border border-sky-500/20">
                  {guidelines.minSizeDigital}
                </span>
              </div>
              <p className="text-[11px] text-neutral-400">
                Below this height, switch strictly to the standalone 1:1 icon mark to preserve legibility.
              </p>
            </div>

            {/* Print Min Size */}
            <div className="bg-neutral-950 border border-neutral-800 rounded-xl p-4 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-white">Physical Print (300 DPI)</span>
                <span className="text-xs font-mono font-semibold px-2 py-0.5 rounded bg-amber-500/10 text-amber-400 border border-amber-500/20">
                  {guidelines.minSizePrint}
                </span>
              </div>
              <p className="text-[11px] text-neutral-400">
                Minimum physical width for offset lithography, screenprinting, embroidery, and stationery.
              </p>
            </div>

          </div>

          <div className="p-3 bg-neutral-850 rounded-xl border border-neutral-800 text-[11px] text-neutral-400 font-mono">
            Tip: For embroidery on cotton caps, increase minimum size by 25% due to thread gauge limits.
          </div>
        </div>

      </div>

      {/* Section 3: Recommended Colors System */}
      <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-6 sm:p-8 space-y-6">
        <div>
          <div className="flex items-center gap-2 text-indigo-400 font-bold text-xs uppercase tracking-wider">
            <Palette className="w-4 h-4" />
            <span>3. Recommended Color Hierarchy</span>
          </div>
          <h3 className="text-lg font-bold text-white font-display mt-1">
            Master Color Palette &amp; Mathematical Specifications
          </h3>
          <p className="text-xs text-neutral-400 mt-1">
            Standardized color values across digital (RGB/HEX), commercial print (CMYK), and solid ink matching (Pantone).
          </p>
        </div>

        {/* Color Bars Proportion visualization */}
        <div className="h-6 w-full rounded-xl overflow-hidden flex shadow-inner">
          <div className="bg-slate-900 flex-1 flex items-center justify-center text-[10px] font-mono text-white font-bold" title="Primary 60%">
            Primary (60%)
          </div>
          <div className="bg-sky-600 w-1/4 flex items-center justify-center text-[10px] font-mono text-white font-bold" title="Secondary 25%">
            Secondary (25%)
          </div>
          <div className="bg-slate-400 w-1/12 flex items-center justify-center text-[10px] font-mono text-slate-900 font-bold" title="Accent 10%">
            Accent
          </div>
          <div className="bg-neutral-100 w-1/12 flex items-center justify-center text-[10px] font-mono text-slate-800 font-bold" title="Neutral 5%">
            Light
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {selectedVersion.colors.map((c, idx) => (
            <div key={idx} className="bg-neutral-950 border border-neutral-800 rounded-xl p-4 space-y-3">
              <div 
                className="w-full h-16 rounded-lg shadow-inner border border-white/10"
                style={{ backgroundColor: c.hex }}
              />
              <div>
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-white">{c.name}</span>
                  <span className="text-[10px] font-mono text-indigo-400">{c.role}</span>
                </div>
                <div className="text-[11px] font-mono text-neutral-400 mt-1">
                  HEX: {c.hex}
                </div>
                <div className="text-[10px] font-mono text-neutral-500">
                  RGB: {c.rgb}
                </div>
                <div className="text-[10px] font-mono text-neutral-500">
                  CMYK: {c.cmyk}
                </div>
                {c.pantone && (
                  <div className="text-[10px] font-mono text-neutral-400 font-semibold mt-0.5">
                    Pantone: {c.pantone}
                  </div>
                )}
              </div>
              <button
                onClick={() => handleCopyCode(c.hex)}
                className="w-full py-1 rounded bg-neutral-900 hover:bg-neutral-800 text-neutral-400 hover:text-white text-[10px] font-mono transition-colors flex items-center justify-center gap-1"
              >
                {copiedCode === c.hex ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                <span>Copy HEX</span>
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Section 4: Typography Hierarchy */}
      <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-6 sm:p-8 space-y-6">
        <div>
          <div className="flex items-center gap-2 text-sky-400 font-bold text-xs uppercase tracking-wider">
            <Type className="w-4 h-4" />
            <span>4. Typography System &amp; Hierarchy</span>
          </div>
          <h3 className="text-lg font-bold text-white font-display mt-1">
            Font Families &amp; Typographic Roles
          </h3>
          <p className="text-xs text-neutral-400 mt-1">
            Engineered typographic pairings ensuring hierarchy from bold brand headlines to small-print legal legibility.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Primary Typeface */}
          <div className="bg-neutral-950 border border-neutral-800 rounded-xl p-5 space-y-3">
            <span className="text-[10px] font-mono text-indigo-400 uppercase font-semibold">Primary Display Typeface</span>
            <div className="text-2xl font-bold text-white font-display">
              {selectedVersion.typography.primaryFont.split('&')[0].trim()}
            </div>
            <p className="text-xs text-neutral-300">
              Used for master logo wordmarks, hero campaign titles, and billboard headlines. Engineered with architectural precision.
            </p>
            <div className="p-3 bg-neutral-900 rounded-lg border border-neutral-800 font-display text-sm tracking-widest text-neutral-200">
              ABCDEFGHIJKLMNOPQRSTUVWXYZ<br />
              abcdefghijklmnopqrstuvwxyz 0123456789
            </div>
          </div>

          {/* Secondary Typeface */}
          <div className="bg-neutral-950 border border-neutral-800 rounded-xl p-5 space-y-3">
            <span className="text-[10px] font-mono text-sky-400 uppercase font-semibold">Secondary Text &amp; UI Typeface</span>
            <div className="text-2xl font-bold text-white">
              Plus Jakarta Sans
            </div>
            <p className="text-xs text-neutral-300">
              Used for subheadings, navigation items, body copy, technical data tables, and mobile app interfaces.
            </p>
            <div className="p-3 bg-neutral-900 rounded-lg border border-neutral-800 text-sm text-neutral-200">
              ABCDEFGHIJKLMNOPQRSTUVWXYZ<br />
              abcdefghijklmnopqrstuvwxyz 0123456789
            </div>
          </div>
        </div>
      </div>

      {/* Section 5: Brand Do's & Don'ts */}
      <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-6 sm:p-8 space-y-6">
        <div>
          <div className="flex items-center gap-2 text-rose-400 font-bold text-xs uppercase tracking-wider">
            <ShieldAlert className="w-4 h-4" />
            <span>5. Logo Misuse &amp; Prohibitions (Do's &amp; Don'ts)</span>
          </div>
          <h3 className="text-lg font-bold text-white font-display mt-1">
            Rules to Protect Brand Equity
          </h3>
          <p className="text-xs text-neutral-400 mt-1">
            Consistency is vital. Never alter, embellish, or distort the logo in any of the following unauthorized manners.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          
          {/* Don't 1: Stretch / Distort */}
          <div className="bg-neutral-950 border border-neutral-800 rounded-xl p-4 space-y-3">
            <div className="h-28 bg-white rounded-lg flex items-center justify-center p-4 overflow-hidden border border-neutral-200 relative">
              <div className="w-full max-w-[200px] scale-x-150 scale-y-75 opacity-90">
                <div dangerouslySetInnerHTML={{ __html: primaryLockupSvg }} />
              </div>
              <div className="absolute top-2 right-2 w-6 h-6 rounded-full bg-rose-600 text-white flex items-center justify-center shadow">
                <X className="w-3.5 h-3.5" />
              </div>
            </div>
            <div>
              <div className="text-xs font-bold text-rose-400 uppercase">Don't: Distort or Stretch</div>
              <p className="text-[11px] text-neutral-400 mt-0.5">
                Always scale proportionately with constrained 1:1 aspect ratio.
              </p>
            </div>
          </div>

          {/* Don't 2: Unauthorized Colors */}
          <div className="bg-neutral-950 border border-neutral-800 rounded-xl p-4 space-y-3">
            <div className="h-28 bg-white rounded-lg flex items-center justify-center p-4 overflow-hidden border border-neutral-200 relative">
              <div className="w-full max-w-[200px] hue-rotate-90 saturate-200">
                <div dangerouslySetInnerHTML={{ __html: primaryLockupSvg }} />
              </div>
              <div className="absolute top-2 right-2 w-6 h-6 rounded-full bg-rose-600 text-white flex items-center justify-center shadow">
                <X className="w-3.5 h-3.5" />
              </div>
            </div>
            <div>
              <div className="text-xs font-bold text-rose-400 uppercase">Don't: Swap Brand Colors</div>
              <p className="text-[11px] text-neutral-400 mt-0.5">
                Never invent random tints or alter designated corporate hues.
              </p>
            </div>
          </div>

          {/* Don't 3: Skeuomorphic Drop Shadows */}
          <div className="bg-neutral-950 border border-neutral-800 rounded-xl p-4 space-y-3">
            <div className="h-28 bg-white rounded-lg flex items-center justify-center p-4 overflow-hidden border border-neutral-200 relative">
              <div className="w-full max-w-[200px] [filter:drop-shadow(8px_8px_4px_rgba(0,0,0,0.8))]">
                <div dangerouslySetInnerHTML={{ __html: primaryLockupSvg }} />
              </div>
              <div className="absolute top-2 right-2 w-6 h-6 rounded-full bg-rose-600 text-white flex items-center justify-center shadow">
                <X className="w-3.5 h-3.5" />
              </div>
            </div>
            <div>
              <div className="text-xs font-bold text-rose-400 uppercase">Don't: Add 3D Drop Shadows</div>
              <p className="text-[11px] text-neutral-400 mt-0.5">
                Keep shapes clean, flat, and vector-pure without archaic 2000s filters.
              </p>
            </div>
          </div>

          {/* Don't 4: Cluttered Background */}
          <div className="bg-neutral-950 border border-neutral-800 rounded-xl p-4 space-y-3">
            <div className="h-28 bg-[repeating-linear-gradient(45deg,#f43f5e,#f43f5e_10px,#3b82f6_10px,#3b82f6_20px)] rounded-lg flex items-center justify-center p-4 overflow-hidden border border-neutral-200 relative">
              <div className="w-full max-w-[200px] bg-transparent">
                <div dangerouslySetInnerHTML={{ __html: primaryLockupSvg }} />
              </div>
              <div className="absolute top-2 right-2 w-6 h-6 rounded-full bg-rose-600 text-white flex items-center justify-center shadow">
                <X className="w-3.5 h-3.5" />
              </div>
            </div>
            <div>
              <div className="text-xs font-bold text-rose-400 uppercase">Don't: Place on Busy Patterns</div>
              <p className="text-[11px] text-neutral-400 mt-0.5">
                Never position over high-frequency noisy photographs or patterns.
              </p>
            </div>
          </div>

          {/* Do 1: Preserve Exclusion Zone */}
          <div className="bg-neutral-950 border border-neutral-800 rounded-xl p-4 space-y-3">
            <div className="h-28 bg-white rounded-lg flex items-center justify-center p-4 overflow-hidden border border-neutral-200 relative">
              <div className="border border-dashed border-indigo-400 p-2 rounded">
                <div className="w-full max-w-[170px]">
                  <div dangerouslySetInnerHTML={{ __html: primaryLockupSvg }} />
                </div>
              </div>
              <div className="absolute top-2 right-2 w-6 h-6 rounded-full bg-emerald-600 text-white flex items-center justify-center shadow">
                <Check className="w-3.5 h-3.5" />
              </div>
            </div>
            <div>
              <div className="text-xs font-bold text-emerald-400 uppercase">Do: Preserve 1X Clear Space</div>
              <p className="text-[11px] text-neutral-400 mt-0.5">
                Always ensure clean breathing room on all 4 perimeter borders.
              </p>
            </div>
          </div>

          {/* Do 2: Pure Monochrome in Single-Ink */}
          <div className="bg-neutral-950 border border-neutral-800 rounded-xl p-4 space-y-3">
            <div className="h-28 bg-neutral-900 rounded-lg flex items-center justify-center p-4 overflow-hidden border border-neutral-700 relative">
              <div className="w-full max-w-[180px]">
                <div dangerouslySetInnerHTML={{ __html: darkLockupSvg }} />
              </div>
              <div className="absolute top-2 right-2 w-6 h-6 rounded-full bg-emerald-600 text-white flex items-center justify-center shadow">
                <Check className="w-3.5 h-3.5" />
              </div>
            </div>
            <div>
              <div className="text-xs font-bold text-emerald-400 uppercase">Do: Use Knockout on Dark</div>
              <p className="text-[11px] text-neutral-400 mt-0.5">
                Use the approved white knockout version for dark background media.
              </p>
            </div>
          </div>

        </div>
      </div>

      {/* Section 6: Live Interactive Real-World Mockups */}
      <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-6 sm:p-8 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-indigo-400 font-bold text-xs uppercase tracking-wider">
              <CreditCard className="w-4 h-4" />
              <span>6. Recommended Real-World Touchpoints</span>
            </div>
            <h3 className="text-lg font-bold text-white font-display mt-1">
              Live Mockup Simulation
            </h3>
            <p className="text-xs text-neutral-400 mt-1">
              Preview how the redesigned system functions across business cards, mobile applications, web navigation, and corporate documentation.
            </p>
          </div>

          {/* Mockup Tabs */}
          <div className="flex items-center bg-neutral-950 p-1 rounded-xl border border-neutral-800">
            <button
              onClick={() => setActiveMockup('card')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                activeMockup === 'card' ? 'bg-indigo-600 text-white' : 'text-neutral-400 hover:text-white'
              }`}
            >
              <CreditCard className="w-3.5 h-3.5" />
              <span>Business Card</span>
            </button>
            <button
              onClick={() => setActiveMockup('mobile')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                activeMockup === 'mobile' ? 'bg-indigo-600 text-white' : 'text-neutral-400 hover:text-white'
              }`}
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span>Mobile App</span>
            </button>
            <button
              onClick={() => setActiveMockup('web')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                activeMockup === 'web' ? 'bg-indigo-600 text-white' : 'text-neutral-400 hover:text-white'
              }`}
            >
              <Globe className="w-3.5 h-3.5" />
              <span>Website Header</span>
            </button>
            <button
              onClick={() => setActiveMockup('doc')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                activeMockup === 'doc' ? 'bg-indigo-600 text-white' : 'text-neutral-400 hover:text-white'
              }`}
            >
              <FileText className="w-3.5 h-3.5" />
              <span>Letterhead</span>
            </button>
          </div>
        </div>

        {/* Mockup Stage */}
        <div className="bg-neutral-950 border border-neutral-800 rounded-xl p-8 min-h-[380px] flex items-center justify-center">
          
          {/* Mockup 1: Business Card */}
          {activeMockup === 'card' && (
            <div className="space-y-4 flex flex-col items-center">
              <div 
                onClick={() => setCardFlipped(!cardFlipped)}
                className="cursor-pointer transition-transform duration-300 hover:scale-[1.02] shadow-2xl"
              >
                {!cardFlipped ? (
                  // Front: Premium Dark Minimal Card
                  <div className="w-[380px] sm:w-[420px] h-[230px] rounded-2xl bg-neutral-900 border border-neutral-700/80 p-8 flex flex-col justify-between shadow-2xl relative overflow-hidden">
                    <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500/10 rounded-full blur-2xl pointer-events-none"></div>
                    
                    <div className="w-40">
                      <div dangerouslySetInnerHTML={{ __html: darkLockupSvg }} />
                    </div>

                    <div className="flex items-end justify-between border-t border-neutral-800 pt-4">
                      <div>
                        <div className="text-sm font-bold text-white font-display">Alex Morgan</div>
                        <div className="text-[11px] font-mono text-indigo-400">Chief Brand Officer</div>
                      </div>
                      <div className="text-right text-[10px] font-mono text-neutral-400 leading-tight">
                        hq@{caseStudy.id}.com<br />
                        +1 (800) 555-0199
                      </div>
                    </div>
                  </div>
                ) : (
                  // Back: Pure White Embossed Card
                  <div className="w-[380px] sm:w-[420px] h-[230px] rounded-2xl bg-white border border-neutral-300 p-8 flex items-center justify-center shadow-2xl relative">
                    <div className="w-48 drop-shadow-sm">
                      <div dangerouslySetInnerHTML={{ __html: primaryLockupSvg }} />
                    </div>
                  </div>
                )}
              </div>

              <div className="text-xs text-neutral-500 font-mono">
                Click card to flip ({cardFlipped ? 'Showing Back' : 'Showing Front: Dark Executive Stock'})
              </div>
            </div>
          )}

          {/* Mockup 2: Mobile App Screen & Home Icon */}
          {activeMockup === 'mobile' && (
            <div className="flex flex-col sm:flex-row items-center justify-center gap-8">
              {/* Home Screen Icon */}
              <div className="text-center space-y-2">
                <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-slate-900 to-indigo-950 border border-indigo-500/40 p-4 shadow-xl flex items-center justify-center">
                  <div 
                    className="w-12 h-12"
                    dangerouslySetInnerHTML={{ __html: iconSvg }} 
                  />
                </div>
                <div className="text-xs font-mono text-neutral-400">iOS App Icon</div>
              </div>

              {/* Smartphone Frame with App Header */}
              <div className="w-64 h-[340px] rounded-3xl bg-neutral-900 border-4 border-neutral-700 shadow-2xl overflow-hidden flex flex-col justify-between">
                {/* Status Bar */}
                <div className="px-5 py-2 bg-neutral-950 flex items-center justify-between text-[10px] font-mono text-neutral-400 border-b border-neutral-800">
                  <span>9:41</span>
                  <span>5G · 100%</span>
                </div>
                
                {/* In-App Header */}
                <div className="p-4 bg-neutral-950/80 border-b border-neutral-800 flex items-center justify-between">
                  <div className="w-24">
                    <div dangerouslySetInnerHTML={{ __html: darkLockupSvg }} />
                  </div>
                  <div className="w-6 h-6 rounded-full bg-neutral-800 border border-neutral-700"></div>
                </div>

                {/* App Content Placeholder */}
                <div className="p-4 flex-1 space-y-3">
                  <div className="h-20 rounded-xl bg-neutral-850 p-3 space-y-2 border border-neutral-800">
                    <div className="h-3 w-2/3 bg-indigo-500/40 rounded"></div>
                    <div className="h-2 w-1/2 bg-neutral-700 rounded"></div>
                  </div>
                  <div className="h-16 rounded-xl bg-neutral-850 p-3 space-y-2 border border-neutral-800">
                    <div className="h-3 w-1/3 bg-neutral-700 rounded"></div>
                  </div>
                </div>

                {/* Bottom Home Indicator */}
                <div className="h-5 flex items-center justify-center bg-neutral-950">
                  <div className="w-24 h-1 bg-neutral-700 rounded-full"></div>
                </div>
              </div>
            </div>
          )}

          {/* Mockup 3: Modern Web Header */}
          {activeMockup === 'web' && (
            <div className="w-full max-w-2xl bg-neutral-900 rounded-xl border border-neutral-800 overflow-hidden shadow-2xl">
              {/* Browser chrome */}
              <div className="px-4 py-2.5 bg-neutral-950 border-b border-neutral-800 flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-neutral-700"></span>
                <span className="w-2.5 h-2.5 rounded-full bg-neutral-700"></span>
                <span className="w-2.5 h-2.5 rounded-full bg-neutral-700"></span>
                <div className="flex-1 max-w-xs mx-auto bg-neutral-900 border border-neutral-800 rounded px-2.5 py-0.5 text-[10px] font-mono text-neutral-400 text-center">
                  https://www.{caseStudy.id}.com
                </div>
              </div>

              {/* Website Navbar */}
              <div className="px-6 py-4 bg-white border-b border-neutral-200 flex items-center justify-between">
                <div className="w-36">
                  <div dangerouslySetInnerHTML={{ __html: primaryLockupSvg }} />
                </div>
                <div className="hidden sm:flex items-center gap-4 text-xs font-semibold text-neutral-600">
                  <span className="text-neutral-900">Solutions</span>
                  <span>Platform</span>
                  <span>Customers</span>
                  <span>Company</span>
                </div>
                <button className="px-3 py-1.5 rounded-lg bg-indigo-600 text-white text-xs font-semibold shadow-sm">
                  Sign In
                </button>
              </div>

              {/* Web Hero Preview */}
              <div className="p-8 bg-slate-50 text-center space-y-3">
                <div className="text-lg font-bold text-slate-900 font-display">
                  Intelligent Global Infrastructure
                </div>
                <div className="text-xs text-slate-500 max-w-md mx-auto">
                  Enterprise-grade speed, precision telemetry, and unified supply operations.
                </div>
              </div>
            </div>
          )}

          {/* Mockup 4: Corporate Letterhead */}
          {activeMockup === 'doc' && (
            <div className="w-full max-w-md bg-white rounded-lg shadow-2xl border border-neutral-300 p-8 space-y-6 text-slate-800">
              <div className="flex items-start justify-between border-b border-slate-200 pb-4">
                <div className="w-36">
                  <div dangerouslySetInnerHTML={{ __html: primaryLockupSvg }} />
                </div>
                <div className="text-right text-[10px] font-mono text-slate-500 leading-tight">
                  One World Trade Center<br />
                  Suite 4800, New York, NY<br />
                  contact@{caseStudy.id}.com
                </div>
              </div>

              <div className="space-y-2 text-xs text-slate-700 leading-relaxed">
                <div className="font-semibold text-slate-900">MEMORANDUM: BRAND ARCHITECTURE ROLLOUT</div>
                <p>
                  To the Board of Directors: This document establishes the formal deployment of our modernized visual identity system. The simplified vector architecture unlocks scalable rendering across all global fleet assets and digital interfaces.
                </p>
                <p className="text-slate-500 text-[11px]">
                  Authorized by Corporate Design Council.
                </p>
              </div>
            </div>
          )}

        </div>
      </div>

      {/* Bottom CTA to Presentation Deck */}
      <div className="pt-4 flex flex-col sm:flex-row items-center justify-between gap-4 border-t border-neutral-800">
        <div className="text-xs text-neutral-400">
          Guidelines complete. Proceed to generate and present the 14-slide internship submission deck.
        </div>
        <button
          onClick={onProceedToDeck}
          className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-sm transition-all shadow-lg shadow-indigo-600/20"
        >
          <span>Open Full 14-Slide Presentation Deck</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>

    </div>
  );
};
