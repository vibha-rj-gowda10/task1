export interface ColorSwatch {
  name: string;
  hex: string;
  rgb: string;
  cmyk: string;
  pantone?: string;
  role: 'Primary' | 'Secondary' | 'Accent' | 'Neutral-Dark' | 'Neutral-Light';
  rationale: string;
}

export interface TypographySpec {
  role: string;
  fontFamily: string;
  weight: string;
  sampleText: string;
  usage: string;
  characteristics: string;
}

export interface RedesignVersion {
  id: 'versionA' | 'versionB' | 'versionC';
  label: string; // 'VERSION A', etc.
  styleTitle: string; // 'Minimal & Modern'
  tagline: string;
  concept: string;
  symbolMeaning: string;
  symbolSvg: (color: string, accent?: string) => string;
  lockupSvg: (mode: 'light' | 'dark' | 'mono', layout?: 'horizontal' | 'vertical') => string;
  typography: {
    primaryFont: string;
    style: string;
    rationale: string;
    specs: TypographySpec[];
  };
  colors: ColorSwatch[];
  improvements: string[];
  keyAttributes: string[];
  bestSuitedFor: string;
}

export interface OriginalLogoAnalysis {
  brandName: string;
  industry: string;
  established: string;
  originalSvgOrImg: string;
  isSvg: boolean;
  executiveSummary: string;
  // 1. Symbol/Icon
  symbolAnalysis: {
    description: string;
    flaws: string[];
    metaphor: string;
  };
  // 2. Typography
  typographyAnalysis: {
    fontType: string;
    critique: string;
    legibilityIssue: string;
  };
  // 3. Colors
  colorsAnalysis: {
    originalColors: { name: string; hex: string; note: string }[];
    harmonyCritique: string;
    contrastIssue: string;
  };
  // 4. Shape & Composition
  shapeComposition: {
    compositionType: string;
    balance: string;
    scalabilityScore: number; // 0-100
    geometricIssues: string[];
  };
  // 5. Brand Personality
  brandPersonality: {
    perceivedTraits: string[];
    intendedTraits: string[];
    personalityGap: string;
  };
  // 6. Strengths and Weaknesses
  strengths: string[];
  weaknesses: string[];
  // 7. What should be preserved
  whatToPreserve: string[];
  // 8. What should be improved
  whatToImprove: string[];
}

export interface BrandGuidelineData {
  clearSpaceRatio: string;
  clearSpaceExplanation: string;
  minSizeDigital: string;
  minSizePrint: string;
  dosAndDonts: {
    type: 'dont' | 'do';
    title: string;
    description: string;
    ruleId: string;
  }[];
  applications: {
    title: string;
    category: string;
    description: string;
  }[];
}

export interface CaseStudy {
  id: string;
  name: string;
  industry: string;
  badge: string;
  analysis: OriginalLogoAnalysis;
  versions: {
    versionA: RedesignVersion;
    versionB: RedesignVersion;
    versionC: RedesignVersion;
  };
  guidelines: BrandGuidelineData;
  rationaleSummary: string;
  conclusionTakeaway: string;
}
