import { CaseStudy } from '../types/brand';

export const CASE_STUDIES: CaseStudy[] = [
  {
    id: 'apex-logistics',
    name: 'Apex Global Logistics',
    industry: 'Freight, Supply Chain & Transport',
    badge: 'Classic Enterprise Rebrand',
    analysis: {
      brandName: 'Apex Global Logistics',
      industry: 'Global Freight & Supply Chain',
      established: 'Est. 2002',
      isSvg: true,
      originalSvgOrImg: `<svg viewBox="0 0 400 160" xmlns="http://www.w3.org/2000/svg" class="w-full h-full">
        <!-- Dated drop shadow & beveled globe -->
        <defs>
          <radialGradient id="apexGrad" cx="35%" cy="35%" r="70%">
            <stop offset="0%" stop-color="#60a5fa" />
            <stop offset="50%" stop-color="#2563eb" />
            <stop offset="100%" stop-color="#1e3a8a" />
          </radialGradient>
          <linearGradient id="swooshGrad" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stop-color="#ef4444" />
            <stop offset="100%" stop-color="#b91c1c" />
          </linearGradient>
          <linearGradient id="yellowSwoosh" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stop-color="#facc15" />
            <stop offset="100%" stop-color="#ca8a04" />
          </linearGradient>
          <filter id="datedShadow" x="-20%" y="-20%" width="140%" height="140%">
            <feDropShadow dx="3" dy="4" stdDeviation="3" flood-color="#000" flood-opacity="0.45"/>
          </filter>
        </defs>
        <!-- Icon group -->
        <g transform="translate(30, 20)" filter="url(#datedShadow)">
          <!-- Beveled Globe -->
          <circle cx="60" cy="60" r="46" fill="url(#apexGrad)" stroke="#1d4ed8" stroke-width="2" />
          <!-- Latitude/Longitude lines that clutter at small size -->
          <ellipse cx="60" cy="60" rx="46" ry="16" fill="none" stroke="#93c5fd" stroke-width="1.5" stroke-dasharray="3,2" />
          <ellipse cx="60" cy="60" rx="46" ry="32" fill="none" stroke="#93c5fd" stroke-width="1.5" stroke-dasharray="3,2" />
          <line x1="60" y1="14" x2="60" y2="106" stroke="#93c5fd" stroke-width="1.5" />
          <!-- Aggressive sharp 2000s swooshes orbiting globe -->
          <path d="M 0,90 Q 60,10 120,40 Q 75,55 20,100 Z" fill="url(#swooshGrad)" />
          <path d="M 15,105 Q 70,35 130,55 Q 85,70 30,115 Z" fill="url(#yellowSwoosh)" opacity="0.9" />
          <!-- Sharp arrow head -->
          <polygon points="120,40 135,32 125,50" fill="#dc2626" />
        </g>
        <!-- Typography: Dated faux-metallic Serif with copperplate style -->
        <text x="175" y="72" font-family="'Times New Roman', serif" font-weight="bold" font-size="38" letter-spacing="4" fill="#1e293b">APEX</text>
        <text x="177" y="98" font-family="'Times New Roman', serif" font-size="13" letter-spacing="6" fill="#475569">GLOBAL LOGISTICS</text>
        <!-- Clunky underline -->
        <rect x="177" y="108" width="180" height="2" fill="#ef4444" />
        <text x="177" y="122" font-family="'Arial', sans-serif" font-size="8.5" letter-spacing="2" fill="#64748b">WORLDWIDE FREIGHT & SUPPLY</text>
      </svg>`,
      executiveSummary: 'Apex Global Logistics currently carries visual baggage from the early 2000s tech boom: heavily rendered 3D spheroids, orbiting swooshes with razor edges, and dated transitional serif typography. While conveying international scope, the logo severely breaks down on modern high-DPI screens, mobile apps, and monochromatic manufacturing applications.',
      symbolAnalysis: {
        description: 'A 3D radial-gradient globe encircled by two hyper-saturated, sharp trajectory swooshes terminating in an angular arrow. Multiple latitude/longitude wireframes compete inside the circle.',
        flaws: [
          'High visual noise: 6 overlapping geometric elements inside a 92px sphere',
          'Swoosh tails create odd orphan negative spaces that clip in favicon bounding boxes',
          'Arrowhead is mechanically awkward and loses silhouette clarity below 48px',
          'Heavy reliance on raster-like radial gradients and drop shadow filters'
        ],
        metaphor: 'Global transport and rapid velocity, but executed with clunky 2000s tropes instead of timeless geometry.'
      },
      typographyAnalysis: {
        fontType: 'Times New Roman / Copperplate Hybrid Serif',
        critique: 'High-contrast serifs with razor-thin horizontal brackets that vanish at small sizes. The secondary subtitle "GLOBAL LOGISTICS" is overly tracked with an archaic red dividing bar.',
        legibilityIssue: 'The hairline serif strokes dissolve completely under 64px, and the subtext is illegible on mobile device screens.'
      },
      colorsAnalysis: {
        originalColors: [
          { name: 'Royal Blue Gradient', hex: '#2563EB', note: 'Dated 2000s web gradient base' },
          { name: 'Crimson Red Swoosh', hex: '#DC2626', note: 'Aggressive tone with high chromatic vibration' },
          { name: 'Yellow Ochre Orbit', hex: '#FACC15', note: 'Third primary color creating visual discord' },
          { name: 'Charcoal Serif', hex: '#1E293B', note: 'Incompatible weight against vibrant blue' }
        ],
        harmonyCritique: 'Combines all three primary subtractive hues (blue, red, yellow) with harsh drop shadows, creating visual fatigue and a dated "budget airline" feel.',
        contrastIssue: 'The yellow swoosh against the light blue globe has poor WCAG AA contrast (only 2.1:1).'
      },
      shapeComposition: {
        compositionType: 'Horizontal offset with floating circular emblem and multi-tier subtext',
        balance: 'Front-heavy on the left due to the protruding red arrow; awkward baseline alignment with the wordmark.',
        scalabilityScore: 34,
        geometricIssues: [
          'Wireframe latitude lines blur into gray noise under 48px',
          'Bounding box has empty top-right and bottom-left triangular dead zones',
          'Cannot be legibly stitched on uniforms or laser-engraved in monochrome'
        ]
      },
      brandPersonality: {
        perceivedTraits: ['Dated 2000s', 'Bureaucratic', 'Cluttered', 'Budget Freight'],
        intendedTraits: ['Precision', 'Global Velocity', 'Intelligent Logistics', 'Technological Trust'],
        personalityGap: 'The brand presents itself as an obsolete freight forwarder rather than a modern, API-driven, cloud-integrated supply chain partner.'
      },
      strengths: [
        'The name "Apex" has strong phonetic and conceptual punch (highest point, peak precision)',
        'The global/directional metaphor (globe + forward motion) has solid historical equity among legacy clients',
        'Blue and red provide recognizable heritage if refined into modern precision values'
      ],
      weaknesses: [
        'Over-complicated icon with wireframe lines and drop shadows',
        'Dated serif typography with fragile hairline strokes',
        'Inability to function as a compact app icon or monochrome stamp',
        'Too many competing accent colors (blue, red, yellow, charcoal)'
      ],
      whatToPreserve: [
        'The core brand name and bold confidence of "Apex"',
        'The conceptual duality of Global Scope + Forward Vector (directional velocity)',
        'The foundational trust of a deep cobalt/navy anchor color'
      ],
      whatToImprove: [
        'Strip away skeuomorphic gradients, drop shadows, and wireframe latitudes',
        'Consolidate into a bold, unified, mathematically pure geometric symbol',
        'Transition from fragile serif to high-performance, precision-engineered grotesque typography',
        'Limit the palette to a high-contrast primary anchor and a singular energetic accent'
      ]
    },
    versions: {
      versionA: {
        id: 'versionA',
        label: 'VERSION A',
        styleTitle: 'Minimal & Modern',
        tagline: 'Pure reductive geometry: The Precision Monogram Chevron',
        concept: 'Distills the letter "A" and the directional apex vector into two clean interlocking geometric strokes that suggest an ascending horizon and forward velocity. Maximizes negative space and silhouette strength.',
        symbolMeaning: 'The left upward sweep represents the globe meridian; the right razor chevron forms the letter "A" and points diagonally upward-right (northeast growth vector). Works instantly as an app icon or high-visibility container marking.',
        symbolSvg: (color = '#0f172a', accent = '#2563eb') => `
          <svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg" class="w-full h-full">
            <path d="M 22,82 L 48,22 C 49,19.5 52,19.5 53,22 L 78,82 C 79,84.5 76.5,87 73.5,87 L 61,87 C 59,87 57.5,85.5 56.5,83.5 L 50.5,69 L 34,69 L 41,53 L 53,53 L 50.5,47 Z" fill="${color}" />
            <path d="M 50.5,16 L 79,44.5 C 81,46.5 81,49.5 79,51.5 L 72,58.5 C 70,60.5 67,60.5 65,58.5 L 50.5,44 L 50.5,16 Z" fill="${accent}" />
          </svg>
        `,
        lockupSvg: (mode = 'light', layout = 'horizontal') => {
          const textColor = mode === 'dark' ? '#f8fafc' : '#0f172a';
          const subColor = mode === 'dark' ? '#94a3b8' : '#64748b';
          const primaryColor = mode === 'dark' ? '#38bdf8' : '#0284c7';
          const brandDark = mode === 'dark' ? '#ffffff' : '#0f172a';
          if (layout === 'vertical') {
            return `
              <svg viewBox="0 0 240 200" xmlns="http://www.w3.org/2000/svg" class="w-full h-full">
                <g transform="translate(85, 20) scale(0.7)">
                  <path d="M 22,82 L 48,22 C 49,19.5 52,19.5 53,22 L 78,82 C 79,84.5 76.5,87 73.5,87 L 61,87 C 59,87 57.5,85.5 56.5,83.5 L 50.5,69 L 34,69 L 41,53 L 53,53 L 50.5,47 Z" fill="${brandDark}" />
                  <path d="M 50.5,16 L 79,44.5 C 81,46.5 81,49.5 79,51.5 L 72,58.5 C 70,60.5 67,60.5 65,58.5 L 50.5,44 L 50.5,16 Z" fill="${primaryColor}" />
                </g>
                <text x="120" y="138" text-anchor="middle" font-family="'Space Grotesk', system-ui, sans-serif" font-weight="700" font-size="28" letter-spacing="3" fill="${textColor}">APEX</text>
                <text x="120" y="162" text-anchor="middle" font-family="'Plus Jakarta Sans', system-ui, sans-serif" font-weight="600" font-size="9" letter-spacing="5" fill="${subColor}">GLOBAL LOGISTICS</text>
              </svg>
            `;
          }
          return `
            <svg viewBox="0 0 380 90" xmlns="http://www.w3.org/2000/svg" class="w-full h-full">
              <g transform="translate(15, 10) scale(0.7)">
                <path d="M 22,82 L 48,22 C 49,19.5 52,19.5 53,22 L 78,82 C 79,84.5 76.5,87 73.5,87 L 61,87 C 59,87 57.5,85.5 56.5,83.5 L 50.5,69 L 34,69 L 41,53 L 53,53 L 50.5,47 Z" fill="${brandDark}" />
                <path d="M 50.5,16 L 79,44.5 C 81,46.5 81,49.5 79,51.5 L 72,58.5 C 70,60.5 67,60.5 65,58.5 L 50.5,44 L 50.5,16 Z" fill="${primaryColor}" />
              </g>
              <text x="100" y="48" font-family="'Space Grotesk', system-ui, sans-serif" font-weight="700" font-size="32" letter-spacing="3" fill="${textColor}">APEX</text>
              <text x="102" y="68" font-family="'Plus Jakarta Sans', system-ui, sans-serif" font-weight="600" font-size="9.5" letter-spacing="4.5" fill="${subColor}">GLOBAL LOGISTICS</text>
            </svg>
          `;
        },
        typography: {
          primaryFont: 'Space Grotesk & Plus Jakarta Sans',
          style: 'Geometric Tech Sans with architectural terminal angles',
          rationale: 'Pairs an unapologetic, engineered headline font with an ultra-legible humanist grotesk subtext for high-contrast reading in digital tracking interfaces and freight documentation.',
          specs: [
            { role: 'Wordmark Title', fontFamily: 'Space Grotesk Bold', weight: '700', sampleText: 'APEX', usage: 'Primary logo identifier and high-impact mastheads', characteristics: 'Square shoulders, monoline terminals, engineered apex' },
            { role: 'Descriptor Line', fontFamily: 'Plus Jakarta Sans SemiBold', weight: '600', sampleText: 'GLOBAL LOGISTICS', usage: 'Subtitle, division names, wayfinding', characteristics: 'Wide tracking (+400), optical kerning, ultra-crisp at 8pt' }
          ]
        },
        colors: [
          { name: 'Apex Deep Navy', hex: '#0F172A', rgb: '15, 23, 42', cmyk: '85, 75, 45, 60', pantone: 'PMS 289 C', role: 'Primary', rationale: 'Provides sovereign institutional stability, authority, and premium contrast on all white substrates.' },
          { name: 'Velocity Cyan', hex: '#0284C7', rgb: '2, 132, 199', cmyk: '80, 40, 0, 0', pantone: 'PMS 2194 C', role: 'Secondary', rationale: 'Signifies frictionless movement, cloud connectivity, and modern supply chain automation.' },
          { name: 'Clean White', hex: '#FFFFFF', rgb: '255, 255, 255', cmyk: '0, 0, 0, 0', role: 'Neutral-Light', rationale: 'Negative space anchor ensuring maximum optical legibility and clean breathing room.' },
          { name: 'Muted Slate', hex: '#64748B', rgb: '100, 116, 139', cmyk: '55, 38, 25, 5', pantone: 'PMS Cool Gray 8 C', role: 'Accent', rationale: 'Secondary hierarchy for metadata, regulatory markings, and sub-labels.' }
        ],
        improvements: [
          'Reduced 6 cluttered elements down to 2 precision geometric vectors',
          'Eliminated 100% of drop shadows and rasterized radial blur effects',
          'Perfect silhouette retention down to 16×16 px browser favicon size',
          'Cut color chaos from 4 conflicting hues to a focused, disciplined corporate palette'
        ],
        keyAttributes: ['Ultra-Scalable', 'Digital-Native', 'Minimalist', 'High-Contrast'],
        bestSuitedFor: 'Tech-forward supply chains, logistics platforms, mobile shipping apps, and high-DPI interfaces.'
      },
      versionB: {
        id: 'versionB',
        label: 'VERSION B',
        styleTitle: 'Professional & Corporate',
        tagline: 'Enterprise authority: The Continuous Meridian Hexagon',
        concept: 'Combines the hexagonal structural strength of shipping containers and honeycomb lattices with the dynamic continuous latitude lines of a global transit network. Communicates institutional scale and rock-solid reliability.',
        symbolMeaning: 'The outer hexagon represents structural integrity and freight protection. The internal interlocking facets form a three-dimensional isometric shipping cube that simultaneously reads as a rotating globe.',
        symbolSvg: (color = '#1e3a8a', accent = '#0284c7') => `
          <svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg" class="w-full h-full">
            <!-- Isometric Cube / Hexagon Matrix -->
            <polygon points="50,12 85,32 85,68 50,88 15,68 15,32" fill="none" stroke="${color}" stroke-width="6" stroke-linejoin="round" />
            <polygon points="50,15 82,33 50,51 18,33" fill="${accent}" opacity="0.9" />
            <polygon points="18,36 50,54 50,85 18,67" fill="${color}" />
            <polygon points="50,54 82,36 82,67 50,85" fill="${color}" opacity="0.75" />
            <!-- Central apex vector notch -->
            <path d="M 42,46 L 50,38 L 58,46" stroke="#ffffff" stroke-width="3" stroke-linecap="round" fill="none" />
          </svg>
        `,
        lockupSvg: (mode = 'light', layout = 'horizontal') => {
          const textColor = mode === 'dark' ? '#f8fafc' : '#1e3a8a';
          const subColor = mode === 'dark' ? '#94a3b8' : '#475569';
          const mainCol = mode === 'dark' ? '#60a5fa' : '#1e3a8a';
          const accCol = mode === 'dark' ? '#38bdf8' : '#0284c7';
          if (layout === 'vertical') {
            return `
              <svg viewBox="0 0 240 200" xmlns="http://www.w3.org/2000/svg" class="w-full h-full">
                <g transform="translate(85, 18) scale(0.7)">
                  <polygon points="50,12 85,32 85,68 50,88 15,68 15,32" fill="none" stroke="${mainCol}" stroke-width="6" stroke-linejoin="round" />
                  <polygon points="50,15 82,33 50,51 18,33" fill="${accCol}" opacity="0.9" />
                  <polygon points="18,36 50,54 50,85 18,67" fill="${mainCol}" />
                  <polygon points="50,54 82,36 82,67 50,85" fill="${mainCol}" opacity="0.75" />
                  <path d="M 42,46 L 50,38 L 58,46" stroke="#ffffff" stroke-width="3" stroke-linecap="round" fill="none" />
                </g>
                <text x="120" y="140" text-anchor="middle" font-family="'Plus Jakarta Sans', system-ui, sans-serif" font-weight="800" font-size="26" letter-spacing="4" fill="${textColor}">APEX</text>
                <text x="120" y="162" text-anchor="middle" font-family="'Plus Jakarta Sans', system-ui, sans-serif" font-weight="600" font-size="8.5" letter-spacing="5" fill="${subColor}">GLOBAL LOGISTICS GROUP</text>
              </svg>
            `;
          }
          return `
            <svg viewBox="0 0 380 90" xmlns="http://www.w3.org/2000/svg" class="w-full h-full">
              <g transform="translate(15, 10) scale(0.7)">
                <polygon points="50,12 85,32 85,68 50,88 15,68 15,32" fill="none" stroke="${mainCol}" stroke-width="6" stroke-linejoin="round" />
                <polygon points="50,15 82,33 50,51 18,33" fill="${accCol}" opacity="0.9" />
                <polygon points="18,36 50,54 50,85 18,67" fill="${mainCol}" />
                <polygon points="50,54 82,36 82,67 50,85" fill="${mainCol}" opacity="0.75" />
                <path d="M 42,46 L 50,38 L 58,46" stroke="#ffffff" stroke-width="3" stroke-linecap="round" fill="none" />
              </g>
              <text x="100" y="47" font-family="'Plus Jakarta Sans', system-ui, sans-serif" font-weight="800" font-size="30" letter-spacing="3" fill="${textColor}">APEX</text>
              <text x="102" y="68" font-family="'Plus Jakarta Sans', system-ui, sans-serif" font-weight="600" font-size="9" letter-spacing="4.5" fill="${subColor}">GLOBAL LOGISTICS GROUP</text>
            </svg>
          `;
        },
        typography: {
          primaryFont: 'Plus Jakarta Sans Heavy & Medium',
          style: 'Corporate Geometric Grotesk with high x-height',
          rationale: 'Engineered for financial filings, customs paperwork, shipping containers, and global fleet vehicles.',
          specs: [
            { role: 'Wordmark Title', fontFamily: 'Plus Jakarta Sans Heavy', weight: '800', sampleText: 'APEX', usage: 'Corporate lockup and building signage', characteristics: 'Authoritative, robust vertical stems, balanced optical kerning' },
            { role: 'Descriptor Line', fontFamily: 'Plus Jakarta Sans Medium', weight: '500', sampleText: 'GLOBAL LOGISTICS GROUP', usage: 'Fleet side panels, bill of lading documentation', characteristics: 'Consistent proportional spacing' }
          ]
        },
        colors: [
          { name: 'Maritime Deep Cobalt', hex: '#1E3A8A', rgb: '30, 58, 138', cmyk: '95, 80, 15, 20', pantone: 'PMS 288 C', role: 'Primary', rationale: 'Represents deep-sea cargo, global ports, and institutional legacy.' },
          { name: 'Skyway Cyan', hex: '#0284C7', rgb: '2, 132, 199', cmyk: '80, 40, 0, 0', pantone: 'PMS 2194 C', role: 'Secondary', rationale: 'Air freight, velocity, and high-altitude logistics.' },
          { name: 'Iron Gray', hex: '#475569', rgb: '71, 85, 105', cmyk: '65, 45, 30, 15', role: 'Neutral-Dark', rationale: 'Container steel, tarmac infrastructure, neutral body text.' }
        ],
        improvements: [
          'Transforms a messy circular globe into an authoritative 3D isometric freight cube',
          'Provides instant recognition on shipping containers from 200 meters away',
          'Seamless reproduction in single-color screenprinting and laser stenciling',
          'Elevates the brand from a local trucking broker to an international supply chain conglomerate'
        ],
        keyAttributes: ['Authoritative', 'Architectural', 'Structural', 'Enterprise-Ready'],
        bestSuitedFor: 'Enterprise B2B contracts, maritime freight, fleet logistics, and industrial aviation.'
      },
      versionC: {
        id: 'versionC',
        label: 'VERSION C',
        styleTitle: 'Creative & Contemporary',
        tagline: 'Kinetic forward pulse: The Dynamic Ribbon Meridian',
        concept: 'Re-imagines the original orbiting swoosh concept with modern mathematical spline curves and energetic color interaction. The loop seamlessly twists through itself to form an infinity-style continuous flow.',
        symbolMeaning: 'The ribbon loop forms both the letter "A" and the mathematical symbol for perpetual motion and seamless circular logistics. The gradient interaction evokes modern software agility and frictionless cross-border commerce.',
        symbolSvg: (color = '#4f46e5', accent = '#06b6d4') => `
          <svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg" class="w-full h-full">
            <defs>
              <linearGradient id="flowGrad1" x1="0" y1="0" x2="1" y2="1">
                <stop offset="0%" stop-color="${color}" />
                <stop offset="100%" stop-color="${accent}" />
              </linearGradient>
            </defs>
            <!-- Fluid geometric mobius-style A ribbon -->
            <path d="M 25,82 C 16,68 18,44 32,28 C 42,16 58,16 68,28 C 82,44 84,68 75,82 C 71,88 64,88 60,82 L 48,58 L 38,78 C 34,86 28,87 25,82 Z" fill="none" stroke="url(#flowGrad1)" stroke-width="10" stroke-linecap="round" stroke-linejoin="round" />
            <!-- Internal ascending trajectory arrow -->
            <path d="M 40,55 L 50,38 L 60,55" stroke="${accent}" stroke-width="5" stroke-linecap="round" stroke-linejoin="round" fill="none" />
            <!-- Floating kinetic node -->
            <circle cx="50" cy="20" r="4.5" fill="${color}" />
          </svg>
        `,
        lockupSvg: (mode = 'light', layout = 'horizontal') => {
          const textColor = mode === 'dark' ? '#f8fafc' : '#0f172a';
          const subColor = mode === 'dark' ? '#94a3b8' : '#64748b';
          const primaryGrad = mode === 'dark' ? '#818cf8' : '#4f46e5';
          const accentGrad = mode === 'dark' ? '#38bdf8' : '#06b6d4';
          if (layout === 'vertical') {
            return `
              <svg viewBox="0 0 240 200" xmlns="http://www.w3.org/2000/svg" class="w-full h-full">
                <g transform="translate(85, 18) scale(0.7)">
                  <path d="M 25,82 C 16,68 18,44 32,28 C 42,16 58,16 68,28 C 82,44 84,68 75,82 C 71,88 64,88 60,82 L 48,58 L 38,78 C 34,86 28,87 25,82 Z" fill="none" stroke="${primaryGrad}" stroke-width="10" stroke-linecap="round" stroke-linejoin="round" />
                  <path d="M 40,55 L 50,38 L 60,55" stroke="${accentGrad}" stroke-width="5" stroke-linecap="round" stroke-linejoin="round" fill="none" />
                  <circle cx="50" cy="20" r="4.5" fill="${primaryGrad}" />
                </g>
                <text x="120" y="138" text-anchor="middle" font-family="'Space Grotesk', system-ui, sans-serif" font-weight="700" font-size="28" letter-spacing="2.5" fill="${textColor}">apex</text>
                <text x="120" y="162" text-anchor="middle" font-family="'Plus Jakarta Sans', system-ui, sans-serif" font-weight="600" font-size="9" letter-spacing="4" fill="${subColor}">LOGISTICS PLATFORM</text>
              </svg>
            `;
          }
          return `
            <svg viewBox="0 0 380 90" xmlns="http://www.w3.org/2000/svg" class="w-full h-full">
              <g transform="translate(15, 10) scale(0.7)">
                <path d="M 25,82 C 16,68 18,44 32,28 C 42,16 58,16 68,28 C 82,44 84,68 75,82 C 71,88 64,88 60,82 L 48,58 L 38,78 C 34,86 28,87 25,82 Z" fill="none" stroke="${primaryGrad}" stroke-width="10" stroke-linecap="round" stroke-linejoin="round" />
                <path d="M 40,55 L 50,38 L 60,55" stroke="${accentGrad}" stroke-width="5" stroke-linecap="round" stroke-linejoin="round" fill="none" />
                <circle cx="50" cy="20" r="4.5" fill="${primaryGrad}" />
              </g>
              <text x="100" y="48" font-family="'Space Grotesk', system-ui, sans-serif" font-weight="700" font-size="34" letter-spacing="1" fill="${textColor}">apex</text>
              <text x="102" y="68" font-family="'Plus Jakarta Sans', system-ui, sans-serif" font-weight="600" font-size="9" letter-spacing="4.5" fill="${subColor}">CONNECTED LOGISTICS</text>
            </svg>
          `;
        },
        typography: {
          primaryFont: 'Space Grotesk (Lowercase treatment) & Jakarta Sans',
          style: 'Contemporary Tech-Forward with progressive lowercase styling',
          rationale: 'Signals friendly accessibility, digital product innovation, and developer-friendly logistics APIs.',
          specs: [
            { role: 'Wordmark Title', fontFamily: 'Space Grotesk Bold', weight: '700', sampleText: 'apex', usage: 'SaaS product interface and modern digital campaigns', characteristics: 'Humanist geometry with playful technical precision' }
          ]
        },
        colors: [
          { name: 'Indigo Electric', hex: '#4F46E5', rgb: '79, 70, 229', cmyk: '80, 75, 0, 0', pantone: 'PMS 2726 C', role: 'Primary', rationale: 'Signifies next-generation digital technology, AI tracking, and agile systems.' },
          { name: 'Cyber Cyan', hex: '#06B6D4', rgb: '6, 182, 212', cmyk: '70, 0, 15, 0', pantone: 'PMS 319 C', role: 'Secondary', rationale: 'Instantaneous data flow, freshness, and global connectivity.' },
          { name: 'Carbon Black', hex: '#090A0F', rgb: '9, 10, 15', cmyk: '80, 70, 60, 90', role: 'Neutral-Dark', rationale: 'OLED dark-mode substrate and sharp typographic contrast.' }
        ],
        improvements: [
          'Evolves the harsh angular swoosh into a harmoniously balanced kinetic ribbon',
          'Positions Apex as an innovative digital-first logistics tech scale-up',
          'Delightful interactive potential for digital animations, micro-interactions, and motion graphics',
          'Vibrant color palette with exceptional presence in mobile app stores'
        ],
        keyAttributes: ['Dynamic', 'Progressive', 'Kinetic', 'SaaS-Aligned'],
        bestSuitedFor: 'Logistics technology, autonomous drone delivery, tracking dashboards, and digital-first consumers.'
      }
    },
    guidelines: {
      clearSpaceRatio: '1X (X = Height of the Apex Chevron Symbol)',
      clearSpaceExplanation: 'To maintain visual integrity, the logo must always be surrounded by clear space free of other graphic elements, typography, or page borders. The unit "X" is mathematically derived from the height of the primary chevron symbol.',
      minSizeDigital: '32px height (Primary Lockup) / 20px (Icon-only favicon)',
      minSizePrint: '18mm width / 0.7 inches',
      dosAndDonts: [
        { type: 'dont', title: 'Do not alter color proportions', description: 'Never swap the primary navy and accent cyan, or substitute unauthorized tints.', ruleId: 'rule-color' },
        { type: 'dont', title: 'Do not distort or stretch', description: 'Always maintain original 1:1 aspect ratio when scaling across media.', ruleId: 'rule-stretch' },
        { type: 'dont', title: 'Do not add drop shadows or bevels', description: 'The identity is intentionally flat and reductive; never apply skeuomorphic 3D filters.', ruleId: 'rule-effects' },
        { type: 'dont', title: 'Do not place on busy photographic backgrounds', description: 'Use the knockout white logo over dark imagery, or place inside a solid neutral card.', ruleId: 'rule-background' },
        { type: 'do', title: 'Always preserve the 1X exclusion zone', description: 'Ensure minimum clear space on all sides of the lockup across all print and web layouts.', ruleId: 'rule-clearspace' },
        { type: 'do', title: 'Use pure monochrome in single-ink processes', description: 'Use 100% Black on white paper or 100% White on dark shipping containers.', ruleId: 'rule-monochrome' }
      ],
      applications: [
        { title: 'Fleet Transportation & Container Markings', category: 'Physical Asset', description: 'High-contrast 2-meter lockup on white truck cabs and corrugated steel freight containers for long-distance legibility.' },
        { title: 'Mobile Driver & Dispatch App Icon', category: 'Digital UI', description: 'Icon-only chevron inside rounded squircle with 8:1 contrast for high daylight glare outdoors.' },
        { title: 'Enterprise Logistics Dashboard & Waybill', category: 'Product & Documents', description: 'Compact 28px horizontal lockup embedded in SaaS navigation headers and automated PDF customs invoices.' },
        { title: 'Executive Business Stationery & ID Badge', category: 'Corporate Print', description: 'Matte dark navy letterhead with debossed velocity cyan foil on 350gsm cotton stock.' }
      ]
    },
    rationaleSummary: 'The redesign of Apex Global Logistics transitions the brand from a dated, cluttered 2002 freight forwarder to a precision-engineered, global supply chain power. By eliminating wireframe sphere noise, harsh multi-color swooshes, and fragile serifs, the identity gains absolute scalability, modern authority, and digital-first agility while honoring the foundational equity of the name and forward vector.',
    conclusionTakeaway: 'This project successfully demonstrates how senior graphic design principles—reductive geometry, optical kerning, functional color theory, and strict exclusion zones—can revitalize an enterprise identity without sacrificing brand recognition. The resulting system is scalable across 16px mobile favicons, enterprise SaaS, and 40-foot freight containers.'
  },
  {
    id: 'brew-bean',
    name: 'Brew & Bean Artisan Coffee',
    industry: 'Specialty Beverage & Hospitality',
    badge: 'Artisan Badge to Modern Roaster',
    analysis: {
      brandName: 'Brew & Bean Artisan Coffee',
      industry: 'Specialty Coffee & Hospitality',
      established: 'Est. 2011',
      isSvg: true,
      originalSvgOrImg: `<svg viewBox="0 0 400 160" xmlns="http://www.w3.org/2000/svg" class="w-full h-full">
        <defs>
          <radialGradient id="craftPaper" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stop-color="#fffbeb" />
            <stop offset="100%" stop-color="#fef3c7" />
          </radialGradient>
        </defs>
        <!-- Over-detailed vintage hipster badge -->
        <g transform="translate(40, 15)">
          <!-- Scalloped gear ring -->
          <circle cx="65" cy="65" r="58" fill="#78350f" stroke="#451a03" stroke-width="3" stroke-dasharray="6,4" />
          <circle cx="65" cy="65" r="50" fill="url(#craftPaper)" stroke="#92400e" stroke-width="2" />
          <!-- Tiny laurel leaves that turn into mud at small size -->
          <path d="M 28,65 Q 40,30 65,30 Q 90,30 102,65 Q 90,100 65,100 Q 40,100 28,65" fill="none" stroke="#b45309" stroke-width="1.5" stroke-dasharray="2,2" />
          <!-- Two overly detailed coffee beans with cracks -->
          <ellipse cx="56" cy="62" rx="14" ry="20" fill="#92400e" transform="rotate(-20, 56, 62)" />
          <path d="M 52,44 Q 56,62 50,80" stroke="#fef3c7" stroke-width="2" fill="none" />
          <ellipse cx="74" cy="66" rx="14" ry="20" fill="#78350f" transform="rotate(25, 74, 66)" />
          <path d="M 76,48 Q 72,66 78,84" stroke="#fef3c7" stroke-width="2" fill="none" />
          <!-- Mini stars and banner -->
          <polygon points="65,22 67,27 72,28 68,31 69,36 65,33 61,36 62,31 58,28 63,27" fill="#b45309" />
          <rect x="25" y="100" width="80" height="18" fill="#451a03" rx="3" />
          <text x="65" y="112" text-anchor="middle" font-family="'Times New Roman', serif" font-size="8" fill="#fef3c7" letter-spacing="1">EST. 2011</text>
        </g>
        <!-- Distressed curly vintage typography -->
        <text x="180" y="65" font-family="'Georgia', serif" font-style="italic" font-size="34" fill="#451a03">Brew &amp; Bean</text>
        <text x="182" y="90" font-family="'Courier New', monospace" font-size="12" letter-spacing="5" fill="#92400e">ROASTERS &amp; PURVEYORS</text>
        <text x="182" y="110" font-family="'Georgia', serif" font-size="9.5" fill="#78350f" font-style="italic">Handcrafted in Small Batches • 100% Arabica</text>
      </svg>`,
      executiveSummary: 'Brew & Bean embodies the 2010s "hipster chalkboard badge" wave: scalloped circular stamps, distressed textures, multiple concentric rings, tiny botanical laurels, and script/slab serif collisions. While nostalgic, it fails modern packaging shelf-presence and cannot scale to mobile loyalty apps or minimalist coffee bag packaging.',
      symbolAnalysis: {
        description: 'A circular seal with a dashed outer perimeter, two hand-drawn coffee beans with irregular fissures, star motifs, and an embedded "EST. 2011" ribbon.',
        flaws: [
          'Excessive line density: 4 concentric circles plus laurel leaves in a 130px diameter',
          'Tiny dashed borders blur into solid muddy rings on mobile displays',
          'Ribbon banner overlaps the base of the seal awkwardly'
        ],
        metaphor: 'Craft heritage and artisanal dedication, but trapped in an era-specific retro template.'
      },
      typographyAnalysis: {
        fontType: 'Italic Serif + Monospace Courier Subhead',
        critique: 'Inconsistent typographic pairing. The italic serif wordmark clashes with typewriter monospace descriptors and cramped slogan text.',
        legibilityIssue: 'The italic ampersand and fine descenders blend into background textures on burlap sacks or digital app headers.'
      },
      colorsAnalysis: {
        originalColors: [
          { name: 'Dark Roast Brown', hex: '#451A03', note: 'Heavy, mud-like tone with low vibrancy' },
          { name: 'Amber Ochre', hex: '#B45309', note: 'Dated sepia tone' },
          { name: 'Craft Parchment', hex: '#FEF3C7', note: 'Skeuomorphic aged-paper background tint' }
        ],
        harmonyCritique: 'Monochromatic sepia tones create an aged, dusty impression rather than fresh, vibrant coffee craft.',
        contrastIssue: 'Yellow-ochre details on craft background fall short of accessibility standards.'
      },
      shapeComposition: {
        compositionType: 'Dense circular seal lockup with right-aligned multi-line text',
        balance: 'The heavy circular badge pulls visual center down-left, leaving awkward white space above the wordmark.',
        scalabilityScore: 28,
        geometricIssues: [
          'Beans lose distinct cleft marks below 64px',
          'Dashed lines fill in on thermal receipt printers'
        ]
      },
      brandPersonality: {
        perceivedTraits: ['Dated 2012 Craft', 'Cluttered', 'Rustic', 'Slow'],
        intendedTraits: ['Nordic Minimalism', 'Specialty Origin', 'Refined Sensory Taste', 'Contemporary Roaster'],
        personalityGap: 'Looks like a generic neighborhood chalkboard cafe rather than a precision specialty roastery.'
      },
      strengths: [
        'Strong name equity in "Brew & Bean"',
        'Coffee bean motif is immediately recognizable',
        'Rich earthy tones carry warm sensory cues'
      ],
      weaknesses: [
        'Extreme over-detailing in the stamp emblem',
        'Dated chalkboard-era aesthetic',
        'Poor performance on mobile ordering apps and retail merchandise'
      ],
      whatToPreserve: [
        'The coffee bean geometry as the primary sensory anchor',
        'Warm, sophisticated coffee-inspired color story',
        'Artisanal care and warmth'
      ],
      whatToImprove: [
        'Simplify bean geometry into a single continuous-line or modernist silhouette',
        'Eliminate the scalloped circle, laurels, dashed lines, and ribbon banner',
        'Replace clashing fonts with a refined contemporary grotesque typeface',
        'Introduce a modern warm palette (Espresso Black, Warm Terracotta, Cream Oat)'
      ]
    },
    versions: {
      versionA: {
        id: 'versionA',
        label: 'VERSION A',
        styleTitle: 'Minimal & Modern',
        tagline: 'Nordic precision: The Single-Stroke Bean & Drop',
        concept: 'Combines the silhouette of an organic coffee bean with an inverted extraction drop into a single continuous vector with golden-ratio curves. Pure, modern, and sculptural.',
        symbolMeaning: 'The outer curve traces an Arabica coffee bean; the central negative space forms both the bean cleft and an extraction coffee droplet. Minimal, iconic, and memorable.',
        symbolSvg: (color = '#271710', accent = '#c27848') => `
          <svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg" class="w-full h-full">
            <!-- Organic Modernist Bean -->
            <path d="M 50,15 C 72,15 88,32 88,54 C 88,74 72,85 50,85 C 28,85 12,74 12,54 C 12,32 28,15 50,15 Z" fill="${color}" />
            <!-- Negative space extraction droplet cleft -->
            <path d="M 50,24 C 54,34 62,44 62,56 C 62,64 56,72 50,72 C 44,72 38,64 38,56 C 38,44 46,34 50,24 Z" fill="#faf7f2" />
            <!-- Accent bean core -->
            <circle cx="50" cy="56" r="4.5" fill="${accent}" />
          </svg>
        `,
        lockupSvg: (mode = 'light', layout = 'horizontal') => {
          const textColor = mode === 'dark' ? '#faf7f2' : '#271710';
          const subColor = mode === 'dark' ? '#d4bda8' : '#8c6b54';
          const beanColor = mode === 'dark' ? '#f5ede3' : '#271710';
          const centerBg = mode === 'dark' ? '#090a0f' : '#ffffff';
          const accentDot = '#c27848';
          if (layout === 'vertical') {
            return `
              <svg viewBox="0 0 240 200" xmlns="http://www.w3.org/2000/svg" class="w-full h-full">
                <g transform="translate(85, 18) scale(0.7)">
                  <path d="M 50,15 C 72,15 88,32 88,54 C 88,74 72,85 50,85 C 28,85 12,74 12,54 C 12,32 28,15 50,15 Z" fill="${beanColor}" />
                  <path d="M 50,24 C 54,34 62,44 62,56 C 62,64 56,72 50,72 C 44,72 38,64 38,56 C 38,44 46,34 50,24 Z" fill="${centerBg}" />
                  <circle cx="50" cy="56" r="4.5" fill="${accentDot}" />
                </g>
                <text x="120" y="138" text-anchor="middle" font-family="'Space Grotesk', system-ui, sans-serif" font-weight="700" font-size="24" letter-spacing="2" fill="${textColor}">BREW &amp; BEAN</text>
                <text x="120" y="160" text-anchor="middle" font-family="'Plus Jakarta Sans', system-ui, sans-serif" font-weight="500" font-size="9" letter-spacing="4" fill="${subColor}">SPECIALTY ROASTERS</text>
              </svg>
            `;
          }
          return `
            <svg viewBox="0 0 380 90" xmlns="http://www.w3.org/2000/svg" class="w-full h-full">
              <g transform="translate(15, 10) scale(0.7)">
                <path d="M 50,15 C 72,15 88,32 88,54 C 88,74 72,85 50,85 C 28,85 12,74 12,54 C 12,32 28,15 50,15 Z" fill="${beanColor}" />
                <path d="M 50,24 C 54,34 62,44 62,56 C 62,64 56,72 50,72 C 44,72 38,64 38,56 C 38,44 46,34 50,24 Z" fill="${centerBg}" />
                <circle cx="50" cy="56" r="4.5" fill="${accentDot}" />
              </g>
              <text x="100" y="47" font-family="'Space Grotesk', system-ui, sans-serif" font-weight="700" font-size="28" letter-spacing="2" fill="${textColor}">BREW &amp; BEAN</text>
              <text x="102" y="68" font-family="'Plus Jakarta Sans', system-ui, sans-serif" font-weight="500" font-size="9" letter-spacing="4.5" fill="${subColor}">SPECIALTY ROASTERS</text>
            </svg>
          `;
        },
        typography: {
          primaryFont: 'Space Grotesk & Plus Jakarta Sans',
          style: 'Minimalist Architectural Grotesque with optical warmth',
          rationale: 'Clean modern letterforms echo European third-wave coffee aesthetics.',
          specs: [
            { role: 'Primary Wordmark', fontFamily: 'Space Grotesk Bold', weight: '700', sampleText: 'BREW & BEAN', usage: 'Packaging bags, exterior signage, website header', characteristics: 'Spacious proportions, balanced kerning' }
          ]
        },
        colors: [
          { name: 'Espresso Noir', hex: '#271710', rgb: '39, 23, 16', cmyk: '60, 70, 75, 75', pantone: 'PMS Black 5 C', role: 'Primary', rationale: 'Deep rich roast tone replacing muddy low-contrast brown.' },
          { name: 'Warm Terracotta', hex: '#C27848', rgb: '194, 120, 72', cmyk: '20, 55, 75, 5', pantone: 'PMS 7578 C', role: 'Secondary', rationale: 'Evokes natural coffee cherry parchment and roasting warmth.' },
          { name: 'Oat Cream', hex: '#FAF7F2', rgb: '250, 247, 242', cmyk: '2, 2, 4, 0', role: 'Neutral-Light', rationale: 'Clean tactile base for ceramic cups and uncoated paper packaging.' }
        ],
        improvements: [
          'Replaced 14 cluttered botanical lines with one iconic silhouette',
          'Instantly readable on take-away paper cups and mobile order screens',
          'Eliminated dated vintage stamp cliches'
        ],
        keyAttributes: ['Minimalist', 'Sculptural', 'Nordic', 'Packaging-Ready'],
        bestSuitedFor: 'Specialty coffee roasters, retail whole-bean packaging, and mobile order apps.'
      },
      versionB: {
        id: 'versionB',
        label: 'VERSION B',
        styleTitle: 'Professional & Corporate',
        tagline: 'Global roaster prestige: The Architectural Monogram Seal',
        concept: 'Refines the circular heritage badge into a clean, modern geometric seal with high-contrast type and precision concentric framing.',
        symbolMeaning: 'Interlocking letters B & B form a harmonious coffee bean emblem surrounded by crisp contemporary typography.',
        symbolSvg: (color = '#1f2937', accent = '#d97706') => `
          <svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg" class="w-full h-full">
            <circle cx="50" cy="50" r="42" fill="none" stroke="${color}" stroke-width="4" />
            <path d="M 38,28 L 52,28 C 60,28 65,33 65,39 C 65,44 61,48 55,49 C 62,50 67,55 67,61 C 67,68 61,72 52,72 L 38,72 Z" fill="none" stroke="${color}" stroke-width="4" stroke-linejoin="round" />
            <line x1="48" y1="28" x2="48" y2="72" stroke="${accent}" stroke-width="3" />
          </svg>
        `,
        lockupSvg: (mode = 'light') => {
          const textColor = mode === 'dark' ? '#f8fafc' : '#1f2937';
          const subColor = mode === 'dark' ? '#94a3b8' : '#6b7280';
          return `
            <svg viewBox="0 0 380 90" xmlns="http://www.w3.org/2000/svg" class="w-full h-full">
              <g transform="translate(15, 10) scale(0.7)">
                <circle cx="50" cy="50" r="42" fill="none" stroke="${textColor}" stroke-width="4" />
                <path d="M 38,28 L 52,28 C 60,28 65,33 65,39 C 65,44 61,48 55,49 C 62,50 67,55 67,61 C 67,68 61,72 52,72 L 38,72 Z" fill="none" stroke="${textColor}" stroke-width="4" stroke-linejoin="round" />
                <line x1="48" y1="28" x2="48" y2="72" stroke="#d97706" stroke-width="3" />
              </g>
              <text x="100" y="48" font-family="'Plus Jakarta Sans', system-ui, sans-serif" font-weight="800" font-size="28" letter-spacing="3" fill="${textColor}">BREW &amp; BEAN</text>
              <text x="102" y="68" font-family="'Plus Jakarta Sans', system-ui, sans-serif" font-weight="600" font-size="9" letter-spacing="4" fill="${subColor}">COFFEE MERCHANTS &amp; CO.</text>
            </svg>
          `;
        },
        typography: {
          primaryFont: 'Plus Jakarta Sans Bold',
          style: 'Structured Corporate Sans',
          rationale: 'Balanced authority for international wholesale and franchise operations.',
          specs: [
            { role: 'Wordmark Title', fontFamily: 'Plus Jakarta Sans Bold', weight: '700', sampleText: 'BREW & BEAN', usage: 'Corporate masthead and wholesale catalogue', characteristics: 'Clean proportions' }
          ]
        },
        colors: [
          { name: 'Dark Roast Carbon', hex: '#1F2937', rgb: '31, 41, 55', cmyk: '70, 60, 50, 60', role: 'Primary', rationale: 'Corporate stability and clean typography.' },
          { name: 'Harvest Amber', hex: '#D97706', rgb: '217, 119, 6', cmyk: '15, 55, 100, 0', role: 'Secondary', rationale: 'Premium warmth and coffee bean elevation.' }
        ],
        improvements: [
          'Maintains traditional heritage seal format while adopting rigorous modern geometry',
          'Scales to commercial espresso machine metal badging'
        ],
        keyAttributes: ['Prestigious', 'Corporate', 'Balanced'],
        bestSuitedFor: 'B2B wholesale coffee supply, hotel chains, and franchise cafes.'
      },
      versionC: {
        id: 'versionC',
        label: 'VERSION C',
        styleTitle: 'Creative & Contemporary',
        tagline: 'Sensory vibrancy: The Kinetic Aroma Wave',
        concept: 'Abstracts the aromatic steam and botanical coffee leaf into dynamic overlapping organic vectors with vibrant modern pastels.',
        symbolMeaning: 'Flowing aroma ribbons suggesting fresh morning roast and community conversation.',
        symbolSvg: (color = '#b45309', accent = '#f59e0b') => `
          <svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg" class="w-full h-full">
            <path d="M 30,75 C 30,55 50,45 50,25 C 50,45 70,55 70,75 C 70,85 50,85 50,85 C 50,85 30,85 30,75 Z" fill="${color}" opacity="0.85" />
            <path d="M 45,65 C 45,50 60,42 60,28 C 60,42 75,50 75,65 C 75,75 60,75 60,75 C 60,75 45,75 45,65 Z" fill="${accent}" opacity="0.75" />
          </svg>
        `,
        lockupSvg: (mode = 'light') => {
          const textColor = mode === 'dark' ? '#f8fafc' : '#37271e';
          return `
            <svg viewBox="0 0 380 90" xmlns="http://www.w3.org/2000/svg" class="w-full h-full">
              <g transform="translate(15, 10) scale(0.7)">
                <path d="M 30,75 C 30,55 50,45 50,25 C 50,45 70,55 70,75 C 70,85 50,85 50,85 C 50,85 30,85 30,75 Z" fill="#b45309" opacity="0.85" />
                <path d="M 45,65 C 45,50 60,42 60,28 C 60,42 75,50 75,65 C 75,75 60,75 60,75 C 60,75 45,75 45,65 Z" fill="#f59e0b" opacity="0.75" />
              </g>
              <text x="100" y="48" font-family="'Space Grotesk', system-ui, sans-serif" font-weight="700" font-size="28" letter-spacing="1" fill="${textColor}">brew + bean</text>
              <text x="102" y="68" font-family="'Plus Jakarta Sans', system-ui, sans-serif" font-weight="500" font-size="9" letter-spacing="3" fill="#b45309">CRAFT COFFEE LAB</text>
            </svg>
          `;
        },
        typography: {
          primaryFont: 'Space Grotesk Lowercase',
          style: 'Casual Modern Sans',
          rationale: 'Approachable, creative coffee culture vibe.',
          specs: [
            { role: 'Wordmark Title', fontFamily: 'Space Grotesk', weight: '700', sampleText: 'brew + bean', usage: 'Modern social media and merch', characteristics: 'Friendly lowercase aesthetic' }
          ]
        },
        colors: [
          { name: 'Warm Cinnamon', hex: '#B45309', rgb: '180, 83, 9', cmyk: '20, 70, 100, 10', role: 'Primary', rationale: 'Sensory spices and artisan baking warmth.' },
          { name: 'Golden Honey', hex: '#F59E0B', rgb: '245, 158, 11', cmyk: '0, 40, 95, 0', role: 'Secondary', rationale: 'Sweet notes and morning sunlight.' }
        ],
        improvements: [
          'Vibrant modern energy appealing to Gen-Z coffee lovers',
          'Dynamic and friendly silhouette'
        ],
        keyAttributes: ['Playful', 'Sensory', 'Contemporary'],
        bestSuitedFor: 'Lifestyle cafes, RTD canned cold brew drinks, and social media branding.'
      }
    },
    guidelines: {
      clearSpaceRatio: '1X (X = Width of Bean Silhouette)',
      clearSpaceExplanation: 'Ensure 1X padding around the lockup to prevent visual crowding on coffee bags and cups.',
      minSizeDigital: '28px height',
      minSizePrint: '15mm width',
      dosAndDonts: [
        { type: 'dont', title: 'Do not add rustic grunge textures', description: 'The identity is intentionally clean and modern; avoid faux-chalkboard filters.', ruleId: 'rule-texture' },
        { type: 'dont', title: 'Do not distort the organic curve', description: 'Maintain exact vector proportion.', ruleId: 'rule-organic' },
        { type: 'do', title: 'Use embossed blind stamping on cups', description: 'The simple geometry allows clean single-color debossing.', ruleId: 'rule-deboss' }
      ],
      applications: [
        { title: 'Matte Whole-Bean Packaging Bag', category: 'Physical Packaging', description: 'Hot-stamped foil on textured compostable kraft bag.' },
        { title: 'Mobile Loyalty & Ordering App', category: 'Digital UI', description: 'High-contrast app icon on iOS and Android with easy readability.' }
      ]
    },
    rationaleSummary: 'Brew & Bean transforms from an over-detailed 2011 hipster stamp into a pure, sculptural brand asset. By focusing on a single continuous extraction bean vector, the identity becomes timeless and packaging-ready.',
    conclusionTakeaway: 'Proves how simplifying complex illustrative logos into bold reductive shapes multiplies brand versatility across digital and physical touchpoints.'
  },
  {
    id: 'pulsetech-health',
    name: 'PulseTech BioHealth',
    industry: 'Healthcare Technology & Medical Diagnostics',
    badge: 'Clinical Tech Modernization',
    analysis: {
      brandName: 'PulseTech BioHealth',
      industry: 'Biotechnology & Medical Software',
      established: 'Est. 2008',
      isSvg: true,
      originalSvgOrImg: `<svg viewBox="0 0 400 160" xmlns="http://www.w3.org/2000/svg" class="w-full h-full">
        <defs>
          <linearGradient id="crossGrad" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stop-color="#06b6d4" />
            <stop offset="100%" stop-color="#10b981" />
          </linearGradient>
          <filter id="glow">
            <feGaussianBlur stdDeviation="3" result="blur" />
            <feComposite in="SourceGraphic" in2="blur" operator="over" />
          </filter>
        </defs>
        <g transform="translate(40, 20)">
          <!-- Clunky medical cross with ECG jagged wave cutting across -->
          <path d="M 45,15 L 75,15 L 75,45 L 105,45 L 105,75 L 75,75 L 75,105 L 45,105 L 45,75 L 15,75 L 15,45 L 45,45 Z" fill="url(#crossGrad)" />
          <!-- Jagged ECG heartbeat line disrupting shape -->
          <path d="M 10,60 L 35,60 L 45,35 L 55,85 L 65,45 L 75,70 L 85,60 L 110,60" fill="none" stroke="#ffffff" stroke-width="3" stroke-linecap="round" />
        </g>
        <!-- Condensed tech font with awkward spacing -->
        <text x="180" y="68" font-family="'Impact', 'Arial Black', sans-serif" font-size="34" letter-spacing="1" fill="#0f172a">PULSE<tspan fill="#06b6d4">TECH</tspan></text>
        <text x="182" y="94" font-family="'Arial', sans-serif" font-size="11" letter-spacing="4" fill="#64748b">BIOHEALTH SOLUTIONS</text>
        <text x="182" y="112" font-family="'Arial', sans-serif" font-size="8.5" letter-spacing="1" fill="#94a3b8">DIAGNOSTICS &bull; TELEMETRY &bull; AI SYSTEMS</text>
      </svg>`,
      executiveSummary: 'PulseTech combines two literal healthcare cliches: a standard medical cross sliced in half by a sharp, jagged EKG heartbeat wave. Combined with harsh cyan-to-green neon gradients and condensed heavy typography, it looks like a generic generic pharmacy banner rather than an FDA-compliant biotech leader.',
      symbolAnalysis: {
        description: 'Standard equal-armed Greek cross intersected by an erratic EKG line graph that fractures the structural integrity of the cross.',
        flaws: [
          'Literal healthcare cliche used by thousands of generic health brands',
          'The white heartbeat line creates tiny disjointed negative fragments inside the cross',
          'Sharp jagged spikes suggest acute cardiac distress rather than healing or wellness'
        ],
        metaphor: 'Medical monitoring and life support, executed with literal cliches.'
      },
      typographyAnalysis: {
        fontType: 'Heavy Condensed Sans + Arial Subtext',
        critique: 'Heavy sans-serif has aggressive letterforms that contrast poorly with the clinical care mission.',
        legibilityIssue: 'The color split between PULSE and TECH reduces wordmark cohesion.'
      },
      colorsAnalysis: {
        originalColors: [
          { name: 'Cyan Neon', hex: '#06B6D4', note: 'Overused tech gradient start' },
          { name: 'Mint Green', hex: '#10B981', note: 'Clashes with cyan at the transition zone' }
        ],
        harmonyCritique: 'The teal-green gradient is synonymous with generic web templates from the early 2010s.',
        contrastIssue: 'The white ECG line inside the cyan cross fails accessibility requirements in bright clinical lighting.'
      },
      shapeComposition: {
        compositionType: 'Horizontal lockup with fractured medical symbol',
        balance: 'The erratic heartbeat line creates visual tension that pulls the eye off-center.',
        scalabilityScore: 36,
        geometricIssues: [
          'Heartbeat peaks create tiny triangles that disappear below 32px'
        ]
      },
      brandPersonality: {
        perceivedTraits: ['Generic Clinic', 'Aggressive', 'Dated Telemetry'],
        intendedTraits: ['Advanced AI Diagnostics', 'Human Empathy', 'Clinical Precision', 'Life-Saving Technology'],
        personalityGap: 'Feels like an emergency siren rather than a calm, trustworthy biotech partner.'
      },
      strengths: [
        'The name "PulseTech" has immediate market comprehension',
        'Cross and pulse are strong thematic anchors if reimagined'
      ],
      weaknesses: [
        'Extreme visual cliche with generic cross and ECG zig-zag',
        'Fractured symbol integrity',
        'Aggressive typography'
      ],
      whatToPreserve: [
        'The concept of vital life rhythm and clinical trust',
        'The name PulseTech'
      ],
      whatToImprove: [
        'Replace the literal broken cross with an elegant dual-cell interconnected pulse nexus',
        'Introduce calibrated precision medical typography',
        'Elevate colors to clinical Cobalt Blue and Vital Coral'
      ]
    },
    versions: {
      versionA: {
        id: 'versionA',
        label: 'VERSION A',
        styleTitle: 'Minimal & Modern',
        tagline: 'Precision diagnostics: The Interlocking Vital Nexus',
        concept: 'Two fluid organic cells intertwine to subtly form an optical medical cross at their intersection and a continuous harmonious pulse rhythm.',
        symbolMeaning: 'The interlocking nodes symbolize the seamless fusion of human biology and computational AI telemetry.',
        symbolSvg: (color = '#0284c7', accent = '#0d9488') => `
          <svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg" class="w-full h-full">
            <circle cx="38" cy="50" r="22" fill="${color}" opacity="0.9" />
            <circle cx="62" cy="50" r="22" fill="${accent}" opacity="0.85" />
            <path d="M 50,34 C 54,42 54,58 50,66 C 46,58 46,42 50,34 Z" fill="#ffffff" />
          </svg>
        `,
        lockupSvg: (mode = 'light') => {
          const textColor = mode === 'dark' ? '#f8fafc' : '#0f172a';
          const subColor = mode === 'dark' ? '#94a3b8' : '#64748b';
          return `
            <svg viewBox="0 0 380 90" xmlns="http://www.w3.org/2000/svg" class="w-full h-full">
              <g transform="translate(15, 10) scale(0.7)">
                <circle cx="38" cy="50" r="22" fill="#0284c7" opacity="0.9" />
                <circle cx="62" cy="50" r="22" fill="#0d9488" opacity="0.85" />
                <path d="M 50,34 C 54,42 54,58 50,66 C 46,58 46,42 50,34 Z" fill="#ffffff" />
              </g>
              <text x="100" y="48" font-family="'Space Grotesk', system-ui, sans-serif" font-weight="700" font-size="28" letter-spacing="2" fill="${textColor}">PULSETECH</text>
              <text x="102" y="68" font-family="'Plus Jakarta Sans', system-ui, sans-serif" font-weight="600" font-size="9" letter-spacing="4" fill="${subColor}">BIOHEALTH SYSTEMS</text>
            </svg>
          `;
        },
        typography: {
          primaryFont: 'Space Grotesk & Jakarta Sans',
          style: 'Clinical High-Precision Grotesque',
          rationale: 'Clean mathematical proportions convey computational reliability.',
          specs: [
            { role: 'Wordmark Title', fontFamily: 'Space Grotesk Bold', weight: '700', sampleText: 'PULSETECH', usage: 'Medical device interfaces and FDA dossiers', characteristics: 'Exact horizontal proportions' }
          ]
        },
        colors: [
          { name: 'Clinical Cobalt', hex: '#0284C7', rgb: '2, 132, 199', cmyk: '80, 40, 0, 0', role: 'Primary', rationale: 'Global hospital standard for calm precision.' },
          { name: 'Cellular Teal', hex: '#0D9488', rgb: '13, 148, 136', cmyk: '80, 20, 45, 5', role: 'Secondary', rationale: 'Biomedical synthesis and cellular vitality.' }
        ],
        improvements: [
          'Removes the jarring jagged EKG spikes in favor of harmonious mathematical curves',
          'Retains medical cross symbolism through subtle negative space'
        ],
        keyAttributes: ['Empathetic', 'Clinical', 'Computational'],
        bestSuitedFor: 'Healthcare SaaS, patient monitoring wearables, and biotech investors.'
      },
      versionB: {
        id: 'versionB',
        label: 'VERSION B',
        styleTitle: 'Professional & Corporate',
        tagline: 'Institutional authority: The Architectural Diagnostic Cross',
        concept: 'Re-engineers the medical cross into four precision chevron facets that converge toward a central focal nexus.',
        symbolMeaning: 'Precision diagnostic focus bringing clarity to complex patient telemetry.',
        symbolSvg: (color = '#0369a1') => `
          <svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg" class="w-full h-full">
            <polygon points="50,15 62,35 50,42 38,35" fill="${color}" />
            <polygon points="50,85 62,65 50,58 38,65" fill="${color}" />
            <polygon points="15,50 35,38 42,50 35,62" fill="${color}" />
            <polygon points="85,50 65,38 58,50 65,62" fill="${color}" />
            <circle cx="50" cy="50" r="4" fill="#0284c7" />
          </svg>
        `,
        lockupSvg: (mode = 'light') => {
          const textColor = mode === 'dark' ? '#f8fafc' : '#0369a1';
          return `
            <svg viewBox="0 0 380 90" xmlns="http://www.w3.org/2000/svg" class="w-full h-full">
              <g transform="translate(15, 10) scale(0.7)">
                <polygon points="50,15 62,35 50,42 38,35" fill="${textColor}" />
                <polygon points="50,85 62,65 50,58 38,65" fill="${textColor}" />
                <polygon points="15,50 35,38 42,50 35,62" fill="${textColor}" />
                <polygon points="85,50 65,38 58,50 65,62" fill="${textColor}" />
                <circle cx="50" cy="50" r="4" fill="#0284c7" />
              </g>
              <text x="100" y="48" font-family="'Plus Jakarta Sans', system-ui, sans-serif" font-weight="800" font-size="28" letter-spacing="3" fill="${textColor}">PULSETECH</text>
              <text x="102" y="68" font-family="'Plus Jakarta Sans', system-ui, sans-serif" font-weight="600" font-size="9" letter-spacing="4" fill="#64748b">BIOHEALTH GROUP</text>
            </svg>
          `;
        },
        typography: {
          primaryFont: 'Plus Jakarta Sans Bold',
          style: 'Corporate Medical Grotesk',
          rationale: 'Institutional weight for hospital networks and regulatory submissions.',
          specs: [
            { role: 'Wordmark Title', fontFamily: 'Plus Jakarta Sans Bold', weight: '800', sampleText: 'PULSETECH', usage: 'Medical equipment and enterprise health systems', characteristics: 'Rigorous baseline stability' }
          ]
        },
        colors: [
          { name: 'Deep Hospital Slate', hex: '#0369A1', rgb: '3, 105, 161', cmyk: '90, 50, 15, 5', role: 'Primary', rationale: 'Maximum institutional confidence.' }
        ],
        improvements: ['Eliminates gimmicky gradient fills', 'Provides monumental structural presence'],
        keyAttributes: ['Authoritative', 'Clinical', 'Structured'],
        bestSuitedFor: 'Hospital procurement, hardware diagnostic machines, and clinical trials.'
      },
      versionC: {
        id: 'versionC',
        label: 'VERSION C',
        styleTitle: 'Creative & Contemporary',
        tagline: 'Humanized health: The Continuous Life Wave',
        concept: 'A singular continuous ribbon forming an organic infinity heart-cross with warm energetic accents.',
        symbolMeaning: 'Perpetual vitality and patient-centered healthcare empathy.',
        symbolSvg: (color = '#6366f1', accent = '#ec4899') => `
          <svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg" class="w-full h-full">
            <path d="M 20,50 Q 35,20 50,50 Q 65,80 80,50 Q 65,20 50,50 Q 35,80 20,50 Z" fill="none" stroke="${color}" stroke-width="7" stroke-linecap="round" />
            <circle cx="50" cy="50" r="5" fill="${accent}" />
          </svg>
        `,
        lockupSvg: (mode = 'light') => {
          const textColor = mode === 'dark' ? '#f8fafc' : '#1e1b4b';
          return `
            <svg viewBox="0 0 380 90" xmlns="http://www.w3.org/2000/svg" class="w-full h-full">
              <g transform="translate(15, 10) scale(0.7)">
                <path d="M 20,50 Q 35,20 50,50 Q 65,80 80,50 Q 65,20 50,50 Q 35,80 20,50 Z" fill="none" stroke="#6366f1" stroke-width="7" stroke-linecap="round" />
                <circle cx="50" cy="50" r="5" fill="#ec4899" />
              </g>
              <text x="100" y="48" font-family="'Space Grotesk', system-ui, sans-serif" font-weight="700" font-size="28" letter-spacing="1" fill="${textColor}">pulsetech</text>
              <text x="102" y="68" font-family="'Plus Jakarta Sans', system-ui, sans-serif" font-weight="600" font-size="9" letter-spacing="3" fill="#6366f1">LIFE CONNECTED</text>
            </svg>
          `;
        },
        typography: {
          primaryFont: 'Space Grotesk',
          style: 'Empathetic Humanist Tech',
          rationale: 'Warm, patient-friendly presence.',
          specs: [
            { role: 'Wordmark Title', fontFamily: 'Space Grotesk', weight: '700', sampleText: 'pulsetech', usage: 'Consumer mobile health app', characteristics: 'Soft geometric curve' }
          ]
        },
        colors: [
          { name: 'Digital Violet', hex: '#6366F1', rgb: '99, 102, 241', cmyk: '70, 60, 0, 0', role: 'Primary', rationale: 'Contemporary wellness technology.' },
          { name: 'Vital Rose', hex: '#EC4899', rgb: '236, 72, 153', cmyk: '0, 80, 20, 0', role: 'Secondary', rationale: 'Human empathy and heartbeat vitality.' }
        ],
        improvements: ['Transforms cold hospital vibe into an engaging consumer wellness identity'],
        keyAttributes: ['Warm', 'Empathetic', 'Modern'],
        bestSuitedFor: 'Consumer health tech, fitness telemetry, and telemedicine.'
      }
    },
    guidelines: {
      clearSpaceRatio: '1X (X = Diameter of the Central Nexus)',
      clearSpaceExplanation: 'Maintain 1X boundary around all lockups for medical screen legibility.',
      minSizeDigital: '24px height',
      minSizePrint: '12mm width',
      dosAndDonts: [
        { type: 'dont', title: 'Do not add jagged zigzag lines', description: 'Avoid recreating chaotic heart arrhythmias; maintain continuous calm curve geometry.', ruleId: 'rule-jagged' },
        { type: 'do', title: 'Prioritize high contrast in dark mode', description: 'Medical monitors in surgery rooms operate in low ambient light; verify 7:1 contrast.', ruleId: 'rule-contrast' }
      ],
      applications: [
        { title: 'Hospital Patient Monitor UI', category: 'Software Interface', description: 'High-contrast status header visible across clinical intensive care units.' },
        { title: 'Wearable Biosensor Casing', category: 'Hardware Product', description: 'Micro-laser etched emblem on waterproof medical silicone.' }
      ]
    },
    rationaleSummary: 'PulseTech transforms from an alarming emergency cliche into a serene, advanced biotechnological beacon.',
    conclusionTakeaway: 'Demonstrates how empathy-led reductive geometry restores dignity and credibility to healthcare branding.'
  }
];
